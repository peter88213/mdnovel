#!/usr/bin/python3
"""A novel organizer for writers. 

Version 1.0.1
Requires Python 3.6+
Copyright (c) 2024 Peter Triesberger
For further information see https://github.com/peter88213/mdnovel
License: GNU GPLv3 (https://www.gnu.org/licenses/gpl-3.0.en.html)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
"""
import os
from pathlib import Path
import sys

from configparser import ConfigParser


class Configuration:

    def __init__(self, settings={}, options={}):
        self.settings = None
        self.options = None
        self._sLabel = 'SETTINGS'
        self._oLabel = 'OPTIONS'
        self.set(settings, options)

    def read(self, iniFile):
        config = ConfigParser()
        config.read(iniFile, encoding='utf-8')
        if config.has_section(self._sLabel):
            section = config[self._sLabel]
            for setting in self.settings:
                fallback = self.settings[setting]
                self.settings[setting] = section.get(setting, fallback)
        if config.has_section(self._oLabel):
            section = config[self._oLabel]
            for option in self.options:
                fallback = self.options[option]
                self.options[option] = section.getboolean(option, fallback)

    def set(self, settings=None, options=None):
        if settings is not None:
            self.settings = settings.copy()
        if options is not None:
            self.options = options.copy()

    def write(self, iniFile):
        config = ConfigParser()
        if self.settings:
            config.add_section(self._sLabel)
            for settingId in self.settings:
                config.set(self._sLabel, settingId, str(self.settings[settingId]))
        if self.options:
            config.add_section(self._oLabel)
            for settingId in self.options:
                if self.options[settingId]:
                    config.set(self._oLabel, settingId, 'Yes')
                else:
                    config.set(self._oLabel, settingId, 'No')
        with open(iniFile, 'w', encoding='utf-8') as f:
            config.write(f)
from configparser import ConfigParser


class NvConfiguration(Configuration):

    def read(self, iniFile:str):
        config = ConfigParser()
        config.read(iniFile, encoding='utf-8')
        if config.has_section(self._sLabel):
            section = config[self._sLabel]
            for app in section:
                self.settings[app] = section[app]

from tkinter import filedialog


from abc import ABC, abstractmethod


class ControllerBase(ABC):

    @abstractmethod
    def __init__(self, title):
        self._internalLockFlag = False


    @property
    def isLocked(self):
        return self._internalLockFlag

    @isLocked.setter
    def isLocked(self, setFlag):
        raise NotImplementedError

    def disable_menu(self):
        self._ui.disable_menu()
        self.plugins.disable_menu()

    def enable_menu(self):
        self._ui.enable_menu()
        self.plugins.enable_menu()

    def get_view(self):
        return self._ui

    def lock(self, event=None):
        self._internalLockFlag = True
        self._ui.lock()
        self.plugins.lock()
        return True

    def on_quit(self):
        self.plugins.on_quit()
        self._ui.on_quit()

    def refresh(self):
        pass

    def unlock(self, event=None):
        self._internalLockFlag = False
        self._ui.unlock()
        self.plugins.unlock()
import glob
from pathlib import Path
import subprocess


from calendar import day_name
from calendar import month_name
from datetime import date
from datetime import time
import gettext
import locale

ROOT_PREFIX = 'rt'
CHAPTER_PREFIX = 'ch'
PLOT_LINE_PREFIX = 'ac'
SECTION_PREFIX = 'sc'
PLOT_POINT_PREFIX = 'ap'
CHARACTER_PREFIX = 'cr'
LOCATION_PREFIX = 'lc'
ITEM_PREFIX = 'it'
PRJ_NOTE_PREFIX = 'pn'
CH_ROOT = f'{ROOT_PREFIX}{CHAPTER_PREFIX}'
PL_ROOT = f'{ROOT_PREFIX}{PLOT_LINE_PREFIX}'
CR_ROOT = f'{ROOT_PREFIX}{CHARACTER_PREFIX}'
LC_ROOT = f'{ROOT_PREFIX}{LOCATION_PREFIX}'
IT_ROOT = f'{ROOT_PREFIX}{ITEM_PREFIX}'
PN_ROOT = f'{ROOT_PREFIX}{PRJ_NOTE_PREFIX}'

BRF_SYNOPSIS_SUFFIX = '_brf_synopsis'
CHAPTERS_SUFFIX = '_chapters'
CHARACTER_REPORT_SUFFIX = '_character_report'
CHARACTERS_SUFFIX = '_characters'
CHARLIST_SUFFIX = '_charlist'
DATA_SUFFIX = '_data'
GRID_SUFFIX = '_grid'
ITEM_REPORT_SUFFIX = '_item_report'
ITEMLIST_SUFFIX = '_itemlist'
ITEMS_SUFFIX = '_items'
LOCATION_REPORT_SUFFIX = '_location_report'
LOCATIONS_SUFFIX = '_locations'
LOCLIST_SUFFIX = '_loclist'
PARTS_SUFFIX = '_parts'
PLOTLIST_SUFFIX = '_plotlist'
PLOTLINES_SUFFIX = '_plotlines'
PROJECTNOTES_SUFFIX = '_projectnote_report'
SECTIONLIST_SUFFIX = '_sectionlist'
SECTIONS_SUFFIX = '_sections'
STAGES_SUFFIX = '_structure'


class Error(Exception):
    pass


locale.setlocale(locale.LC_TIME, "")
LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
try:
    CURRENT_LANGUAGE = locale.getlocale()[0][:2]
except:
    CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
try:
    t = gettext.translation('mdnovel', LOCALE_PATH, languages=[CURRENT_LANGUAGE])
    _ = t.gettext
except:

    def _(message):
        return message

WEEKDAYS = day_name
MONTHS = month_name


def norm_path(path):
    if path is None:
        path = ''
    return os.path.normpath(path)


def string_to_list(text, divider=';'):
    elements = []
    try:
        tempList = text.split(divider)
        for element in tempList:
            element = element.strip()
            if element and not element in elements:
                elements.append(element)
        return elements

    except:
        return []


def list_to_string(elements, divider=';'):
    try:
        text = divider.join(elements)
        return text

    except:
        return ''


def intersection(elemList, refList):
    return [elem for elem in elemList if elem in refList]


def verified_date(dateStr):
    if dateStr is not None:
        date.fromisoformat(dateStr)
    return dateStr


def verified_int_string(intStr):
    if intStr is not None:
        int(intStr)
    return intStr


def verified_time(timeStr):
    if  timeStr is not None:
        time.fromisoformat(timeStr)
        while timeStr.count(':') < 2:
            timeStr = f'{timeStr}:00'
    return timeStr



def open_document(document):
    try:
        os.startfile(norm_path(document))
    except:
        try:
            os.system('xdg-open "%s"' % norm_path(document))
        except:
            try:
                os.system('open "%s"' % norm_path(document))
            except:
                pass


class LinkProcessor:
    ZIM_NOTE_EXTENSION = '.txt'

    def __init__(self, model):
        self._mdl = model

    def shorten_path(self, linkPath):
        projectDir = os.path.split(self._mdl.prjFile.filePath)[0]
        try:
            linkPath = os.path.relpath(linkPath, projectDir)
        except ValueError:
            pass
        return linkPath.replace('\\', '/')

    def expand_path(self, linkPath):
        if linkPath.startswith('~'):
            homeDir = str(Path.home())
            linkPath = linkPath.replace('~', homeDir, 1)
        else:
            projectDir = os.path.split(self._mdl.prjFile.filePath)[0]
            linkPath = os.path.join(projectDir, linkPath)
        return os.path.realpath(linkPath).replace('\\', '/')

    def open_link(self, linkPath, launchers):
        linkPath = self.expand_path(linkPath)
        extension = None
        try:
            filePath, extension = os.path.splitext(linkPath)
            if extension == self.ZIM_NOTE_EXTENSION:
                launcher = launchers['.zim']
                if os.path.isfile(launcher):
                    pagePath = filePath.split('/')
                    zimPages = []

                    while pagePath:
                        zimPages.insert(0, pagePath.pop())
                        zimPath = '/'.join(pagePath)
                        zimNotebook = glob.glob(norm_path(f'{zimPath}/*.zim'))
                        if zimNotebook:
                            subprocess.Popen([launcher, zimNotebook[0], ":".join(zimPages)])
                            return

        except:
            pass
        launcher = launchers.get(extension, '')
        if os.path.isfile(launcher):
            subprocess.Popen([launcher, linkPath])
            return

        if os.path.isfile(linkPath):
            open_document(linkPath)
            return

        raise FileNotFoundError(f"{_('File not found')}: {norm_path(linkPath)}")

from datetime import datetime


from abc import ABC, abstractmethod


class FileFactory(ABC):

    def __init__(self, fileClasses):
        self._fileClasses = fileClasses

    @abstractmethod
    def make_file_objects(self, sourcePath, **kwargs):
        pass


class ExportTargetFactory(FileFactory):

    def make_file_objects(self, sourcePath, **kwargs):
        fileName, __ = os.path.splitext(sourcePath)
        suffix = kwargs['suffix']
        for fileClass in self._fileClasses:
            if fileClass.SUFFIX == suffix:
                if suffix is None:
                    suffix = ''
                targetFile = fileClass(f'{fileName}{suffix}{fileClass.EXTENSION}', **kwargs)
                return None, targetFile

        raise Error(f'{_("Export type is not supported")}: "{suffix}".')

import csv

from string import Template

from abc import ABC
from urllib.parse import quote



class File(ABC):
    DESCRIPTION = _('File')
    EXTENSION = None
    SUFFIX = None

    def __init__(self, filePath, **kwargs):
        self.novel = None
        self._filePath = None
        self.projectName = None
        self.projectPath = None
        self.sectionsSplit = False
        self.filePath = filePath

    @property
    def filePath(self):
        return self._filePath

    @filePath.setter
    def filePath(self, filePath: str):
        filePath = filePath.replace('\\', '/')
        if self.SUFFIX is not None:
            suffix = self.SUFFIX
        else:
            suffix = ''
        if filePath.lower().endswith(f'{suffix}{self.EXTENSION}'.lower()):
            self._filePath = filePath
            try:
                head, tail = os.path.split(os.path.realpath(filePath))
            except:
                head, tail = os.path.split(filePath)
            self.projectPath = quote(head.replace('\\', '/'), '/:')
            self.projectName = quote(tail.replace(f'{suffix}{self.EXTENSION}', ''))

    def read(self):
        raise NotImplementedError

    def write(self):
        raise NotImplementedError



class Filter:

    def accept(self, source, eId):
        return True

    def get_message(self, source):
        return ''
from urllib.parse import quote
from urllib.parse import unquote


class BasicElement:

    def __init__(self,
            on_element_change=None,
            title=None,
            desc=None,
            links=None):
        if on_element_change is None:
            self.on_element_change = self.do_nothing
        else:
            self.on_element_change = on_element_change
        self._title = title
        self._desc = desc
        if links is None:
            self._links = {}
        else:
            self._links = links

    @property
    def title(self):
        return self._title

    @title.setter
    def title(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._title != newVal:
            self._title = newVal
            self.on_element_change()

    @property
    def desc(self):
        return self._desc

    @desc.setter
    def desc(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._desc != newVal:
            self._desc = newVal
            self.on_element_change()

    @property
    def links(self):
        try:
            return self._links.copy()
        except AttributeError:
            return None

    @links.setter
    def links(self, newVal):
        if newVal is not None:
            for elem in newVal:
                val = newVal[elem]
                if val is not None:
                    assert type(val) == str
        if self._links != newVal:
            self._links = newVal
            self.on_element_change()

    def do_nothing(self):
        pass

    def from_yaml(self, yaml):
        self._metaDict = {}
        for entry in yaml:
            try:
                metaData = entry.split(':', maxsplit=1)
                metaKey = metaData[0].strip()
                metaValue = metaData[1].strip()
                self._metaDict[metaKey] = metaValue
            except:
                pass

        self.title = self._get_meta_value('Title')

    def get_links(self):
        linkList = []
        if self.links:
            for path in self.links:
                relativeLink = f'[LinkPath]({quote(path)})'
                if self.links[path]:
                    absoluteLink = f'[FullPath](file:///{quote(self.links[path])})'
                else:
                    absoluteLink = ''
                linkList.append((relativeLink, absoluteLink))
        return linkList

    def set_links(self, linkList):
        links = self.links
        for relativeLink, absoluteLink in linkList:
            links[unquote(relativeLink)] = unquote(absoluteLink).split('file:///')[1]
        self.links = links

    def to_yaml(self, yaml):
        if self.title:
            yaml.append(f'Title: {self.title}')
        return yaml

    def _get_meta_value(self, key, default=None):
        text = self._metaDict.get(key, None)
        if text is not None:
            return text
        else:
            return default



class BasicElementNotes(BasicElement):

    def __init__(self,
            notes=None,
            **kwargs):
        super().__init__(**kwargs)
        self._notes = notes

    @property
    def notes(self):
        return self._notes

    @notes.setter
    def notes(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._notes != newVal:
            self._notes = newVal
            self.on_element_change()



class BasicElementTags(BasicElementNotes):

    def __init__(self,
            tags=None,
            **kwargs):
        super().__init__(**kwargs)
        self._tags = tags

    @property
    def tags(self):
        return self._tags

    @tags.setter
    def tags(self, newVal):
        if newVal is not None:
            for elem in newVal:
                if elem is not None:
                    assert type(elem) == str
        if self._tags != newVal:
            self._tags = newVal
            self.on_element_change()

    def from_yaml(self, yaml):
        super().from_yaml(yaml)
        tags = string_to_list(self._get_meta_value('Tags'))
        strippedTags = []
        for tag in tags:
            strippedTags.append(tag.strip())
        self.tags = strippedTags

    def to_yaml(self, yaml):
        yaml = super().to_yaml(yaml)
        if self.tags:
            yaml.append(f'Tags: {list_to_string(self.tags)}')
        return yaml



class WorldElement(BasicElementTags):

    def __init__(self,
            aka=None,
            **kwargs):
        super().__init__(**kwargs)
        self._aka = aka

    @property
    def aka(self):
        return self._aka

    @aka.setter
    def aka(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._aka != newVal:
            self._aka = newVal
            self.on_element_change()

    def from_yaml(self, yaml):
        super().from_yaml(yaml)
        self.aka = self._get_meta_value('Aka')

    def to_yaml(self, yaml):
        yaml = super().to_yaml(yaml)
        if self.aka:
            yaml.append(f'Aka: {self.aka}')
        return yaml



class Character(WorldElement):
    MAJOR_MARKER = _('Major Character')
    MINOR_MARKER = _('Minor Character')

    def __init__(self,
            bio=None,
            goals=None,
            fullName=None,
            isMajor=None,
            birthDate=None,
            deathDate=None,
            **kwargs):
        super().__init__(**kwargs)
        self._bio = bio
        self._goals = goals
        self._fullName = fullName
        self._isMajor = isMajor
        self._birthDate = birthDate
        self._deathDate = deathDate

    @property
    def bio(self):
        return self._bio

    @bio.setter
    def bio(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._bio != newVal:
            self._bio = newVal
            self.on_element_change()

    @property
    def goals(self):
        return self._goals

    @goals.setter
    def goals(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._goals != newVal:
            self._goals = newVal
            self.on_element_change()

    @property
    def fullName(self):
        return self._fullName

    @fullName.setter
    def fullName(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._fullName != newVal:
            self._fullName = newVal
            self.on_element_change()

    @property
    def isMajor(self):
        return self._isMajor

    @isMajor.setter
    def isMajor(self, newVal):
        if newVal is not None:
            assert type(newVal) == bool
        if self._isMajor != newVal:
            self._isMajor = newVal
            self.on_element_change()

    @property
    def birthDate(self):
        return self._birthDate

    @birthDate.setter
    def birthDate(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._birthDate != newVal:
            self._birthDate = newVal
            self.on_element_change()

    @property
    def deathDate(self):
        return self._deathDate

    @deathDate.setter
    def deathDate(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._deathDate != newVal:
            self._deathDate = newVal
            self.on_element_change()

    def from_yaml(self, yaml):
        super().from_yaml(yaml)
        self.isMajor = self._get_meta_value('major', None) == '1'
        self.fullName = self._get_meta_value('FullName')
        self.birthDate = verified_date(self._get_meta_value('BirthDate'))
        self.deathDate = verified_date(self._get_meta_value('DeathDate'))

    def to_yaml(self, yaml):
        yaml = super().to_yaml(yaml)
        if self.isMajor:
            yaml.append(f'major: 1')
        if self.fullName:
            yaml.append(f'FullName: {self.fullName}')
        if self.birthDate:
            yaml.append(f'BirthDate: {self.birthDate}')
        if self.deathDate:
            yaml.append(f'DeathDate: {self.deathDate}')
        return yaml

from datetime import date
from datetime import datetime
from datetime import time
from datetime import timedelta
import re

from calendar import isleap
from datetime import date
from datetime import datetime
from datetime import timedelta


def difference_in_years(startDate, endDate):
    diffyears = endDate.year - startDate.year
    difference = endDate - startDate.replace(endDate.year)
    days_in_year = isleap(endDate.year) and 366 or 365
    years = diffyears + (difference.days + difference.seconds / 86400.0) / days_in_year
    return int(years)


def get_age(nowIso, birthDateIso, deathDateIso):
    now = datetime.fromisoformat(nowIso)
    if deathDateIso:
        deathDate = datetime.fromisoformat(deathDateIso)
        if now > deathDate:
            years = difference_in_years(deathDate, now)
            return -1 * years

    birthDate = datetime.fromisoformat(birthDateIso)
    years = difference_in_years(birthDate, now)
    return years


def get_specific_date(dayStr, refIso):
    refDate = date.fromisoformat(refIso)
    return date.isoformat(refDate + timedelta(days=int(dayStr)))


def get_unspecific_date(dateIso, refIso):
    refDate = date.fromisoformat(refIso)
    return str((date.fromisoformat(dateIso) - refDate).days)


ADDITIONAL_WORD_LIMITS = re.compile(r'--|—|–|\<\/p\>')

NO_WORD_LIMITS = re.compile(r'\<note\>.*?\<\/note\>|\<comment\>.*?\<\/comment\>|\<.+?\>')


class Section(BasicElementTags):

    SCENE = ['-', 'A', 'R', 'x']

    STATUS = [
        None,
        _('Outline'),
        _('Draft'),
        _('1st Edit'),
        _('2nd Edit'),
        _('Done')
    ]

    NULL_DATE = '0001-01-01'
    NULL_TIME = '00:00:00'

    def __init__(self,
            scType=None,
            scene=None,
            status=None,
            appendToPrev=None,
            goal=None,
            conflict=None,
            outcome=None,
            plotNotes=None,
            scDate=None,
            scTime=None,
            day=None,
            lastsMinutes=None,
            lastsHours=None,
            lastsDays=None,
            characters=None,
            locations=None,
            items=None,
            **kwargs):
        super().__init__(**kwargs)
        self._sectionContent = None
        self.wordCount = 0

        self._scType = scType
        self._scene = scene
        self._status = status
        self._appendToPrev = appendToPrev
        self._goal = goal
        self._conflict = conflict
        self._outcome = outcome
        self._plotlineNotes = plotNotes
        try:
            newDate = date.fromisoformat(scDate)
            self._weekDay = newDate.weekday()
            self._localeDate = newDate.strftime('%x')
            self._date = scDate
        except:
            self._weekDay = None
            self._localeDate = None
            self._date = None
        self._time = scTime
        self._day = day
        self._lastsMinutes = lastsMinutes
        self._lastsHours = lastsHours
        self._lastsDays = lastsDays
        self._characters = characters
        self._locations = locations
        self._items = items

        self.scPlotLines = []
        self.scPlotPoints = {}

    @property
    def sectionContent(self):
        return self._sectionContent

    @sectionContent.setter
    def sectionContent(self, text):
        if text is not None:
            assert type(text) == str
        if self._sectionContent != text:
            self._sectionContent = text
            if text is not None:
                text = ADDITIONAL_WORD_LIMITS.sub(' ', text)
                text = NO_WORD_LIMITS.sub('', text)
                self.wordCount = len(text.split())
            else:
                self.wordCount = 0
            self.on_element_change()

    @property
    def scType(self):
        return self._scType

    @scType.setter
    def scType(self, newVal):
        if newVal is not None:
            assert type(newVal) == int
        if self._scType != newVal:
            self._scType = newVal
            self.on_element_change()

    @property
    def scene(self):
        return self._scene

    @scene.setter
    def scene(self, newVal):
        if newVal is not None:
            assert type(newVal) == int
        if self._scene != newVal:
            self._scene = newVal
            self.on_element_change()

    @property
    def status(self):
        return self._status

    @status.setter
    def status(self, newVal):
        if newVal is not None:
            assert type(newVal) == int
        if self._status != newVal:
            self._status = newVal
            self.on_element_change()

    @property
    def appendToPrev(self):
        return self._appendToPrev

    @appendToPrev.setter
    def appendToPrev(self, newVal):
        if newVal is not None:
            assert type(newVal) == bool
        if self._appendToPrev != newVal:
            self._appendToPrev = newVal
            self.on_element_change()

    @property
    def goal(self):
        return self._goal

    @goal.setter
    def goal(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._goal != newVal:
            self._goal = newVal
            self.on_element_change()

    @property
    def conflict(self):
        return self._conflict

    @conflict.setter
    def conflict(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._conflict != newVal:
            self._conflict = newVal
            self.on_element_change()

    @property
    def outcome(self):
        return self._outcome

    @outcome.setter
    def outcome(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._outcome != newVal:
            self._outcome = newVal
            self.on_element_change()

    @property
    def plotlineNotes(self):
        try:
            return dict(self._plotlineNotes)
        except TypeError:
            return None

    @plotlineNotes.setter
    def plotlineNotes(self, newVal):
        if newVal is not None:
            for elem in newVal:
                val = newVal[elem]
                if val is not None:
                    assert type(val) == str
        if self._plotlineNotes != newVal:
            self._plotlineNotes = newVal
            self.on_element_change()

    @property
    def date(self):
        return self._date

    @date.setter
    def date(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._date != newVal:
            if not newVal:
                self._date = None
                self._weekDay = None
                self._localeDate = None
                self.on_element_change()
                return

            try:
                newDate = date.fromisoformat(newVal)
                self._weekDay = newDate.weekday()
            except:
                return

            try:
                self._localeDate = newDate.strftime('%x')
            except:
                self._localeDate = newVal
            self._date = newVal
            self.on_element_change()

    @property
    def weekDay(self):
        return self._weekDay

    @property
    def localeDate(self):
        return self._localeDate

    @property
    def time(self):
        return self._time

    @time.setter
    def time(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._time != newVal:
            self._time = newVal
            self.on_element_change()

    @property
    def day(self):
        return self._day

    @day.setter
    def day(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._day != newVal:
            self._day = newVal
            self.on_element_change()

    @property
    def lastsMinutes(self):
        return self._lastsMinutes

    @lastsMinutes.setter
    def lastsMinutes(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._lastsMinutes != newVal:
            self._lastsMinutes = newVal
            self.on_element_change()

    @property
    def lastsHours(self):
        return self._lastsHours

    @lastsHours.setter
    def lastsHours(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._lastsHours != newVal:
            self._lastsHours = newVal
            self.on_element_change()

    @property
    def lastsDays(self):
        return self._lastsDays

    @lastsDays.setter
    def lastsDays(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._lastsDays != newVal:
            self._lastsDays = newVal
            self.on_element_change()

    @property
    def characters(self):
        try:
            return self._characters[:]
        except TypeError:
            return None

    @characters.setter
    def characters(self, newVal):
        if newVal is not None:
            for elem in newVal:
                if elem is not None:
                    assert type(elem) == str
        if self._characters != newVal:
            self._characters = newVal
            self.on_element_change()

    @property
    def locations(self):
        try:
            return self._locations[:]
        except TypeError:
            return None

    @locations.setter
    def locations(self, newVal):
        if newVal is not None:
            for elem in newVal:
                if elem is not None:
                    assert type(elem) == str
        if self._locations != newVal:
            self._locations = newVal
            self.on_element_change()

    @property
    def items(self):
        try:
            return self._items[:]
        except TypeError:
            return None

    @items.setter
    def items(self, newVal):
        if newVal is not None:
            for elem in newVal:
                if elem is not None:
                    assert type(elem) == str
        if self._items != newVal:
            self._items = newVal
            self.on_element_change()

    def day_to_date(self, referenceDate):
        if self._date:
            return True

        try:
            self.date = get_specific_date(self._day, referenceDate)
            self._day = None
            return True

        except:
            self.date = None
            return False

    def date_to_day(self, referenceDate):
        if self._day:
            return True

        try:
            self._day = get_unspecific_date(self._date, referenceDate)
            self.date = None
            return True

        except:
            self._day = None
            return False

    def from_yaml(self, yaml):
        super().from_yaml(yaml)

        typeStr = self._get_meta_value('type', '0')
        if typeStr in ('0', '1', '2', '3'):
            self.scType = int(typeStr)
        else:
            self.scType = 1
        status = self._get_meta_value('status', None)
        if status in ('2', '3', '4', '5'):
            self.status = int(status)
        else:
            self.status = 1
        scene = self._get_meta_value('scene', 0)
        if scene in ('1', '2', '3'):
            self.scene = int(scene)
        else:
            self.scene = 0

        if not self.scene:
            sceneKind = self._get_meta_value('pacing', None)
            if sceneKind in ('1', '2'):
                self.scene = int(sceneKind) + 1

        self.appendToPrev = self._get_meta_value('append', None) == '1'

        self.date = verified_date(self._get_meta_value('Date'))
        if not self.date:
            self.day = verified_int_string(self._get_meta_value('Day'))

        self.time = verified_time(self._get_meta_value('Time'))

        self.lastsDays = verified_int_string(self._get_meta_value('LastsDays'))
        self.lastsHours = verified_int_string(self._get_meta_value('LastsHours'))
        self.lastsMinutes = verified_int_string(self._get_meta_value('LastsMinutes'))

        scCharacters = self._get_meta_value('Characters')
        self.characters = string_to_list(scCharacters)

        scLocations = self._get_meta_value('Locations')
        self.locations = string_to_list(scLocations)

        scItems = self._get_meta_value('Items')
        self.items = string_to_list(scItems)

    def get_end_date_time(self):
        endDate = None
        endTime = None
        endDay = None
        if self.lastsDays:
            lastsDays = int(self.lastsDays)
        else:
            lastsDays = 0
        if self.lastsHours:
            lastsSeconds = int(self.lastsHours) * 3600
        else:
            lastsSeconds = 0
        if self.lastsMinutes:
            lastsSeconds += int(self.lastsMinutes) * 60
        sectionDuration = timedelta(days=lastsDays, seconds=lastsSeconds)
        if self.time:
            if self.date:
                try:
                    sectionStart = datetime.fromisoformat(f'{self.date} {self.time}')
                    sectionEnd = sectionStart + sectionDuration
                    endDate, endTime = sectionEnd.isoformat().split('T')
                except:
                    pass
            else:
                try:
                    if self.day:
                        dayInt = int(self.day)
                    else:
                        dayInt = 0
                    startDate = (date.min + timedelta(days=dayInt)).isoformat()
                    sectionStart = datetime.fromisoformat(f'{startDate} {self.time}')
                    sectionEnd = sectionStart + sectionDuration
                    endDate, endTime = sectionEnd.isoformat().split('T')
                    endDay = str((date.fromisoformat(endDate) - date.min).days)
                    endDate = None
                except:
                    pass
        return endDate, endTime, endDay

    def to_yaml(self, yaml):
        yaml = super().to_yaml(yaml)
        if self.scType:
            yaml.append(f'type: {self.scType}')
        if self.status > 1:
            yaml.append(f'status: {self.status}')
        if self.scene > 0:
            yaml.append(f'scene: {self.scene}')
        if self.appendToPrev:
            yaml.append(f'append: 1')

        if self.date:
            yaml.append(f'Date: {self.date}')
        elif self.day:
            yaml.append(f'Day: {self.day}')
        if self.time:
            yaml.append(f'Time: {self.time}')

        if self.lastsDays and self.lastsDays != '0':
            yaml.append(f'LastsDays: {self.lastsDays}')
        if self.lastsHours and self.lastsHours != '0':
            yaml.append(f'LastsHours: {self.lastsHours}')
        if self.lastsMinutes and self.lastsMinutes != '0':
            yaml.append(f'LastsMinutes: {self.lastsMinutes}')

        if self.characters:
            yaml.append(f'Characters: {list_to_string(self.characters)}')

        if self.locations:
            yaml.append(f'Locations: {list_to_string(self.locations)}')

        if self.items:
            yaml.append(f'Items: {list_to_string(self.items)}')

        return yaml


class FileExport(File):
    SUFFIX = ''
    _fileHeader = ''
    _partTemplate = ''
    _chapterTemplate = ''
    _unusedChapterTemplate = ''
    _sectionTemplate = ''
    _firstSectionTemplate = ''
    _unusedSectionTemplate = ''
    _stage1Template = ''
    _stage2Template = ''
    _sectionDivider = ''
    _chapterEndTemplate = ''
    _unusedChapterEndTemplate = ''
    _characterSectionHeading = ''
    _characterTemplate = ''
    _locationSectionHeading = ''
    _locationTemplate = ''
    _itemSectionHeading = ''
    _itemTemplate = ''
    _fileFooter = ''
    _projectNoteTemplate = ''
    _arcTemplate = ''

    _DIVIDER = ', '

    def __init__(self, filePath, **kwargs):
        super().__init__(filePath, **kwargs)
        self.sectionFilter = Filter()
        self.chapterFilter = Filter()
        self.characterFilter = Filter()
        self.locationFilter = Filter()
        self.itemFilter = Filter()
        self.arcFilter = Filter()
        self.turningPointFilter = Filter()

    def write(self):
        text = self._get_text()
        backedUp = False
        if os.path.isfile(self.filePath):
            try:
                os.replace(self.filePath, f'{self.filePath}.bak')
            except:
                raise Error(f'{_("Cannot overwrite file")}: "{norm_path(self.filePath)}".')
            else:
                backedUp = True
        try:
            with open(self.filePath, 'w', encoding='utf-8') as f:
                f.write(text)
        except:
            if backedUp:
                os.replace(f'{self.filePath}.bak', self.filePath)
            raise Error(f'{_("Cannot write file")}: "{norm_path(self.filePath)}".')

    def _convert_from_mdnov(self, text, **kwargs):
        if text is None:
            text = ''
        return(text)

    def _get_arcMapping(self, plId):
        arcMapping = dict(
            ID=plId,
            Title=self._convert_from_mdnov(self.novel.plotLines[plId].title, quick=True),
            Desc=self._convert_from_mdnov(self.novel.plotLines[plId].desc),
            Notes=self._convert_from_mdnov(self.novel.plotLines[plId].notes),
            ProjectName=self._convert_from_mdnov(self.projectName, quick=True),
            ProjectPath=self.projectPath,
        )
        return arcMapping

    def _get_arcs(self):
        lines = []
        for plId in self.novel.tree.get_children(PL_ROOT):
            if self.arcFilter.accept(self, plId):
                if self._arcTemplate:
                    template = Template(self._arcTemplate)
                    lines.append(template.safe_substitute(self._get_arcMapping(plId)))
        return lines

    def _get_chapterMapping(self, chId, chapterNumber):
        if chapterNumber == 0:
            chapterNumber = ''

        chapterMapping = dict(
            ID=chId,
            ChapterNumber=chapterNumber,
            Title=self._convert_from_mdnov(self.novel.chapters[chId].title, quick=True),
            Desc=self._convert_from_mdnov(self.novel.chapters[chId].desc),
            Notes=self._convert_from_mdnov(self.novel.chapters[chId].notes),
            ProjectName=self._convert_from_mdnov(self.projectName, quick=True),
            ProjectPath=self.projectPath,
        )
        return chapterMapping

    def _get_chapters(self):
        lines = []
        chapterNumber = 0
        sectionNumber = 0
        wordsTotal = 0
        for chId in self.novel.tree.get_children(CH_ROOT):
            dispNumber = 0
            if not self.chapterFilter.accept(self, chId):
                continue

            template = None
            if self.novel.chapters[chId].chType == 1:
                if self._unusedChapterTemplate:
                    template = Template(self._unusedChapterTemplate)
            elif self.novel.chapters[chId].chLevel == 1 and self._partTemplate:
                template = Template(self._partTemplate)
            else:
                template = Template(self._chapterTemplate)
                chapterNumber += 1
                dispNumber = chapterNumber
            if template is not None:
                lines.append(template.safe_substitute(self._get_chapterMapping(chId, dispNumber)))

            sectionLines, sectionNumber, wordsTotal = self._get_sections(chId, sectionNumber, wordsTotal)
            lines.extend(sectionLines)

            template = None
            if self.novel.chapters[chId].chType == 1:
                if self._unusedChapterEndTemplate:
                    template = Template(self._unusedChapterEndTemplate)
            elif self._chapterEndTemplate:
                template = Template(self._chapterEndTemplate)
            if template is not None:
                lines.append(template.safe_substitute(self._get_chapterMapping(chId, dispNumber)))
        return lines

    def _get_characterMapping(self, crId):
        if self.novel.characters[crId].tags is not None:
            tags = list_to_string(self.novel.characters[crId].tags, divider=self._DIVIDER)
        else:
            tags = ''
        if self.novel.characters[crId].isMajor:
            characterStatus = Character.MAJOR_MARKER
        else:
            characterStatus = Character.MINOR_MARKER

        __, __, __, __, __, __, chrBio, chrGls = self._get_renamings()

        characterMapping = dict(
            ID=crId,
            Title=self._convert_from_mdnov(self.novel.characters[crId].title, quick=True),
            Desc=self._convert_from_mdnov(self.novel.characters[crId].desc),
            Tags=self._convert_from_mdnov(tags),
            AKA=self._convert_from_mdnov(self.novel.characters[crId].aka, quick=True),
            Notes=self._convert_from_mdnov(self.novel.characters[crId].notes),
            Bio=self._convert_from_mdnov(self.novel.characters[crId].bio),
            Goals=self._convert_from_mdnov(self.novel.characters[crId].goals),
            FullName=self._convert_from_mdnov(self.novel.characters[crId].fullName, quick=True),
            Status=characterStatus,
            ProjectName=self._convert_from_mdnov(self.projectName, quick=True),
            ProjectPath=self.projectPath,
            CharactersSuffix=CHARACTERS_SUFFIX,
            CustomChrBio=chrBio,
            CustomChrGoals=chrGls
        )
        return characterMapping

    def _get_characters(self):
        if self._characterSectionHeading:
            lines = [self._characterSectionHeading]
        else:
            lines = []
        template = Template(self._characterTemplate)
        for crId in self.novel.tree.get_children(CR_ROOT):
            if self.characterFilter.accept(self, crId):
                lines.append(template.safe_substitute(self._get_characterMapping(crId)))
        return lines

    def _get_fileFooter(self):
        lines = []
        template = Template(self._fileFooter)
        lines.append(template.safe_substitute(self._get_fileFooterMapping()))
        return lines

    def _get_fileFooterMapping(self):
        return []

    def _get_fileHeader(self):
        lines = []
        template = Template(self._fileHeader)
        lines.append(template.safe_substitute(self._get_fileHeaderMapping()))
        return lines

    def _get_fileHeaderMapping(self):
        filterMessages = []
        expFilters = [
            self.chapterFilter,
            self.sectionFilter,
            self.characterFilter,
            self.locationFilter,
            self.itemFilter,
            self.arcFilter,
            self.turningPointFilter,
            ]
        for expFilter in expFilters:
            message = expFilter.get_message(self)
            if message:
                filterMessages.append(message)
            if filterMessages:
                filters = self._convert_from_mdnov('\n'.join(filterMessages))
            else:
                filters = ''
            pltPrgs, chrczn, wrldbld, goal, cflct, outcm, chrBio, chrGls = self._get_renamings()

        fileHeaderMapping = dict(
            Title=self._convert_from_mdnov(self.novel.title, quick=True),
            Filters=filters,
            Desc=self._convert_from_mdnov(self.novel.desc),
            AuthorName=self._convert_from_mdnov(self.novel.authorName, quick=True),
            CustomPlotProgress=pltPrgs,
            CustomCharacterization=chrczn,
            CustomWorldBuilding=wrldbld,
            CustomGoal=goal,
            CustomConflict=cflct,
            CustomOutcome=outcm,
            CustomChrBio=chrBio,
            CustomChrGoals=chrGls
        )
        return fileHeaderMapping

    def _get_itemMapping(self, itId):
        if self.novel.items[itId].tags is not None:
            tags = list_to_string(self.novel.items[itId].tags, divider=self._DIVIDER)
        else:
            tags = ''

        itemMapping = dict(
            ID=itId,
            Title=self._convert_from_mdnov(self.novel.items[itId].title, quick=True),
            Desc=self._convert_from_mdnov(self.novel.items[itId].desc),
            Notes=self._convert_from_mdnov(self.novel.items[itId].notes),
            Tags=self._convert_from_mdnov(tags, quick=True),
            AKA=self._convert_from_mdnov(self.novel.items[itId].aka, quick=True),
            ProjectName=self._convert_from_mdnov(self.projectName, quick=True),
            ProjectPath=self.projectPath,
            ItemsSuffix=ITEMS_SUFFIX,
        )
        return itemMapping

    def _get_items(self):
        if self._itemSectionHeading:
            lines = [self._itemSectionHeading]
        else:
            lines = []
        template = Template(self._itemTemplate)
        for itId in self.novel.tree.get_children(IT_ROOT):
            if self.itemFilter.accept(self, itId):
                lines.append(template.safe_substitute(self._get_itemMapping(itId)))
        return lines

    def _get_locationMapping(self, lcId):
        if self.novel.locations[lcId].tags is not None:
            tags = list_to_string(self.novel.locations[lcId].tags, divider=self._DIVIDER)
        else:
            tags = ''

        locationMapping = dict(
            ID=lcId,
            Title=self._convert_from_mdnov(self.novel.locations[lcId].title, quick=True),
            Desc=self._convert_from_mdnov(self.novel.locations[lcId].desc),
            Notes=self._convert_from_mdnov(self.novel.locations[lcId].notes),
            Tags=self._convert_from_mdnov(tags, quick=True),
            AKA=self._convert_from_mdnov(self.novel.locations[lcId].aka, quick=True),
            ProjectName=self._convert_from_mdnov(self.projectName, quick=True),
            ProjectPath=self.projectPath,
            LocationsSuffix=LOCATIONS_SUFFIX,
        )
        return locationMapping

    def _get_locations(self):
        if self._locationSectionHeading:
            lines = [self._locationSectionHeading]
        else:
            lines = []
        template = Template(self._locationTemplate)
        for lcId in self.novel.tree.get_children(LC_ROOT):
            if self.locationFilter.accept(self, lcId):
                lines.append(template.safe_substitute(self._get_locationMapping(lcId)))
        return lines

    def _get_renamings(self):
        if self.novel.customPlotProgress:
            pltPrgs = self.novel.customPlotProgress
        else:
            pltPrgs = _('Plot progress')
        if self.novel.customCharacterization:
            chrczn = self.novel.customCharacterization
        else:
            chrczn = _('Characterization')
        if self.novel.customWorldBuilding:
            wrldbld = self.novel.customWorldBuilding
        else:
            wrldbld = _('World building')
        if self.novel.customGoal:
            goal = self.novel.customGoal
        else:
            goal = _('Opening')
        if self.novel.customConflict:
            cflct = self.novel.customConflict
        else:
            cflct = _('Peak em. moment')
        if self.novel.customOutcome:
            outcm = self.novel.customOutcome
        else:
            outcm = _('Ending')
        if self.novel.customChrBio:
            chrBio = self.novel.customChrBio
        else:
            chrBio = _('Bio')
        if self.novel.customChrGoals:
            chrGls = self.novel.customChrGoals
        else:
            chrGls = _('Goals')
        return pltPrgs, chrczn, wrldbld, goal, cflct, outcm, chrBio, chrGls

    def _get_sectionMapping(self, scId, sectionNumber, wordsTotal, firstInChapter=False):

        if sectionNumber == 0:
            sectionNumber = ''
        if self.novel.sections[scId].tags is not None:
            tags = list_to_string(self.novel.sections[scId].tags, divider=self._DIVIDER)
        else:
            tags = ''

        if self.novel.sections[scId].characters is not None:
            sChList = []
            for crId in self.novel.sections[scId].characters:
                sChList.append(self.novel.characters[crId].title)
            sectionChars = list_to_string(sChList, divider=self._DIVIDER)

            if sChList:
                viewpointChar = sChList[0]
            else:
                viewpointChar = ''
        else:
            sectionChars = ''
            viewpointChar = ''

        if self.novel.sections[scId].locations is not None:
            sLcList = []
            for lcId in self.novel.sections[scId].locations:
                sLcList.append(self.novel.locations[lcId].title)
            sectionLocs = list_to_string(sLcList, divider=self._DIVIDER)
        else:
            sectionLocs = ''

        if self.novel.sections[scId].items is not None:
            sItList = []
            for itId in self.novel.sections[scId].items:
                sItList.append(self.novel.items[itId].title)
            sectionItems = list_to_string(sItList, divider=self._DIVIDER)
        else:
            sectionItems = ''

        if self.novel.sections[scId].date is not None and self.novel.sections[scId].date != Section.NULL_DATE:
            scDay = ''
            isoDate = self.novel.sections[scId].date
            cmbDate = self.novel.sections[scId].localeDate
            yearStr, monthStr, dayStr = isoDate.split('-')
            dtMonth = MONTHS[int(monthStr) - 1]
            try:
                dtWeekday = WEEKDAYS[self.novel.sections[scId].weekDay]
            except TypeError:
                dtWeekday = ''

        else:
            isoDate = ''
            yearStr = ''
            monthStr = ''
            dayStr = ''
            dtMonth = ''
            dtWeekday = ''
            if self.novel.sections[scId].day is not None:
                scDay = self.novel.sections[scId].day
                cmbDate = f'{_("Day")} {self.novel.sections[scId].day}'
            else:
                scDay = ''
                cmbDate = ''

        if self.novel.sections[scId].time is not None:
            h, m, s = self.novel.sections[scId].time.split(':')
            scTime = f'{h}:{m}'
            odsTime = f'PT{h}H{m}M{s}S'
        else:
            scTime = ''
            odsTime = ''

        if self.novel.sections[scId].lastsDays is not None and self.novel.sections[scId].lastsDays != '0':
            lastsDays = self.novel.sections[scId].lastsDays
            days = f'{self.novel.sections[scId].lastsDays}d '
        else:
            lastsDays = ''
            days = ''

        if self.novel.sections[scId].lastsHours is not None and self.novel.sections[scId].lastsHours != '0':
            lastsHours = self.novel.sections[scId].lastsHours
            hours = f'{self.novel.sections[scId].lastsHours}h '
        else:
            lastsHours = ''
            hours = ''

        if self.novel.sections[scId].lastsMinutes is not None and self.novel.sections[scId].lastsMinutes != '0':
            lastsMinutes = self.novel.sections[scId].lastsMinutes
            minutes = f'{self.novel.sections[scId].lastsMinutes}min'
        else:
            lastsMinutes = ''
            minutes = ''

        duration = f'{days}{hours}{minutes}'

        pltPrgs, chrczn, wrldbld, goal, cflct, outcm, __, __ = self._get_renamings()
        sectionMapping = dict(
            ID=scId,
            SectionNumber=sectionNumber,
            Title=self._convert_from_mdnov(
                self.novel.sections[scId].title,
                quick=True
                ),
            Desc=self._convert_from_mdnov(
                self.novel.sections[scId].desc,
                append=self.novel.sections[scId].appendToPrev
                ),
            WordCount=str(self.novel.sections[scId].wordCount),
            WordsTotal=wordsTotal,
            Status=int(self.novel.sections[scId].status),
            SectionContent=self._convert_from_mdnov(
                        self.novel.sections[scId].sectionContent,
                        append=self.novel.sections[scId].appendToPrev,
                        firstInChapter=firstInChapter,
                        ),
            Date=isoDate,
            Time=scTime,
            OdsTime=odsTime,
            Day=scDay,
            ScDate=cmbDate,
            DateYear=yearStr,
            DateMonth=monthStr,
            DateDay=dayStr,
            DateWeekday=dtWeekday,
            MonthName=dtMonth,
            LastsDays=lastsDays,
            LastsHours=lastsHours,
            LastsMinutes=lastsMinutes,
            Duration=duration,
            Scene=Section.SCENE[self.novel.sections[scId].scene],
            Goal=self._convert_from_mdnov(self.novel.sections[scId].goal),
            Conflict=self._convert_from_mdnov(self.novel.sections[scId].conflict),
            Outcome=self._convert_from_mdnov(self.novel.sections[scId].outcome),
            Tags=self._convert_from_mdnov(tags, quick=True),
            Characters=sectionChars,
            Viewpoint=viewpointChar,
            Locations=sectionLocs,
            Items=sectionItems,
            Notes=self._convert_from_mdnov(self.novel.sections[scId].notes),
            ProjectName=self._convert_from_mdnov(self.projectName, quick=True),
            ProjectPath=self.projectPath,
            SectionsSuffix=SECTIONS_SUFFIX,
            CustomPlotProgress=pltPrgs,
            CustomCharacterization=chrczn,
            CustomWorldBuilding=wrldbld,
            CustomGoal=goal,
            CustomConflict=cflct,
            CustomOutcome=outcm
        )
        return sectionMapping

    def _get_sections(self, chId, sectionNumber, wordsTotal):
        lines = []
        firstSectionInChapter = True
        for scId in self.novel.tree.get_children(chId):
            template = None
            dispNumber = 0
            if not self.sectionFilter.accept(self, scId):
                continue

            sectionContent = self.novel.sections[scId].sectionContent
            if sectionContent is None:
                sectionContent = ''

            if self.novel.sections[scId].scType == 2:
                if self._stage1Template:
                    template = Template(self._stage1Template)
                else:
                    continue

            elif self.novel.sections[scId].scType == 3:
                if self._stage2Template:
                    template = Template(self._stage2Template)
                else:
                    continue

            elif self.novel.sections[scId].scType == 1 or self.novel.chapters[chId].chType == 1:
                if self._unusedSectionTemplate:
                    template = Template(self._unusedSectionTemplate)
                else:
                    continue

            else:
                sectionNumber += 1
                dispNumber = sectionNumber
                wordsTotal += self.novel.sections[scId].wordCount
                template = Template(self._sectionTemplate)
                if firstSectionInChapter and self._firstSectionTemplate:
                    template = Template(self._firstSectionTemplate)
            if not (firstSectionInChapter or self.novel.sections[scId].appendToPrev or self.novel.sections[scId].scType > 1):
                lines.append(self._sectionDivider)
            if template is not None:
                lines.append(
                    template.safe_substitute(
                        self._get_sectionMapping(
                            scId, dispNumber,
                            wordsTotal,
                            firstInChapter=firstSectionInChapter,
                            )
                        )
                    )
            if self.novel.sections[scId].scType < 2:
                firstSectionInChapter = False
        return lines, sectionNumber, wordsTotal

    def _get_prjNoteMapping(self, pnId):
        noteMapping = dict(
            ID=pnId,
            Title=self._convert_from_mdnov(self.novel.projectNotes[pnId].title, quick=True),
            Desc=self._convert_from_mdnov(self.novel.projectNotes[pnId].desc),
            ProjectName=self._convert_from_mdnov(self.projectName, quick=True),
            ProjectPath=self.projectPath,
        )
        return noteMapping

    def _get_projectNotes(self):
        lines = []
        template = Template(self._projectNoteTemplate)
        for pnId in self.novel.tree.get_children(PN_ROOT):
            pnMap = self._get_prjNoteMapping(pnId)
            lines.append(template.safe_substitute(pnMap))
        return lines

    def _get_text(self):
        lines = self._get_fileHeader()
        lines.extend(self._get_chapters())
        lines.extend(self._get_characters())
        lines.extend(self._get_locations())
        lines.extend(self._get_items())
        lines.extend(self._get_arcs())
        lines.extend(self._get_projectNotes())
        lines.extend(self._get_fileFooter())
        return ''.join(lines)



class CsvFile(FileExport):

    EXTENSION = '.csv'

    def write(self):
        csvRows = self._get_text()
        backedUp = False
        if os.path.isfile(self.filePath):
            try:
                os.replace(self.filePath, f'{self.filePath}.bak')
            except:
                raise Error(f'{_("Cannot overwrite file")}: "{norm_path(self.filePath)}".')
            else:
                backedUp = True
        try:
            with open(self.filePath, 'w', encoding='utf-8', newline='') as f:
                csvWriter = csv.writer(f, dialect='excel')
                for row in csvRows:
                    csvWriter.writerow(row)
        except:
            if backedUp:
                os.replace(f'{self.filePath}.bak', self.filePath)
            raise Error(f'{_("Cannot write file")}: "{norm_path(self.filePath)}".')

    def _get_character_columns(self, crId):
        return []

    def _get_characters(self):
        csvRows = [self._get_header_columns()]
        for crId in self.novel.tree.get_children(CR_ROOT):
            csvColumns = self._get_character_columns(crId)
            csvRows.append(csvColumns)
        return csvRows

    def _get_chapter_columns(self, chId, chNumber):
        return []

    def _get_chapters(self):
        csvRows = [self._get_header_columns()]
        chNumber = 0
        for chId in self.novel.tree.get_children(CH_ROOT):
            if self.novel.chapters[chId].chType > 0:
                continue

                chNumber += 1
                csvColumns = self._get_chapter_columns(chId, chNumber)
                csvRows.append(csvColumns)
        return csvRows

    def _get_header_columns(self):
        return []

    def _get_item_columns(self, ItId):
        return []

    def _get_items(self):
        csvRows = [self._get_header_columns()]
        for ItId in self.novel.tree.get_children(IT_ROOT):
            csvColumns = self._get_item_columns(ItId)
            csvRows.append(csvColumns)
        return csvRows

    def _get_location_columns(self, lcId):
        return []

    def _get_locations(self):
        csvRows = [self._get_header_columns()]
        for lcId in self.novel.tree.get_children(LC_ROOT):
            csvColumns = self._get_location_columns(lcId)
            csvRows.append(csvColumns)
        return csvRows

    def _get_plotline_columns(self, plId):
        return []

    def _get_plotlines(self):
        csvRows = [self._get_header_columns()]
        for plId in self.novel.tree.get_children(PL_ROOT):
            csvColumns = self._get_plotline_columns(plId)
            csvRows.append(csvColumns)
        return csvRows

    def _get_section_columns(self, scId, scNumber, wordsTotal):
        return []

    def _get_sections(self):
        csvRows = [self._get_header_columns()]
        scNumber = 0
        wordsTotal = 0
        for chId in self.novel.tree.get_children(CH_ROOT):
            for scId in self.novel.tree.get_children(chId):
                if self.novel.sections[scId].scType > 0:
                    continue

                scNumber += 1
                wordsTotal += self.novel.sections[scId].wordCount
                csvColumns = self._get_section_columns(scId, scNumber, wordsTotal)
                csvRows.append(csvColumns)
        return csvRows



class CsvCharList(CsvFile):

    DESCRIPTION = _('Character list')
    SUFFIX = CHARLIST_SUFFIX

    def _get_header_columns(self):
        pltPrgs, chrczn, wrldbld, goal, cflct, outcm, chrBio, chrGls = self._get_renamings()
        columns = []
        columns.append('ID')
        columns.append(_("Title"))
        columns.append(_("Full name"))
        columns.append(_("Aka"))
        columns.append(_("Description"))
        columns.append(chrBio)
        columns.append(chrGls)
        columns.append(_("Status"))
        columns.append(_("Tags"))
        columns.append(_("Notes"))
        return columns

    def _get_character_columns(self, crId):
        columns = []
        mapping = self._get_characterMapping(crId)
        columns.append(mapping['ID'])
        columns.append(mapping['Title'])
        columns.append(mapping['FullName'])
        columns.append(mapping['AKA'])
        columns.append(mapping['Desc'])
        columns.append(mapping['Bio'])
        columns.append(mapping['Goals'])
        columns.append(mapping['Status'])
        columns.append(mapping['Tags'])
        columns.append(mapping['Notes'])
        return columns

    def _get_text(self):
        return self._get_characters()



class CsvGrid(CsvFile):

    DESCRIPTION = _('Plot grid')
    SUFFIX = GRID_SUFFIX

    def _get_header_columns(self):
        pltPrgs, chrczn, wrldbld, goal, cflct, outcm, chrBio, chrGls = self._get_renamings()
        columns = []
        columns.append(_("Section"))
        columns.append(_("Date"))
        columns.append(_("Time"))
        columns.append(_("Day"))
        columns.append(_("Title"))
        columns.append(_("Description"))
        columns.append(_("Viewpoint"))
        for plId in self.novel.tree.get_children(PL_ROOT):
            columns.append(self.novel.plotLines[plId].title)
        columns.append(_("Tags"))
        columns.append(_("Scene"))
        columns.append(f'{_("Goal")} / {_("Reaction")} / {goal}')
        columns.append(f'{chrczn} / {_("Conflict")} / {_("Dilemma")} / {cflct}')
        columns.append(f'{wrldbld} / {_("Outcome")} / {_("Choice")} / {outcm}')
        columns.append(_("Notes"))
        return columns

    def _get_section_columns(self, scId, scNumber, wordsTotal):
        columns = []
        mapping = self._get_sectionMapping(scId, scNumber, 0)
        columns.append(mapping['SectionNumber'])
        columns.append(mapping['Date'])
        columns.append(mapping['Time'])
        columns.append(mapping['Day'])
        columns.append(mapping['Title'])
        columns.append(mapping['Desc'])
        columns.append(mapping['Viewpoint'])

        section = self.novel.sections[scId]
        for plId in self.novel.tree.get_children(PL_ROOT):
            plotlineNotes = section.plotlineNotes
            if plotlineNotes:
                arcNote = plotlineNotes.get(plId, '')
            else:
                arcNote = ''
            columns.append(arcNote)

        columns.append(mapping['Tags'])
        columns.append(mapping['Scene'])
        columns.append(mapping['Goal'])
        columns.append(mapping['Conflict'])
        columns.append(mapping['Outcome'])
        columns.append(mapping['Notes'])
        return columns

    def _get_text(self):
        return self._get_sections()



class CsvItemList(CsvFile):

    DESCRIPTION = _('Item list')
    SUFFIX = ITEMLIST_SUFFIX

    def _get_header_columns(self):
        pltPrgs, chrczn, wrldbld, goal, cflct, outcm, chrBio, chrGls = self._get_renamings()
        columns = []
        columns.append('ID')
        columns.append(_("Title"))
        columns.append(_("Aka"))
        columns.append(_("Description"))
        columns.append(_("Tags"))
        columns.append(_("Notes"))
        return columns

    def _get_item_columns(self, crId):
        columns = []
        mapping = self._get_itemMapping(crId)
        columns.append(mapping['ID'])
        columns.append(mapping['Title'])
        columns.append(mapping['AKA'])
        columns.append(mapping['Desc'])
        columns.append(mapping['Tags'])
        columns.append(mapping['Notes'])
        return columns

    def _get_text(self):
        return self._get_items()



class CsvLocList(CsvFile):
    DESCRIPTION = _('Location list')
    SUFFIX = LOCLIST_SUFFIX

    def _get_header_columns(self):
        pltPrgs, chrczn, wrldbld, goal, cflct, outcm, chrBio, chrGls = self._get_renamings()
        columns = []
        columns.append('ID')
        columns.append(_("Title"))
        columns.append(_("Aka"))
        columns.append(_("Description"))
        columns.append(_("Tags"))
        columns.append(_("Notes"))
        return columns

    def _get_location_columns(self, crId):
        columns = []
        mapping = self._get_locationMapping(crId)
        columns.append(mapping['ID'])
        columns.append(mapping['Title'])
        columns.append(mapping['AKA'])
        columns.append(mapping['Desc'])
        columns.append(mapping['Tags'])
        columns.append(mapping['Notes'])
        return columns

    def _get_text(self):
        return self._get_locations()



class CsvSectionList(CsvFile):

    DESCRIPTION = _('Section list')
    SUFFIX = SECTIONLIST_SUFFIX

    def _get_sectionMapping(self, scId, sectionNumber, wordsTotal, **kwargs):
        sectionMapping = super()._get_sectionMapping(scId, sectionNumber, wordsTotal)
        sectionMapping['Status'] = Section.STATUS[sectionMapping['Status']]
        return sectionMapping

    def _get_header_columns(self):
        pltPrgs, chrczn, wrldbld, goal, cflct, outcm, chrBio, chrGls = self._get_renamings()
        columns = []
        columns.append('ID')
        columns.append(_("Section"))
        columns.append(_("Title"))
        columns.append(_("Description"))
        columns.append(_("Viewpoint"))
        columns.append(_("Date"))
        columns.append(_("Time"))
        columns.append(_("Day"))
        columns.append(_("Duration"))
        columns.append(_("Tags"))
        columns.append(_("Notes"))
        columns.append(_("Scene"))
        columns.append(f'{_("Goal")} / {_("Reaction")} / {goal}')
        columns.append(f'{chrczn} / {_("Conflict")} / {_("Dilemma")} / {cflct}')
        columns.append(f'{wrldbld} / {_("Outcome")} / {_("Choice")} / {outcm}')
        columns.append(_("Status"))
        columns.append(_("Words total"))
        columns.append(_("Word count"))
        columns.append(_("Characters"))
        columns.append(_("Locations"))
        columns.append(_("Items"))
        return columns

    def _get_section_columns(self, scId, scNumber, wordsTotal):
        columns = []
        mapping = self._get_sectionMapping(scId, scNumber, wordsTotal)
        columns.append(mapping['ID'])
        columns.append(mapping['SectionNumber'])
        columns.append(mapping['Title'])
        columns.append(mapping['Desc'])
        columns.append(mapping['Viewpoint'])
        columns.append(mapping['Date'])
        columns.append(mapping['Time'])
        columns.append(mapping['Day'])
        columns.append(mapping['Duration'])
        columns.append(mapping['Tags'])
        columns.append(mapping['Notes'])
        columns.append(mapping['Scene'])
        columns.append(mapping['Goal'])
        columns.append(mapping['Conflict'])
        columns.append(mapping['Outcome'])
        columns.append(mapping['Status'])
        columns.append(mapping['WordsTotal'])
        columns.append(mapping['WordCount'])
        columns.append(mapping['Characters'])
        columns.append(mapping['Locations'])
        columns.append(mapping['Items'])
        return columns

    def _get_text(self):
        return self._get_sections()



class ScVpFilter:

    def __init__(self, crId):
        self._crId = crId

    def accept(self, source, scId):
        try:
            if self._crId == source.novel.sections[scId].characters[0]:
                return True

        except:
            pass
        return False

    def get_message(self, source):
        return f'{_("Sections from viewpoint")}: {source.novel.characters[self._crId].title}'


class ScAcFilter:

    def __init__(self, plId):
        self._plId = plId

    def accept(self, source, scId):
        try:
            if self._plId in source.novel.sections[scId].scPlotLines:
                return True

        except:
            pass
        return False

    def get_message(self, source):
        return f'{_("Sections belonging to plot line")}: "{source.novel.plotLines[self._plId].title}"'


class ChVpFilter:

    def __init__(self, crId):
        self._crId = crId

    def accept(self, source, chId):
        for scId in source.novel.tree.get_children(chId):
            try:
                if self._crId == source.novel.sections[scId].characters[0]:
                    return True

            except:
                pass
        return False

    def get_message(self, source):
        return f'{_("Chapters from viewpoint")}: {source.novel.characters[self._crId].title}'


class ChAcFilter:

    def __init__(self, plId):
        self._plId = plId

    def accept(self, source, chId):
        for scId in source.novel.tree.get_children(chId):
            try:
                if self._plId in source.novel.sections[scId].scPlotLines:
                    return True

            except:
                pass
        return False

    def get_message(self, source):
        return f'{_("Chapters belonging to plot line")}: "{source.novel.plotLines[self._plId].title}"'


class FilterFactory:

    @staticmethod
    def get_section_filter(filterElementId):
        if filterElementId.startswith(CHARACTER_PREFIX):
            return ScVpFilter(filterElementId)

        elif filterElementId.startswith(PLOT_LINE_PREFIX):
            return ScAcFilter(filterElementId)

        else:
            return Filter()

    @staticmethod
    def get_chapter_filter(filterElementId):
        if filterElementId.startswith(CHARACTER_PREFIX):
            return ChVpFilter(filterElementId)

        elif filterElementId.startswith(PLOT_LINE_PREFIX):
            return ChAcFilter(filterElementId)

        else:
            return Filter()


def sanitize_markdown(text):
    while '\n---' in text:
        text = text.replace('\n---', '\n???')
    text = text.replace('@@', '??')
    text = text.replace('%%', '??')
    while '\n\n' in text:
        text = text.replace('\n\n', '\n')
    text = text.replace('\n', '\n\n').strip()
    return text


class MdFile(FileExport):
    DESCRIPTION = 'Markdown file'
    EXTENSION = '.md'
    SUFFIX = ''
    SECTION_DIVIDER = '* * *'
    _fileHeader = '''**${Title}**  
  
*${AuthorName}*  
  
'''

    def _convert_from_mdnov(self, text, quick=False, append=False, firstInChapter=False):
        if text is None:
            return ''

        return sanitize_markdown(text)



class MdBriefSynopsis(MdFile):
    DESCRIPTION = _('Brief synopsis')
    SUFFIX = BRF_SYNOPSIS_SUFFIX

    _partTemplate = '\n# ${Title}\n\n'
    _chapterTemplate = '\n## ${Title}\n\n'
    _sectionTemplate = '${Title}\n\n'


class MdChapterDesc(MdFile):
    DESCRIPTION = _('Chapter descriptions')
    SUFFIX = CHAPTERS_SUFFIX

    _partTemplate = '\n# ${Title}\n\n'
    _chapterTemplate = '## ${Title}\n\n$Desc\n\n'



class MdCharacters(MdFile):
    DESCRIPTION = _('Character descriptions')
    SUFFIX = CHARACTERS_SUFFIX

    _fileHeader = f'{MdFile._fileHeader}# {DESCRIPTION}\n\n'
    _characterTemplate = f'''\n## $Title$FullName$AKA\n\n$Desc$Bio$Goals'''

    def _get_characterMapping(self, crId):
        characterMapping = super()._get_characterMapping(crId)
        if self.novel.characters[crId].aka:
            characterMapping['AKA'] = f' ("{self.novel.characters[crId].aka}")'
        else:
            characterMapping['AKA'] = ''
        if self.novel.characters[crId].fullName:
            characterMapping['FullName'] = f'/{self.novel.characters[crId].fullName}'
        else:
            characterMapping['FullName'] = ''
        if self.novel.characters[crId].desc:
            characterMapping['Desc'] = f'### {_("Description")}\n\n{self.novel.characters[crId].desc}\n\n'
        else:
            characterMapping['Desc'] = ''
        if self.novel.characters[crId].bio:
            characterMapping['Bio'] = f"### {characterMapping['CustomChrBio']}\n\n{self.novel.characters[crId].bio}\n\n"
        else:
            characterMapping['Bio'] = ''
        if self.novel.characters[crId].goals:
            characterMapping['Goals'] = f"### {characterMapping['CustomChrGoals']}\n\n{self.novel.characters[crId].goals}\n\n"
        else:
            characterMapping['Goals'] = ''

        return characterMapping


class MdExport(MdFile):
    DESCRIPTION = 'Markdown file'
    EXTENSION = '.md'
    SUFFIX = ''
    _partTemplate = '\n# ${Title}\n\n'
    _chapterTemplate = '\n## ${Title}\n\n'
    _sectionTemplate = '${SectionContent}\n\n'
    _sectionDivider = f'{MdFile.SECTION_DIVIDER}\n\n'



class MdItems(MdFile):
    DESCRIPTION = _('Item descriptions')
    SUFFIX = ITEMS_SUFFIX

    _fileHeader = f'{MdFile._fileHeader}# {DESCRIPTION}\n\n'
    _itemTemplate = '\n## $Title$AKA\n\n$Desc'

    def _get_itemMapping(self, itId):
        itemMapping = super()._get_itemMapping(itId)
        if self.novel.items[itId].aka:
            itemMapping['AKA'] = f' ("{self.novel.items[itId].aka}")'
        else:
            itemMapping['AKA'] = ''
        if self.novel.items[itId].desc:
            itemMapping['Desc'] = f'### {_("Description")}\n\n{self.novel.items[itId].desc}\n\n'
        else:
            itemMapping['Desc'] = ''
        return itemMapping


class MdLocations(MdFile):
    DESCRIPTION = _('Location descriptions')
    SUFFIX = LOCATIONS_SUFFIX

    _fileHeader = f'{MdFile._fileHeader}# {DESCRIPTION}\n\n'
    _locationTemplate = '\n## $Title$AKA\n\n$Desc'

    def _get_locationMapping(self, lcId):
        locationMapping = super()._get_locationMapping(lcId)
        if self.novel.locations[lcId].aka:
            locationMapping['AKA'] = f' ("{self.novel.locations[lcId].aka}")'
        else:
            locationMapping['AKA'] = ''
        if self.novel.locations[lcId].desc:
            locationMapping['Desc'] = f'### {_("Description")}\n\n{self.novel.locations[lcId].desc}\n\n'
        else:
            locationMapping['Desc'] = ''
        return locationMapping


class MdPartDesc(MdFile):
    DESCRIPTION = _('Part descriptions')
    SUFFIX = PARTS_SUFFIX

    _partTemplate = '# ${Title}\n\n$Desc\n\n'

from string import Template



class MdPlotlines(MdFile):
    DESCRIPTION = _('Plot lines')
    SUFFIX = PLOTLINES_SUFFIX

    _fileHeader = f'{MdFile._fileHeader}# {DESCRIPTION}\n\n'
    _arcHeadingTemplate = f'''# {_('Plot lines')}
'''

    _arcTemplate = '\n## $Title\n\n$Desc\n\n$TurningPoints\n\n'
    _plotPointTemplate = '### $Title\n\n$Desc'
    _assocSectionTemplate = '$Section: *$SectionTitle*'

    def write(self):
        self._firstPlotLine = True
        super().write()

    def _get_arcMapping(self, plId):
        arcMapping = super()._get_arcMapping(plId)
        if self._firstPlotLine:
            arcMapping['Heading'] = self._arcHeadingTemplate
            self._firstPlotLine = False
        else:
            arcMapping['Heading'] = ''
        plotPoints = []
        for ppId in self.novel.tree.get_children(plId):
            plotPointMapping = dict(
                ID=ppId,
                Title=self.novel.plotPoints[ppId].title,
                Desc=self._convert_from_mdnov(self.novel.plotPoints[ppId].desc),
            )
            template = Template(self._plotPointTemplate)
            plotPoints.append(template.safe_substitute(plotPointMapping))
            scId = self.novel.plotPoints[ppId].sectionAssoc
            if scId:
                sectionAssocMapping = dict(
                    SectionTitle=self.novel.sections[scId].title,
                    ProjectName=self._convert_from_mdnov(self.projectName, True),
                    Section=_('Section'),
                    Description=_('Description'),
                    Manuscript=_('Manuscript'),
                    scID=scId,
                    SectionsSuffix=SECTIONS_SUFFIX,
                )
                template = Template(self._assocSectionTemplate)
                plotPoints.append(template.safe_substitute(sectionAssocMapping))
        arcMapping['TurningPoints'] = '\n\n'.join(plotPoints)
        return arcMapping



class MdSectionDesc(MdFile):
    DESCRIPTION = _('Section descriptions')
    SUFFIX = SECTIONS_SUFFIX

    _partTemplate = '\n# ${Title}\n\n'
    _chapterTemplate = '\n## ${Title}\n\n'
    _sectionTemplate = '${Desc}\n\n'
    _sectionDivider = f'{MdFile.SECTION_DIVIDER}\n\n'

    def _get_sectionMapping(self, scId, sectionNumber, wordsTotal, **kwargs):
        sectionMapping = super()._get_sectionMapping(scId, sectionNumber, wordsTotal, **kwargs)
        sectionMapping['Manuscript'] = _('Manuscript')
        return sectionMapping


class MdStages(MdFile):
    DESCRIPTION = _('Story structure')
    SUFFIX = STAGES_SUFFIX

    _fileHeader = f'{MdFile._fileHeader}# {DESCRIPTION}\n\n'

    _stage1Template = '\n## $Title\n\n$Desc\n\n'
    _stage2Template = '\n### $Title\n\n$Desc\n\n'

from datetime import date
import webbrowser


prefs = {}

HELP_URL = 'https://peter88213.github.io/mdnovhelp-en/'
HOME_URL = 'https://github.com/peter88213/mdnovel/'
SC_EDITOR = _('Section Editor')
SC_EDITOR_ICON = 'eLogo32'


def to_string(text):
    if text is None:
        return ''

    return str(text)


def open_help(page):
    webbrowser.open(f'{HELP_URL}{page}')


def datestr(isoDate):
    if prefs['localize_date']:
        return date.fromisoformat(isoDate).strftime("%x")
    else:
        return isoDate


def get_section_date_str(section):
    if prefs['localize_date']:
        return section.localeDate
    else:
        return section.date
from tkinter import messagebox
from tkinter import ttk

import tkinter as tk


class SimpleDialog:

    def __init__(self, master,
                 text='', buttons=[], default=None, cancel=None,
                 title=None, class_=None):
        if class_:
            self.root = tk.Toplevel(master, class_=class_)
        else:
            self.root = tk.Toplevel(master)
        if title:
            self.root.title(title)
            self.root.iconname(title)

        _setup_dialog(self.root)

        self.message = tk.Message(self.root, text=text, aspect=400, bg='white')
        self.message.pack(expand=1, fill='both')
        self.frame = tk.Frame(self.root)
        self.frame.pack()
        self.num = default
        self.cancel = cancel
        self.default = default
        self.root.bind('<Return>', self.return_event)
        for num in range(len(buttons)):
            s = buttons[num]
            b = ttk.Button(
                self.frame,
                text=s,
                command=(lambda self=self, num=num: self.done(num))
                )
            if num == default:
                b.configure(default='active')
            b.pack(side='left', fill='both', expand=1, padx=5, pady=10)
        self.root.protocol('WM_DELETE_WINDOW', self.wm_delete_window)
        self.root.transient(master)
        _place_window(self.root, master)

    def go(self):
        self.root.wait_visibility()
        self.root.grab_set()
        self.root.mainloop()
        self.root.destroy()
        return self.num

    def return_event(self, event):
        if self.default is None:
            self.root.bell()
        else:
            self.done(self.default)

    def wm_delete_window(self):
        if self.cancel is None:
            self.root.bell()
        else:
            self.done(self.cancel)

    def done(self, num):
        self.num = num
        self.root.quit()


class Dialog(tk.Toplevel):


    def __init__(self, parent, title=None):
        master = parent
        tk.Toplevel.__init__(self, master)

        self.withdraw()  # remain invisible for now
        if parent is not None and parent.winfo_viewable():
            self.transient(parent)

        if title:
            self.title(title)

        _setup_dialog(self)

        self.parent = parent

        self.result = None

        body = tk.Frame(self)
        self.initial_focus = self.body(body)
        body.pack(padx=5, pady=5)

        self.buttonbox()

        if self.initial_focus is None:
            self.initial_focus = self

        self.protocol('WM_DELETE_WINDOW', self.cancel)

        _place_window(self, parent)

        self.initial_focus.focus_set()

        self.wait_visibility()
        self.grab_set()
        self.wait_window(self)

    def destroy(self):
        self.initial_focus = None
        tk.Toplevel.destroy(self)


    def body(self, master):
        pass

    def buttonbox(self):

        box = tk.Frame(self)

        w = ttk.Button(box, text=_('OK'), width=10, command=self.ok, default='active')
        w.pack(side='left', padx=5, pady=10)
        w = ttk.Button(box, text=_('Cancel'), width=10, command=self.cancel)
        w.pack(side='left', padx=5, pady=10)

        self.bind('<Return>', self.ok)
        self.bind('<Escape>', self.cancel)

        box.pack()


    def ok(self, event=None):

        if not self.validate():
            self.initial_focus.focus_set()  # put focus back
            return

        self.withdraw()
        self.update_idletasks()

        try:
            self.apply()
        finally:
            self.cancel()

    def cancel(self, event=None):

        if self.parent is not None:
            self.parent.focus_set()
        self.destroy()


    def validate(self):

        return 1  # override

    def apply(self):

        pass  # override


def _place_window(w, parent=None):
    w.wm_withdraw()  # Remain invisible while we figure out the geometry
    w.update_idletasks()  # Actualize geometry information

    minwidth = w.winfo_reqwidth()
    minheight = w.winfo_reqheight()
    maxwidth = w.winfo_vrootwidth()
    maxheight = w.winfo_vrootheight()
    if parent is not None and parent.winfo_ismapped():
        x = parent.winfo_rootx() + (parent.winfo_width() - minwidth) // 2
        y = parent.winfo_rooty() + (parent.winfo_height() - minheight) // 2
        vrootx = w.winfo_vrootx()
        vrooty = w.winfo_vrooty()
        x = min(x, vrootx + maxwidth - minwidth)
        x = max(x, vrootx)
        y = min(y, vrooty + maxheight - minheight)
        y = max(y, vrooty)
        if w._windowingsystem == 'aqua':
            y = max(y, 22)
    else:
        x = (w.winfo_screenwidth() - minwidth) // 2
        y = (w.winfo_screenheight() - minheight) // 2

    w.wm_maxsize(maxwidth, maxheight)
    w.wm_geometry('+%d+%d' % (x, y))
    w.wm_deiconify()  # Become visible at the desired location


def _setup_dialog(w):
    if w._windowingsystem == 'aqua':
        w.tk.call('::tk::unsupported::MacWindowStyle', 'style',
                  w, 'moveableModal', '')
    elif w._windowingsystem == 'x11':
        w.wm_attributes('-type', 'dialog')



class _QueryDialog(Dialog):

    def __init__(self, title, prompt,
                 initialvalue=None,
                 minvalue=None, maxvalue=None,
                 parent=None):

        self.prompt = prompt
        self.minvalue = minvalue
        self.maxvalue = maxvalue

        self.initialvalue = initialvalue

        Dialog.__init__(self, parent, title)

    def destroy(self):
        self.entry = None
        Dialog.destroy(self)

    def body(self, master):

        w = ttk.Label(master, text=self.prompt, justify='left')
        w.grid(row=0, padx=5, sticky='w')

        self.entry = ttk.Entry(master, name='entry')
        self.entry.grid(row=1, padx=5, pady=5, sticky='w' + 'e')

        if self.initialvalue is not None:
            self.entry.insert(0, self.initialvalue)
            self.entry.select_range(0, 'end')

        return self.entry

    def validate(self):
        try:
            result = self.getresult()
        except ValueError:
            messagebox.showwarning(
                _('Illegal value'),
                f'{self.errormessage}\n{_("Please try again")}.',
                parent=self
            )
            return 0

        if self.minvalue is not None and result < self.minvalue:
            messagebox.showwarning(
                _('Too small'),
                f'{_("The allowed minimum value is")} {self.minvalue}.\n{_("Please try again")}.',
                parent=self
            )
            return 0

        if self.maxvalue is not None and result > self.maxvalue:
            messagebox.showwarning(
                _('Too large'),
                f'{_("The allowed maximum value is")} {self.maxvalue}.\n{_("Please try again")}.',
                parent=self
            )
            return 0

        self.result = result

        return 1


class _QueryInteger(_QueryDialog):
    errormessage = _('Not an integer.')

    def getresult(self):
        return self.getint(self.entry.get())


def askinteger(title, prompt, **kw):
    d = _QueryInteger(title, prompt, **kw)
    return d.result


class _QueryFloat(_QueryDialog):
    errormessage = _('Not a floating point value.')

    def getresult(self):
        return self.getdouble(self.entry.get())


def askfloat(title, prompt, **kw):
    d = _QueryFloat(title, prompt, **kw)
    return d.result


class _QueryString(_QueryDialog):

    def __init__(self, *args, **kw):
        if 'show' in kw:
            self.__show = kw['show']
            del kw['show']
        else:
            self.__show = None
        _QueryDialog.__init__(self, *args, **kw)

    def body(self, master):
        entry = _QueryDialog.body(self, master)
        if self.__show is not None:
            entry.configure(show=self.__show)
        return entry

    def getresult(self):
        return self.entry.get()


def askstring(title, prompt, **kw):
    d = _QueryString(title, prompt, **kw)
    return d.result



class NvDocExporter:
    EXPORT_TARGET_CLASSES = [
        MdExport,
        CsvCharList,
        CsvGrid,
        CsvItemList,
        CsvLocList,
        CsvSectionList,
        MdBriefSynopsis,
        MdChapterDesc,
        MdCharacters,
        MdItems,
        MdLocations,
        MdPartDesc,
        MdPlotlines,
        MdSectionDesc,
        MdStages,
        ]

    def __init__(self, ui):
        self._ui = ui
        self.exportTargetFactory = ExportTargetFactory(self.EXPORT_TARGET_CLASSES)
        self._source = None
        self._target = None

    def run(self, source, suffix, **kwargs):
        self._source = source
        self._isNewer = False
        __, self._target = self.exportTargetFactory.make_file_objects(self._source.filePath, suffix=suffix)
        if os.path.isfile(self._target.filePath):
            targetTimestamp = os.path.getmtime(self._target.filePath)
            try:
                if  targetTimestamp > self._source.timestamp:
                    timeStatus = _('Newer than the project file')
                    self._isNewer = True
                    defaultButton = 1
                else:
                    timeStatus = _('Older than the project file')
                    defaultButton = 0
            except:
                timeStatus = ''
                defaultButton = 0
            self._targetFileDate = datetime.fromtimestamp(targetTimestamp).strftime('%c')
            title = _('Export document')
            message = _('{0} already exists.\n(last saved on {2})\n{1}.\n\nOpen this document instead of overwriting it?').format(
                        norm_path(self._target.DESCRIPTION), timeStatus, self._targetFileDate)
            askOverwrite = SimpleDialog(
                None,
                text=message,
                buttons=[_('Overwrite'), _('Open existing'), _('Cancel')],
                default=defaultButton,
                cancel=2,
                title=title
                )
            values = [False, True, None]
            openExisting = values[askOverwrite.go()]
            if openExisting is None:
                raise Error(f'{_("Action canceled by user")}.')

            elif openExisting:
                open_document(self._target.filePath)
                if self._isNewer:
                    prefix = ''
                else:
                    prefix = '!'
                return f'{prefix}{_("Opened existing {0} (last saved on {1})").format(self._target.DESCRIPTION, self._targetFileDate)}.'

        filterElementId = kwargs.get('filter', '')
        self._target.sectionFilter = FilterFactory.get_section_filter(filterElementId)
        self._target.chapterFilter = FilterFactory.get_chapter_filter(filterElementId)
        self._target.novel = self._source.novel
        self._target.write()
        self._targetFileDate = datetime.now().replace(microsecond=0).isoformat(sep=' ')
        if kwargs.get('show', True):
            askOpen = kwargs.get('ask', True) and prefs['ask_doc_open']
            if not askOpen or self._ui.ask_yes_no(
                _('{} created.\n\nOpen now?').format(norm_path(self._target.DESCRIPTION)),
                title=self._target.novel.title,
                ):
                open_document(self._target.filePath)
        return _('Created {0} on {1}.').format(self._target.DESCRIPTION, self._targetFileDate)


from html import escape


class HtmlReport(FileExport):
    DESCRIPTION = 'HTML report'
    EXTENSION = '.html'
    SUFFIX = '_report'

    _fileHeader = '''<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>

<style type="text/css">
body {font-family: sans-serif}
p.title {font-size: larger; font-weight: bold}
td {padding: 10}
tr.heading {font-size:smaller; font-weight: bold; background-color:rgb(240,240,240)}
table {border-spacing: 0}
table, td {border: rgb(240,240,240) solid 1px; vertical-align: top}
td.chtitle {font-weight: bold}
</style>

'''

    _fileFooter = '''</table>
</body>
</html>
'''

    def _convert_from_mdnov(self, text, quick=False, **kwargs):
        if not text:
            return ''

        text = escape(text.rstrip())
        if quick:
            return text.replace('\n', ' ')

        newlines = []
        for line in text.split('\n'):
            newlines.append(f'<p>{line}</p>')
        return '\n'.join(newlines)



class HtmlCharacters(HtmlReport):
    DESCRIPTION = 'HTML charcters report'
    EXTENSION = '.html'
    SUFFIX = CHARACTER_REPORT_SUFFIX

    _fileHeader = f'''{HtmlReport._fileHeader}
<title>{_('Characters')} ($Title)</title>
</head>

<body>
<p class=title>$Title {_('by')} $AuthorName - {_('Characters')}</p>
<table>
<tr class="heading">
<td class="chtitle">{_('Name')}</td>
<td>{_('Full name')}</td>
<td>{_('AKA')}</td>
<td>{_('Tags')}</td>
<td>{_('Description')}</td>
<td>$CustomChrBio</td>
<td>$CustomChrGoals</td>
<td>{_('Notes')}</td>
</tr>
'''

    _characterTemplate = '''<tr>
<td class="chtitle">$Title</td>
<td>$FullName</td>
<td>$AKA</td>
<td>$Tags</td>
<td>$Desc</td>
<td>$Bio</td>
<td>$Goals</td>
<td>$Notes</td>
</tr>
'''



class HtmlItems(HtmlReport):
    DESCRIPTION = 'HTML items report'
    EXTENSION = '.html'
    SUFFIX = ITEM_REPORT_SUFFIX

    _fileHeader = f'''{HtmlReport._fileHeader}
<title>{_('Items')} ($Title)</title>
</head>

<body>
<p class=title>$Title {_('by')} $AuthorName - {_('Items')}</p>
<table>
<tr class="heading">
<td class="chtitle">{_('Name')}</td>
<td>{_('AKA')}</td>
<td>{_('Tags')}</td>
<td>{_('Description')}</td>
</tr>
'''

    _itemTemplate = '''<tr>
<td class="chtitle">$Title</td>
<td>$AKA</td>
<td>$Tags</td>
<td>$Desc</td>
</tr>
'''



class HtmlLocations(HtmlReport):
    DESCRIPTION = 'HTML locations report'
    EXTENSION = '.html'
    SUFFIX = LOCATION_REPORT_SUFFIX

    _fileHeader = f'''{HtmlReport._fileHeader}
<title>{_('Locations')} ($Title)</title>
</head>

<body>
<p class=title>$Title {_('by')} $AuthorName - {_('Locations')}</p>
<table>
<tr class="heading">
<td class="chtitle">{_('Name')}</td>
<td>{_('AKA')}</td>
<td>{_('Tags')}</td>
<td>{_('Description')}</td>
</tr>
'''

    _locationTemplate = '''<tr>
<td class="chtitle">$Title</td>
<td>$AKA</td>
<td>$Tags</td>
<td>$Desc</td>
</tr>
'''



class HtmlPlotList(HtmlReport):
    DESCRIPTION = _('HTML Plot list')
    SUFFIX = PLOTLIST_SUFFIX

    def write(self):

        def create_cell(text, attr=''):
            return f'<td {attr}>{self._convert_from_novx(text)}</td>'

        htmlText = [self._fileHeader]
        htmlText.append(f'''<title>{self.novel.title}</title>
</head>
<body>
<p class=title>{self.novel.title} - {_("Plot")}</p>
<table>''')
        plotLineColors = (
            'LightSteelBlue',
            'Gold',
            'Coral',
            'YellowGreen',
            'MediumTurquoise',
            'Plum',
            )

        if self.novel.tree.get_children(PL_ROOT) is not None:
            plotLines = self.novel.tree.get_children(PL_ROOT)
        else:
            plotLines = []

        htmlText.append('<tr class="heading">')
        htmlText.append(create_cell(''))
        for i, plId in enumerate(plotLines):
            colorIndex = i % len(plotLineColors)
            htmlText.append(create_cell(self.novel.plotLines[plId].title, attr=f'style="background: {plotLineColors[colorIndex]}"'))
        htmlText.append('</tr>')

        for chId in self.novel.tree.get_children(CH_ROOT):
            for scId in self.novel.tree.get_children(chId):
                if self.novel.sections[scId].scType == 0:
                    htmlText.append(f'<tr>')
                    htmlText.append(create_cell(self.novel.sections[scId].title))
                    for i, plId in enumerate(plotLines):
                        colorIndex = i % len(plotLineColors)
                        if scId in self.novel.plotLines[plId].sections:
                            plotPoints = []
                            for ppId in self.novel.tree.get_children(plId):
                                if scId == self.novel.plotPoints[ppId].sectionAssoc:
                                    plotPoints.append(self.novel.plotPoints[ppId].title)
                            htmlText.append(create_cell(list_to_string(plotPoints), attr=f'style="background: {plotLineColors[colorIndex]}"'))
                        else:
                            htmlText.append(create_cell(''))
                    htmlText.append(f'</tr>')

        htmlText.append(self._fileFooter)
        with open(self.filePath, 'w', encoding='utf-8') as f:
            f.write('\n'.join(htmlText))


class HtmlProjectNotes(HtmlReport):
    DESCRIPTION = 'HTML project notes report'
    EXTENSION = '.html'
    SUFFIX = PROJECTNOTES_SUFFIX

    _fileHeader = f'''{HtmlReport._fileHeader}
<title>{_('Project notes')} ($Title)</title>
</head>

<body>
<p class=title>$Title {_('by')} $AuthorName - {_('Project notes')}</p>
<table>
<tr class="heading">
<td class="chtitle">{_('Title')}</td>
<td>{_('Text')}</td>
</tr>
'''

    _projectNoteTemplate = '''<tr>
<td class="chtitle">$Title</td>
<td>$Desc</td>
</tr>
'''



class NvHtmlReporter:
    EXPORT_TARGET_CLASSES = [
        HtmlCharacters,
        HtmlLocations,
        HtmlItems,
        HtmlPlotList,
        HtmlProjectNotes,
        ]

    def __init__(self):
        self._exportTargetFactory = ExportTargetFactory(self.EXPORT_TARGET_CLASSES)

    def run(self, source, suffix, tempdir='.'):
        kwargs = {'suffix':suffix}
        __, target = self._exportTargetFactory.make_file_objects(source.filePath, **kwargs)
        __, filename = os.path.split(target.filePath)
        target.filePath = f'{tempdir}/{filename}'
        target.novel = source.novel
        target.write()
        open_document(target.filePath)




class ImportSourceFactory(FileFactory):

    def make_file_objects(self, sourcePath, **kwargs):
        for fileClass in self._fileClasses:
            if fileClass.SUFFIX is not None:
                if sourcePath.endswith(f'{fileClass.SUFFIX }{fileClass.EXTENSION}'):
                    sourceFile = fileClass(sourcePath, **kwargs)
                    return sourceFile, None

        raise Error(f'{_("This document is not meant to be written back")}.')



class ImportTargetFactory(FileFactory):

    def make_file_objects(self, sourcePath, **kwargs):
        fileName, __ = os.path.splitext(sourcePath)
        sourceSuffix = kwargs['suffix']
        if sourceSuffix:
            e = fileName.split(sourceSuffix)
            if len(e) > 1:
                e.pop()
            ywPathBasis = ''.join(e)
        else:
            ywPathBasis = fileName

        for fileClass in self._fileClasses:
            if os.path.isfile(f'{ywPathBasis}{fileClass.EXTENSION}'):
                targetFile = fileClass(f'{ywPathBasis}{fileClass.EXTENSION}', **kwargs)
                return None, targetFile

        raise Error(f'{_("No mdnovel project to write")}.')



class Chapter(BasicElementNotes):

    def __init__(self,
            chLevel=None,
            chType=None,
            noNumber=None,
            isTrash=None,
            **kwargs):
        super().__init__(**kwargs)
        self._chLevel = chLevel
        self._chType = chType
        self._noNumber = noNumber
        self._isTrash = isTrash

    @property
    def chLevel(self):
        return self._chLevel

    @chLevel.setter
    def chLevel(self, newVal):
        if newVal is not None:
            assert type(newVal) == int
        if self._chLevel != newVal:
            self._chLevel = newVal
            self.on_element_change()

    @property
    def chType(self):
        return self._chType

    @chType.setter
    def chType(self, newVal):
        if newVal is not None:
            assert type(newVal) == int
        if self._chType != newVal:
            self._chType = newVal
            self.on_element_change()

    @property
    def noNumber(self):
        return self._noNumber

    @noNumber.setter
    def noNumber(self, newVal):
        if newVal is not None:
            assert type(newVal) == bool
        if self._noNumber != newVal:
            self._noNumber = newVal
            self.on_element_change()

    @property
    def isTrash(self):
        return self._isTrash

    @isTrash.setter
    def isTrash(self, newVal):
        if newVal is not None:
            assert type(newVal) == bool
        if self._isTrash != newVal:
            self._isTrash = newVal
            self.on_element_change()

    def from_yaml(self, yaml):
        super().from_yaml(yaml)
        typeStr = self._get_meta_value('type', '0')
        if typeStr in ('0', '1'):
            self.chType = int(typeStr)
        else:
            self.chType = 1
        chLevel = self._get_meta_value('level', None)
        if chLevel == '1':
            self.chLevel = 1
        else:
            self.chLevel = 2
        self.isTrash = self._get_meta_value('isTrash', None) == '1'
        self.noNumber = self._get_meta_value('noNumber', None) == '1'

    def to_yaml(self, yaml):
        yaml = super().to_yaml(yaml)
        if self.chType:
            yaml.append(f'type: {self.chType}')
        if self.chLevel == 1:
            yaml.append(f'level: 1')
        if self.isTrash:
            yaml.append(f'isTrash: 1')
        if self.noNumber:
            yaml.append(f'noNumber: 1')
        return yaml


def create_id(elements, prefix=''):
    i = 1
    while f'{prefix}{i}' in elements:
        i += 1
    return f'{prefix}{i}'



class MdImport(MdFile):

    def read(self):
        LOW_WORDCOUNT = 10

        def write_section_content(scId, lines):
            if scId is not None:
                text = '\n\n'.join(lines)
                self.novel.sections[scId].sectionContent = text
                if self.novel.sections[scId].wordCount < LOW_WORDCOUNT:
                    self.novel.sections[scId].status = 1
                else:
                    self.novel.sections[scId].status = 2

        chCount = 0
        scCount = 0
        lines = []
        chId = None
        scId = None
        try:
            with open(self.filePath, 'r', encoding='utf-8') as f:
                mdText = f.read()
        except(FileNotFoundError):
            raise Error(f'{_("File not found")}: "{norm_path(self.filePath)}".')

        except:
            try:
                with open(self.filePath, 'r') as f:
                    mdText = f.read()
            except:
                raise Error(f'{_("Cannot read file")}: "{norm_path(self.filePath)}".')

        cnvText = mdText
        mdLines = cnvText.split('\n')
        for mdLine in mdLines:
            if mdLine.startswith('#'):

                write_section_content(scId, lines)
                scId = None

                chCount += 1
                chId = create_id(self.novel.chapters, CHAPTER_PREFIX)
                self.novel.chapters[chId] = Chapter()
                chTitle = mdLine.split('# ')[1]
                self.novel.chapters[chId].title = chTitle
                self.novel.tree.append(CH_ROOT, chId)
                self.novel.chapters[chId].chType = 0
                if mdLine.startswith('# '):
                    self.novel.chapters[chId].chLevel = 1
                else:
                    self.novel.chapters[chId].chLevel = 0
            elif self.SECTION_DIVIDER in mdLine:
                write_section_content(scId, lines)
                scId = None
            elif scId is not None:
                if mdLine or lines:
                    lines.append(mdLine)
            elif mdLine and chId is not None:
                scCount += 1
                scId = create_id(self.novel.sections, SECTION_PREFIX)
                self.novel.sections[scId] = Section(
                    status=1,
                    scType=0,
                    scene=0,
                    )
                self.novel.tree.append(chId, scId)
                self.novel.sections[scId].title = f'{_("Section")} {scCount}'
                lines = [mdLine]
        write_section_content(scId, lines)


class MdOutline(MdFile):

    def read(self):

        def write_desc(element, lines):
            newlines = []
            for line in lines:
                newlines.append(line)
            text = ''.join(newlines)
            text = text.replace('\n', '')
            element.desc = text

        chCount = 0
        scCount = 0
        lines = []
        chId = None
        scId = None
        try:
            with open(self.filePath, 'r', encoding='utf-8') as f:
                mdText = f.read()
        except(FileNotFoundError):
            raise Error(f'{_("File not found")}: "{norm_path(self.filePath)}".')

        except:
            try:
                with open(self.filePath, 'r') as f:
                    mdText = f.read()
            except:
                raise Error(f'{_("Cannot read file")}: "{norm_path(self.filePath)}".')

        cnvText = mdText
        mdLines = cnvText.split('\n')
        scTitle = None
        for mdLine in mdLines:
            if mdLine.startswith('# ') or mdLine.startswith('## '):
                if scId is not None:
                    write_desc(self.novel.sections[scId], lines)
                    scId = None

                elif chId is not None:
                    write_desc(self.novel.chapters[chId], lines)
                    scId = None

                chCount += 1
                chId = create_id(self.novel.chapters, CHAPTER_PREFIX)
                self.novel.chapters[chId] = Chapter()
                chTitle = mdLine.split('# ')[1]
                self.novel.chapters[chId].title = chTitle
                self.novel.tree.append(CH_ROOT, chId)
                self.novel.chapters[chId].chType = 0
                if mdLine.startswith('# '):
                    self.novel.chapters[chId].chLevel = 1
                else:
                    self.novel.chapters[chId].chLevel = 0
                scTitle = None
                lines = []
            elif mdLine.startswith('### '):
                if scId is not None:
                    write_desc(self.novel.sections[scId], lines)
                elif chId is not None:
                    write_desc(self.novel.chapters[chId], lines)
                scTitle = mdLine.lstrip('### ').strip()
                lines = []

                scCount += 1
                scId = create_id(self.novel.sections, SECTION_PREFIX)
                self.novel.sections[scId] = Section(
                    status=1,
                    scType=0,
                    scene=0,
                    )
                self.novel.tree.append(chId, scId)
                self.novel.sections[scId].title = f'Section {scCount}'
                if scTitle is not None:
                    self.novel.sections[scId].title = scTitle
            elif mdLine or lines:
                lines.append(mdLine)
        if scId is not None:
            write_desc(self.novel.sections[scId], lines)
        elif chId is not None:
            write_desc(self.novel.chapters[chId], lines)
from datetime import date

from datetime import date



class Novel(BasicElement):

    def __init__(self,
            authorName=None,
            wordTarget=None,
            wordCountStart=None,
            renumberChapters=None,
            renumberParts=None,
            renumberWithinParts=None,
            romanChapterNumbers=None,
            romanPartNumbers=None,
            saveWordCount=None,
            workPhase=None,
            chapterHeadingPrefix=None,
            chapterHeadingSuffix=None,
            partHeadingPrefix=None,
            partHeadingSuffix=None,
            customPlotProgress=None,
            customCharacterization=None,
            customWorldBuilding=None,
            customGoal=None,
            customConflict=None,
            customOutcome=None,
            customChrBio=None,
            customChrGoals=None,
            referenceDate=None,
            tree=None,
            **kwargs):
        super().__init__(**kwargs)
        self._authorName = authorName
        self._wordTarget = wordTarget
        self._wordCountStart = wordCountStart
        self._renumberChapters = renumberChapters
        self._renumberParts = renumberParts
        self._renumberWithinParts = renumberWithinParts
        self._romanChapterNumbers = romanChapterNumbers
        self._romanPartNumbers = romanPartNumbers
        self._saveWordCount = saveWordCount
        self._workPhase = workPhase
        self._chapterHeadingPrefix = chapterHeadingPrefix
        self._chapterHeadingSuffix = chapterHeadingSuffix
        self._partHeadingPrefix = partHeadingPrefix
        self._partHeadingSuffix = partHeadingSuffix
        self._customPlotProgress = customPlotProgress
        self._customCharacterization = customCharacterization
        self._customWorldBuilding = customWorldBuilding
        self._customGoal = customGoal
        self._customConflict = customConflict
        self._customOutcome = customOutcome
        self._customChrBio = customChrBio
        self._customChrGoals = customChrGoals

        self.chapters = {}
        self.sections = {}
        self.plotPoints = {}
        self.languages = None
        self.plotLines = {}
        self.locations = {}
        self.items = {}
        self.characters = {}
        self.projectNotes = {}
        try:
            self.referenceWeekDay = date.fromisoformat(referenceDate).weekday()
            self._referenceDate = referenceDate
        except:
            self.referenceWeekDay = None
            self._referenceDate = None
        self.tree = tree

    @property
    def authorName(self):
        return self._authorName

    @authorName.setter
    def authorName(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._authorName != newVal:
            self._authorName = newVal
            self.on_element_change()

    @property
    def wordTarget(self):
        return self._wordTarget

    @wordTarget.setter
    def wordTarget(self, newVal):
        if newVal is not None:
            assert type(newVal) == int
        if self._wordTarget != newVal:
            self._wordTarget = newVal
            self.on_element_change()

    @property
    def wordCountStart(self):
        return self._wordCountStart

    @wordCountStart.setter
    def wordCountStart(self, newVal):
        if newVal is not None:
            assert type(newVal) == int
        if self._wordCountStart != newVal:
            self._wordCountStart = newVal
            self.on_element_change()

    @property
    def renumberChapters(self):
        return self._renumberChapters

    @renumberChapters.setter
    def renumberChapters(self, newVal):
        if newVal is not None:
            assert type(newVal) == bool
        if self._renumberChapters != newVal:
            self._renumberChapters = newVal
            self.on_element_change()

    @property
    def renumberParts(self):
        return self._renumberParts

    @renumberParts.setter
    def renumberParts(self, newVal):
        if newVal is not None:
            assert type(newVal) == bool
        if self._renumberParts != newVal:
            self._renumberParts = newVal
            self.on_element_change()

    @property
    def renumberWithinParts(self):
        return self._renumberWithinParts

    @renumberWithinParts.setter
    def renumberWithinParts(self, newVal):
        if newVal is not None:
            assert type(newVal) == bool
        if self._renumberWithinParts != newVal:
            self._renumberWithinParts = newVal
            self.on_element_change()

    @property
    def romanChapterNumbers(self):
        return self._romanChapterNumbers

    @romanChapterNumbers.setter
    def romanChapterNumbers(self, newVal):
        if newVal is not None:
            assert type(newVal) == bool
        if self._romanChapterNumbers != newVal:
            self._romanChapterNumbers = newVal
            self.on_element_change()

    @property
    def romanPartNumbers(self):
        return self._romanPartNumbers

    @romanPartNumbers.setter
    def romanPartNumbers(self, newVal):
        if newVal is not None:
            assert type(newVal) == bool
        if self._romanPartNumbers != newVal:
            self._romanPartNumbers = newVal
            self.on_element_change()

    @property
    def saveWordCount(self):
        return self._saveWordCount

    @saveWordCount.setter
    def saveWordCount(self, newVal):
        if newVal is not None:
            assert type(newVal) == bool
        if self._saveWordCount != newVal:
            self._saveWordCount = newVal
            self.on_element_change()

    @property
    def workPhase(self):
        return self._workPhase

    @workPhase.setter
    def workPhase(self, newVal):
        if newVal is not None:
            assert type(newVal) == int
        if self._workPhase != newVal:
            self._workPhase = newVal
            self.on_element_change()

    @property
    def chapterHeadingPrefix(self):
        return self._chapterHeadingPrefix

    @chapterHeadingPrefix.setter
    def chapterHeadingPrefix(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._chapterHeadingPrefix != newVal:
            self._chapterHeadingPrefix = newVal
            self.on_element_change()

    @property
    def chapterHeadingSuffix(self):
        return self._chapterHeadingSuffix

    @chapterHeadingSuffix.setter
    def chapterHeadingSuffix(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._chapterHeadingSuffix != newVal:
            self._chapterHeadingSuffix = newVal
            self.on_element_change()

    @property
    def partHeadingPrefix(self):
        return self._partHeadingPrefix

    @partHeadingPrefix.setter
    def partHeadingPrefix(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._partHeadingPrefix != newVal:
            self._partHeadingPrefix = newVal
            self.on_element_change()

    @property
    def partHeadingSuffix(self):
        return self._partHeadingSuffix

    @partHeadingSuffix.setter
    def partHeadingSuffix(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._partHeadingSuffix != newVal:
            self._partHeadingSuffix = newVal
            self.on_element_change()

    @property
    def customPlotProgress(self):
        return self._customPlotProgress

    @customPlotProgress.setter
    def customPlotProgress(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._customPlotProgress != newVal:
            self._customPlotProgress = newVal
            self.on_element_change()

    @property
    def customCharacterization(self):
        return self._customCharacterization

    @customCharacterization.setter
    def customCharacterization(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._customCharacterization != newVal:
            self._customCharacterization = newVal
            self.on_element_change()

    @property
    def customWorldBuilding(self):
        return self._customWorldBuilding

    @customWorldBuilding.setter
    def customWorldBuilding(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._customWorldBuilding != newVal:
            self._customWorldBuilding = newVal
            self.on_element_change()

    @property
    def customGoal(self):
        return self._customGoal

    @customGoal.setter
    def customGoal(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._customGoal != newVal:
            self._customGoal = newVal
            self.on_element_change()

    @property
    def customConflict(self):
        return self._customConflict

    @customConflict.setter
    def customConflict(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._customConflict != newVal:
            self._customConflict = newVal
            self.on_element_change()

    @property
    def customOutcome(self):
        return self._customOutcome

    @customOutcome.setter
    def customOutcome(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._customOutcome != newVal:
            self._customOutcome = newVal
            self.on_element_change()

    @property
    def customChrBio(self):
        return self._customChrBio

    @customChrBio.setter
    def customChrBio(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._customChrBio != newVal:
            self._customChrBio = newVal
            self.on_element_change()

    @property
    def customChrGoals(self):
        return self._customChrGoals

    @customChrGoals.setter
    def customChrGoals(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._customChrGoals != newVal:
            self._customChrGoals = newVal
            self.on_element_change()

    @property
    def referenceDate(self):
        return self._referenceDate

    @referenceDate.setter
    def referenceDate(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._referenceDate != newVal:
            if not newVal:
                self._referenceDate = None
                self.referenceWeekDay = None
                self.on_element_change()
            else:
                try:
                    self.referenceWeekDay = date.fromisoformat(newVal).weekday()
                except:
                    pass
                else:
                    self._referenceDate = newVal
                    self.on_element_change()

    def from_yaml(self, yaml):
        super().from_yaml(yaml)
        self.renumberChapters = self._get_meta_value('renumberChapters', None) == '1'
        self.renumberParts = self._get_meta_value('renumberParts', None) == '1'
        self.renumberWithinParts = self._get_meta_value('renumberWithinParts', None) == '1'
        self.romanChapterNumbers = self._get_meta_value('romanChapterNumbers', None) == '1'
        self.romanPartNumbers = self._get_meta_value('romanPartNumbers', None) == '1'
        self.saveWordCount = self._get_meta_value('saveWordCount', None) == '1'
        workPhase = self._get_meta_value('workPhase', None)
        if workPhase in ('1', '2', '3', '4', '5'):
            self.workPhase = int(workPhase)
        else:
            self.workPhase = None

        self.authorName = self._get_meta_value('Author')

        chapterHeadingPrefix = self._get_meta_value('ChapterHeadingPrefix')
        if chapterHeadingPrefix:
            chapterHeadingPrefix = chapterHeadingPrefix[1:-1]
        self.chapterHeadingPrefix = chapterHeadingPrefix

        chapterHeadingSuffix = self._get_meta_value('ChapterHeadingSuffix')
        if chapterHeadingSuffix:
            chapterHeadingSuffix = chapterHeadingSuffix[1:-1]
        self.chapterHeadingSuffix = chapterHeadingSuffix

        partHeadingPrefix = self._get_meta_value('PartHeadingPrefix')
        if partHeadingPrefix:
            partHeadingPrefix = partHeadingPrefix[1:-1]
        self.partHeadingPrefix = partHeadingPrefix

        partHeadingSuffix = self._get_meta_value('PartHeadingSuffix')
        if partHeadingSuffix:
            partHeadingSuffix = partHeadingSuffix[1:-1]
        self.partHeadingSuffix = partHeadingSuffix

        self.customPlotProgress = self._get_meta_value('CustomPlotProgress')
        self.customCharacterization = self._get_meta_value('CustomCharacterization')
        self.customWorldBuilding = self._get_meta_value('CustomWorldBuilding')

        self.customGoal = self._get_meta_value('CustomGoal')
        self.customConflict = self._get_meta_value('CustomConflict')
        self.customOutcome = self._get_meta_value('CustomOutcome')

        self.customChrBio = self._get_meta_value('CustomChrBio')
        self.customChrGoals = self._get_meta_value('CustomChrGoals')

        ws = self._get_meta_value('WordCountStart')
        if ws is not None:
            self.wordCountStart = int(ws)
        wt = self._get_meta_value('WordTarget')
        if wt is not None:
            self.wordTarget = int(wt)

        self.referenceDate = verified_date(self._get_meta_value('ReferenceDate'))

    def to_yaml(self, yaml):
        yaml = super().to_yaml(yaml)
        if self.renumberChapters:
            yaml.append(f'renumberChapters: 1')
        if self.renumberParts:
            yaml.append(f'renumberParts: 1')
        if self.renumberWithinParts:
            yaml.append(f'renumberWithinParts: 1')
        if self.romanChapterNumbers:
            yaml.append(f'romanChapterNumbers: 1')
        if self.romanPartNumbers:
            yaml.append(f'romanPartNumbers: 1')
        if self.saveWordCount:
            yaml.append(f'saveWordCount: 1')
        if self.workPhase is not None:
            yaml.append(f'workPhase: {self.workPhase}')

        if self.authorName:
            yaml.append(f'Author: {self.authorName}')

        if self.chapterHeadingPrefix:
            yaml.append(f'ChapterHeadingPrefix: "{self.chapterHeadingPrefix}"')
        if self.chapterHeadingSuffix:
            yaml.append(f'ChapterHeadingSuffix: "{self.chapterHeadingSuffix}"')

        if self.partHeadingPrefix:
            yaml.append(f'PartHeadingPrefix: "{self.partHeadingPrefix}"')
        if self.partHeadingSuffix:
            yaml.append(f'PartHeadingSuffix: "{self.partHeadingSuffix}"')

        if self.customPlotProgress:
            yaml.append(f'CustomPlotProgress: {self.customPlotProgress}')
        if self.customCharacterization:
            yaml.append(f'CustomCharacterization: {self.customCharacterization}')
        if self.customWorldBuilding:
            yaml.append(f'CustomWorldBuilding: {self.customWorldBuilding}')

        if self.customGoal:
            yaml.append(f'CustomGoal: {self.customGoal}')
        if self.customConflict:
            yaml.append(f'CustomConflict: {self.customConflict}')
        if self.customOutcome:
            yaml.append(f'CustomOutcome: {self.customOutcome}')

        if self.customChrBio:
            yaml.append(f'CustomChrBio: {self.customChrBio}')
        if self.customChrGoals:
            yaml.append(f'CustomChrGoals: {self.customChrGoals}')

        if self.wordCountStart:
            yaml.append(f'WordCountStart: {self.wordCountStart}')
        if self.wordTarget:
            yaml.append(f'WordTarget: {self.wordTarget}')

        if self.referenceDate:
            yaml.append(f'ReferenceDate: {self.referenceDate}')
        return yaml

    def update_plot_lines(self):
        for scId in self.sections:
            self.sections[scId].scPlotPoints = {}
            self.sections[scId].scPlotLines = []
            for plId in self.plotLines:
                if scId in self.plotLines[plId].sections:
                    self.sections[scId].scPlotLines.append(plId)
                    for ppId in self.tree.get_children(plId):
                        if self.plotPoints[ppId].sectionAssoc == scId:
                            self.sections[scId].scPlotPoints[ppId] = plId
                            break



class PlotLine(BasicElementNotes):

    def __init__(self,
            shortName=None,
            sections=None,
            **kwargs):
        super().__init__(**kwargs)

        self._shortName = shortName
        self._sections = sections

    @property
    def shortName(self):
        return self._shortName

    @shortName.setter
    def shortName(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._shortName != newVal:
            self._shortName = newVal
            self.on_element_change()

    @property
    def sections(self):
        try:
            return self._sections[:]
        except TypeError:
            return None

    @sections.setter
    def sections(self, newVal):
        if newVal is not None:
            for elem in newVal:
                if elem is not None:
                    assert type(elem) == str
        if self._sections != newVal:
            self._sections = newVal
            self.on_element_change()

    def from_yaml(self, yaml):
        super().from_yaml(yaml)
        self.shortName = self._get_meta_value('ShortName')
        plSections = self._get_meta_value('Sections')
        self.sections = string_to_list(plSections)

    def to_yaml(self, yaml):
        yaml = super().to_yaml(yaml)
        if self.shortName:
            yaml.append(f'ShortName: {self.shortName}')
        if self.sections:
            yaml.append(f'Sections: {list_to_string(self.sections)}')
        return yaml


class PlotPoint(BasicElementNotes):

    def __init__(self,
            sectionAssoc=None,
            **kwargs):
        super().__init__(**kwargs)

        self._sectionAssoc = sectionAssoc

    @property
    def sectionAssoc(self):
        return self._sectionAssoc

    @sectionAssoc.setter
    def sectionAssoc(self, newVal):
        if newVal is not None:
            assert type(newVal) == str
        if self._sectionAssoc != newVal:
            self._sectionAssoc = newVal
            self.on_element_change()

    def from_yaml(self, yaml):
        super().from_yaml(yaml)
        self.sectionAssoc = self._get_meta_value('Section')

    def to_yaml(self, yaml):
        yaml = super().to_yaml(yaml)
        if self.sectionAssoc:
            yaml.append(f'Section: {self.sectionAssoc}')
        return yaml


class MdnovFile(MdFile):
    DESCRIPTION = _('mdnovel project')
    EXTENSION = '.mdnov'

    _fileHeader = '''@@book
    
---
$YAML
---


$Links
%%

'''
    _chapterTemplate = '''
@@$ID
    
---
$YAML
---

$Links$Desc$Notes
%%

'''
    _partTemplate = _chapterTemplate
    _unusedChapterTemplate = _chapterTemplate
    _sectionTemplate = '''
@@$ID
    
---
$YAML
---

$Links$Desc$Notes$Goal$Conflict$Outcome$Plotlines$SectionContent%%
'''
    _unusedSectionTemplate = _sectionTemplate
    _stage1Template = _sectionTemplate
    _stage2Template = _sectionTemplate
    _sectionDivider = ''
    _chapterEndTemplate = ''
    _unusedChapterEndTemplate = ''
    _characterSectionHeading = ''
    _characterTemplate = '''
@@$ID
    
---
$YAML
---

$Links$Desc$Bio$Goals
%%

'''
    _locationSectionHeading = ''
    _locationTemplate = '''
@@$ID
    
---
$YAML
---

$Links$Desc
%%

'''
    _itemSectionHeading = ''
    _itemTemplate = _locationTemplate
    _projectNoteTemplate = _locationTemplate
    _arcTemplate = '''
@@$ID
    
---
$YAML
---

$Links$Desc
%%

'''
    _fileFooter = '\n$Wordcountlog\n\n%%'

    def __init__(self, filePath, **kwargs):
        super().__init__(filePath)
        self.on_element_change = None

        self.wcLog = {}

        self.wcLogUpdate = {}

        self.timestamp = None
        self._range = None
        self._collectedLines = None
        self._properties = {}
        self._plId = None

    def adjust_section_types(self):
        partType = 0
        for chId in self.novel.tree.get_children(CH_ROOT):
            if self.novel.chapters[chId].chLevel == 1:
                partType = self.novel.chapters[chId].chType
            elif partType != 0 and not self.novel.chapters[chId].isTrash:
                self.novel.chapters[chId].chType = partType
            for scId in self.novel.tree.get_children(chId):
                if self.novel.sections[scId].scType < self.novel.chapters[chId].chType:
                    self.novel.sections[scId].scType = self.novel.chapters[chId].chType

    def count_words(self):
        count = 0
        totalCount = 0
        for chId in self.novel.tree.get_children(CH_ROOT):
            if not self.novel.chapters[chId].isTrash:
                for scId in self.novel.tree.get_children(chId):
                    if self.novel.sections[scId].scType < 2:
                        totalCount += self.novel.sections[scId].wordCount
                        if self.novel.sections[scId].scType == 0:
                            count += self.novel.sections[scId].wordCount
        return count, totalCount

    def read(self):
        with open(self.filePath, 'r', encoding='utf-8') as f:
            lines = f.read().split('\n')
        processor = None
        elemId = None
        chId = None
        self._collectedLines = None
        self.novel.tree.reset()
        for self._line in lines:
            if self._line.startswith('@@book'):
                processor = self._read_project
                elemId = None
                element = self.novel
                continue

            if self._line.startswith(f'@@{CHAPTER_PREFIX}'):
                processor = self._read_chapter
                elemId = self._line.split('@@')[1].strip()
                self.novel.chapters[elemId] = Chapter(on_element_change=self.on_element_change)
                self.novel.tree.append(CH_ROOT, elemId)
                element = self.novel.chapters[elemId]
                chId = elemId
                continue

            if self._line.startswith(f'@@{CHARACTER_PREFIX}'):
                processor = self._read_character
                elemId = self._line.split('@@')[1].strip()
                self.novel.characters[elemId] = Character(on_element_change=self.on_element_change)
                self.novel.tree.append(CR_ROOT, elemId)
                element = self.novel.characters[elemId]
                continue

            if self._line.startswith(f'@@{ITEM_PREFIX}'):
                processor = self._read_world_element
                elemId = self._line.split('@@')[1].strip()
                self.novel.items[elemId] = WorldElement(on_element_change=self.on_element_change)
                self.novel.tree.append(IT_ROOT, elemId)
                element = self.novel.items[elemId]
                continue

            if self._line.startswith(f'@@{LOCATION_PREFIX}'):
                processor = self._read_world_element
                elemId = self._line.split('@@')[1].strip()
                self.novel.locations[elemId] = WorldElement(on_element_change=self.on_element_change)
                self.novel.tree.append(LC_ROOT, elemId)
                element = self.novel.locations[elemId]
                continue

            if self._line.startswith(f'@@{PLOT_LINE_PREFIX}'):
                processor = self._read_plot_line
                elemId = self._line.split('@@')[1].strip()
                self.novel.plotLines[elemId] = PlotLine(on_element_change=self.on_element_change)
                self.novel.tree.append(PL_ROOT, elemId)
                element = self.novel.plotLines[elemId]
                plId = elemId
                continue

            if self._line.startswith(f'@@{PLOT_POINT_PREFIX}'):
                processor = self._read_plot_point
                elemId = self._line.split('@@')[1].strip()
                self.novel.plotPoints[elemId] = PlotPoint(on_element_change=self.on_element_change)
                self.novel.tree.append(plId, elemId)
                element = (self.novel.plotPoints[elemId])
                continue

            if self._line.startswith(f'@@{PRJ_NOTE_PREFIX}'):
                processor = self._read_project_note
                elemId = self._line.split('@@')[1].strip()
                self.novel.projectNotes[elemId] = BasicElement()
                self.novel.tree.append(PN_ROOT, elemId)
                element = self.novel.projectNotes[elemId]
                continue

            if self._line.startswith(f'@@{SECTION_PREFIX}'):
                processor = self._read_section
                elemId = self._line.split('@@')[1].strip()
                self.novel.sections[elemId] = Section(on_element_change=self.on_element_change)
                self.novel.tree.append(chId, elemId)
                element = self.novel.sections[elemId]
                continue

            if self._line.startswith(f'@@Progress'):
                processor = self._read_word_count_log
                elemId = None
                continue

            if processor is not None:
                processor(element)

        for scId in self.novel.sections:

            self.novel.sections[scId].characters = intersection(self.novel.sections[scId].characters, self.novel.characters)
            self.novel.sections[scId].locations = intersection(self.novel.sections[scId].locations, self.novel.locations)
            self.novel.sections[scId].items = intersection(self.novel.sections[scId].items, self.novel.items)

        for ppId in self.novel.plotPoints:

            scId = self.novel.plotPoints[ppId].sectionAssoc
            if scId in self.novel.sections:
                self.novel.sections[scId].scPlotPoints[ppId] = plId
            else:
                self.novel.plotPoints[ppId].sectionAssoc = None

        for plId in self.novel.plotLines:

            self.novel.plotLines[plId].sections = intersection(self.novel.plotLines[plId].sections, self.novel.sections)

            for scId in self.novel.plotLines[plId].sections:
                self.novel.sections[scId].scPlotLines.append(plId)

        self._get_timestamp()
        self._keep_word_count()

    def write(self):
        self._update_word_count_log()
        self.adjust_section_types()
        super().write()
        self._get_timestamp()

    def _add_key(self, text, key):
        if not key:
            return ''

        if not text:
            return ''

        return f'%%{key}:\n\n{sanitize_markdown(text)}\n\n'

    def _add_links(self, element, mapping):
        links = element.get_links()
        linkRepr = []
        if links:
            for relativeLink, absoluteLink in links:
                linkRepr.append('%%Link:')
                linkRepr.append(relativeLink)
                linkRepr.append(absoluteLink)
        links = '\n\n'.join(linkRepr)
        mapping['Links'] = f'{links}\n'
        return mapping

    def _add_plotline_notes(self, prjScn, mapping):
        plRepr = []
        if prjScn.plotlineNotes:
            for plId in prjScn.plotlineNotes:
                if not plId in prjScn.scPlotLines:
                    continue

                if not prjScn.plotlineNotes[plId]:
                    continue

                plRepr.append('%%Plotline:')
                plRepr.append(plId)

                plRepr.append('%%Plotline note:')
                plRepr.append(sanitize_markdown(prjScn.plotlineNotes[plId]))
        plStr = '\n\n'.join(plRepr)
        mapping['Plotlines'] = f'{plStr}\n\n'
        return mapping

    def _add_yaml(self, element, mapping):
        yaml = element.to_yaml([])
        mapping['YAML'] = '\n'.join(yaml)
        return mapping

    def _get_arcMapping(self, plId):
        mapping = super()._get_arcMapping(plId)
        element = self.novel.plotLines[plId]
        mapping = self._add_yaml(element, mapping)
        mapping = self._add_links(element, mapping)
        mapping['Desc'] = self._add_key(element.desc, 'Desc')
        return mapping

    def _get_chapterMapping(self, chId, chapterNumber):
        mapping = super()._get_chapterMapping(chId, chapterNumber)
        element = self.novel.chapters[chId]
        mapping = self._add_yaml(element, mapping)
        mapping = self._add_links(element, mapping)
        mapping['Desc'] = self._add_key(element.desc, 'Desc')
        mapping['Notes'] = self._add_key(element.desc, 'Notes')
        return mapping

    def _get_characterMapping(self, crId):
        mapping = super()._get_characterMapping(crId)
        element = self.novel.characters[crId]
        mapping = self._add_yaml(element, mapping)
        mapping = self._add_links(element, mapping)
        mapping['Desc'] = self._add_key(element.desc, 'Desc')
        mapping['Bio'] = self._add_key(element.bio, 'Bio')
        mapping['Goals'] = self._add_key(element.goals, 'Goals')
        mapping['Notes'] = self._add_key(element.desc, 'Notes')
        return mapping

    def _get_fileFooterMapping(self):
        mapping = {}
        if not self.wcLog:
            mapping['Wordcountlog'] = ''
            return mapping

        lines = ['@@Progress']
        wcLastCount = None
        wcLastTotalCount = None
        for wc in self.wcLog:
            if self.novel.saveWordCount:
                if self.wcLog[wc][0] == wcLastCount and self.wcLog[wc][1] == wcLastTotalCount:
                    continue

                wcLastCount = self.wcLog[wc][0]
                wcLastTotalCount = self.wcLog[wc][1]
            lines.append(f'- {list_to_string([wc, self.wcLog[wc][0], self.wcLog[wc][1]])}')
        mapping['Wordcountlog'] = '\n'.join(lines)
        return mapping

    def _get_fileHeaderMapping(self):
        mapping = super()._get_fileHeaderMapping()
        element = self.novel
        mapping = self._add_yaml(element, mapping)
        mapping = self._add_links(element, mapping)
        mapping['Desc'] = self._add_key(element.desc, 'Desc')
        return mapping

    def _get_itemMapping(self, itId):
        mapping = super()._get_itemMapping(itId)
        element = self.novel.items[itId]
        mapping = self._add_yaml(element, mapping)
        mapping = self._add_links(element, mapping)
        mapping['Desc'] = self._add_key(element.desc, 'Desc')
        mapping['Notes'] = self._add_key(element.desc, 'Notes')
        return mapping

    def _get_locationMapping(self, lcId):
        mapping = super()._get_locationMapping(lcId)
        element = self.novel.locations[lcId]
        mapping = self._add_yaml(element, mapping)
        mapping = self._add_links(element, mapping)
        mapping['Desc'] = self._add_key(element.desc, 'Desc')
        mapping['Notes'] = self._add_key(element.desc, 'Notes')
        return mapping

    def _get_prjNoteMapping(self, pnId):
        mapping = super()._get_prjNoteMapping(pnId)
        element = self.novel.projectNotes[pnId]
        mapping = self._add_yaml(element, mapping)
        mapping = self._add_links(element, mapping)
        mapping['Desc'] = self._add_key(element.desc, 'Desc')
        return mapping

    def _get_sectionMapping(self, scId, sectionNumber, wordsTotal, firstInChapter=False):
        mapping = super()._get_sectionMapping(scId, sectionNumber, wordsTotal)
        element = self.novel.sections[scId]
        mapping = self._add_yaml(element, mapping)
        mapping = self._add_links(element, mapping)
        mapping = self._add_plotline_notes(element, mapping)
        mapping['Desc'] = self._add_key(element.desc, 'Desc')
        mapping['Goal'] = self._add_key(element.goal, 'Goal')
        mapping['Conflict'] = self._add_key(element.conflict, 'Conflict')
        mapping['Outcome'] = self._add_key(element.outcome, 'Outcome')
        mapping['Notes'] = self._add_key(element.notes, 'Notes')
        mapping['SectionContent'] = self._add_key(element.sectionContent, 'Content')
        return mapping

    def _get_timestamp(self):
        try:
            self.timestamp = os.path.getmtime(self.filePath)
        except:
            self.timestamp = None

    def _keep_word_count(self):
        if not self.wcLog:
            return

        actualCountInt, actualTotalCountInt = self.count_words()
        actualCount = str(actualCountInt)
        actualTotalCount = str(actualTotalCountInt)
        latestDate = list(self.wcLog)[-1]
        latestCount = self.wcLog[latestDate][0]
        latestTotalCount = self.wcLog[latestDate][1]
        if actualCount != latestCount or actualTotalCount != latestTotalCount:
            try:
                fileDateIso = date.fromtimestamp(self.timestamp).isoformat()
            except:
                fileDateIso = date.today().isoformat()
            self.wcLogUpdate[fileDateIso] = [actualCount, actualTotalCount]

    def _read_element(self, element):
        if self._line.startswith('---'):
            if self._range != 'yaml':
                self._range = 'yaml'
                self._collectedLines = []
            else:
                element.from_yaml(self._collectedLines)
                self._range = None
            return

        if self._line.startswith('%%'):

            if self._range is not None:
                text = '\n'.join(self._collectedLines).strip()
                classProperty = self._properties.get(self._range, None)
                if classProperty is not None:
                    classProperty.fset(element, f'{text}\n')
                    self._plId = None
                elif self._range == 'Plotline':
                    self._plId = text
                elif self._range == 'Plotline note'and self._plId is not None:
                    plNotes = element.plotlineNotes
                    plNotes[self._plId] = text
                    element.plotlineNotes = plNotes
                    self._plId = None
                elif self._range == 'Link':
                    self._set_links(element, text)
                elif self._range == 'Progress':
                    self._set_word_count(text)
            self._collectedLines = []
            tag = self._line.strip('%: ')
            if tag:
                self._range = tag

        elif self._range is not None:
            self._collectedLines.append(self._line)

    def _read_chapter(self, element):
        self._properties = {
            'Desc':Chapter.desc,
            'Notes':Chapter.notes,
        }
        self._read_element(element)

    def _read_character(self, element):
        self._properties = {
            'Desc':Character.desc,
            'Notes':Character.notes,
            'Bio':Character.bio,
            'Goals':Character.goals,
        }
        self._read_element(element)

    def _read_world_element(self, element):
        self._properties = {
            'Desc':WorldElement.desc,
            'Notes':WorldElement.notes,
        }
        self._read_element(element)

    def _read_plot_line(self, element):
        self._properties = {
            'Desc':PlotLine.desc,
            'Notes':PlotLine.notes,
        }
        self._read_element(element)

    def _read_plot_point(self, element):
        self._properties = {
            'Desc':PlotPoint.desc,
            'Notes':PlotPoint.notes,
        }
        self._read_element(element)

    def _read_project(self, element):
        self._properties = {
            'Desc':Novel.desc,
        }
        self._read_element(element)

    def _read_project_note(self, element):
        self._properties = {
            'Desc':BasicElement.desc,
        }
        self._read_element(element)

    def _read_section(self, element):
        if element.plotlineNotes is None:
            element.plotlineNotes = {}
        self._properties = {
            'Desc':Section.desc,
            'Notes':Section.notes,
            'Goal':Section.goal,
            'Conflict':Section.conflict,
            'Outcome':Section.outcome,
            'Content':Section.sectionContent,
        }
        self._read_element(element)

    def _read_word_count_log(self, element):
        self._range = 'Progress'
        self._read_element(element)

    def _set_links(self, element, text):
        linkList = []
        relativeLink = ''
        absoluteLink = ''
        for line in text.split('\n'):
            if not line:
                continue

            linkType, link = line.split('](')
            if linkType == '[LinkPath':
                relativeLink = link.strip(') ')
            elif linkType == '[FullPath':
                absoluteLink = link.strip(') ')
                if relativeLink:
                    linkList.append((relativeLink, absoluteLink))
                relativeLink = ''
                absoluteLink = ''
        element.set_links(linkList)

    def _set_word_count(self, text):
        for line in text.split('\n'):
            if not line:
                continue

            wc = (line.strip('- ').split(';'))
            self.wcLog[wc[0]] = [wc[1], wc[2]]

    def _update_word_count_log(self):
        if self.novel.saveWordCount:
            newCountInt, newTotalCountInt = self.count_words()
            newCount = str(newCountInt)
            newTotalCount = str(newTotalCountInt)
            todayIso = date.today().isoformat()
            self.wcLogUpdate[todayIso] = [newCount, newTotalCount]
            for wcDate in self.wcLogUpdate:
                self.wcLog[wcDate] = self.wcLogUpdate[wcDate]
        self.wcLogUpdate = {}



class NewProjectFactory(FileFactory):
    DO_NOT_IMPORT = []

    def make_file_objects(self, sourcePath, **kwargs):
        if not self._canImport(sourcePath):
            raise Error(f'{_("This document is not meant to be written back")}.')

        fileName, __ = os.path.splitext(sourcePath)
        targetFile = MdnovFile(f'{fileName}{MdnovFile.EXTENSION}', **kwargs)
        if sourcePath.endswith('.md'):
            try:
                with open(sourcePath, 'r') as f:
                    content = f.read()
            except:
                raise Error(f'{_("Cannot read file")}: "{norm_path(sourcePath)}".')

            if '### ' in content:
                sourceFile = MdOutline(sourcePath, **kwargs)
            else:
                sourceFile = MdImport(sourcePath, **kwargs)
            return sourceFile, targetFile

        else:
            for fileClass in self._fileClasses:
                if fileClass.SUFFIX is not None:
                    if sourcePath.endswith(f'{fileClass.SUFFIX}{fileClass.EXTENSION}'):
                        sourceFile = fileClass(sourcePath, **kwargs)
                        return sourceFile, targetFile

            raise Error(f'{_("File type is not supported")}: "{norm_path(sourcePath)}".')

    def _canImport(self, sourcePath):
        fileName, __ = os.path.splitext(sourcePath)
        for suffix in self.DO_NOT_IMPORT:
            if fileName.endswith(suffix):
                return False

        return True


class NvDocImporter:
    IMPORT_SOURCE_CLASSES = [
    ]
    CREATE_SOURCE_CLASSES = [
    ]

    def __init__(self, ui):
        self._ui = ui
        self.importSourceFactory = ImportSourceFactory(self.IMPORT_SOURCE_CLASSES)
        self.newProjectFactory = NewProjectFactory(self.CREATE_SOURCE_CLASSES)
        self.importTargetFactory = ImportTargetFactory([MdnovFile])
        self.newFile = None

    def run(self, sourcePath, **kwargs):
        self.newFile = None
        if not os.path.isfile(sourcePath):
            raise Error(f'!{_("File not found")}: "{norm_path(sourcePath)}".')

        try:
            source, __ = self.importSourceFactory.make_file_objects(sourcePath, **kwargs)
        except Error:

            source, target = self.newProjectFactory.make_file_objects(sourcePath, **kwargs)
            if os.path.isfile(target.filePath):
                raise Error(f'!{_("File already exists")}: "{norm_path(target.filePath)}".')

            self._check(source, target)
            source.novel = kwargs['nv_service'].make_novel()
            source.read()
            target.novel = source.novel
            target.write()
            self.newFile = target.filePath
            return f'{_("File written")}: "{norm_path(target.filePath)}".'

        else:

            kwargs['suffix'] = source.SUFFIX
            __, target = self.importTargetFactory.make_file_objects(sourcePath, **kwargs)
            self.newFile = None
            self._check(source, target)
            target.novel = kwargs['nv_service'].make_novel()
            target.read()
            source.novel = target.novel
            source.read()
            if os.path.isfile(target.filePath):
                if not self._ui.ask_yes_no(
                    _('Update the project?'),
                    title=source.DESCRIPTION,
                    ):
                    raise Error(f'{_("Action canceled by user")}.')

            target.novel = source.novel
            target.write()
            message = f'{_("File written")}: "{norm_path(target.filePath)}".'
            self.newFile = target.filePath
            if source.sectionsSplit:
                os.replace(source.filePath, f'{source.filePath}.bak')
                message = f'{message} - {_("Source document deleted")}.'
            return message

    def _check(self, source, target):
        if source.filePath is None:
            raise Error(f'{_("File type is not supported")}.')

        if not os.path.isfile(source.filePath):
            raise Error(f'{_("File not found")}: "{norm_path(source.filePath)}".')

from abc import abstractmethod

from abc import ABC
from abc import abstractmethod


class Observable(ABC):

    @abstractmethod
    def __init__(self):
        self._clients = []
        self._isModified = False

    @property
    def isModified(self):
        return self._isModified

    @isModified.setter
    def isModified(self, setFlag):
        self._isModified = setFlag
        self.refresh_clients()

    def on_element_change(self):
        self.isModified = True

    def refresh_clients(self):
        for client in self._clients:
            client.refresh()

    def register_client(self, client):
        if not client in self._clients:
            self._clients.append(client)

    def unregister_client(self, client):
        if client in self._clients:
            self._clients.remove(client)



class ModelBase(Observable):

    @abstractmethod
    def __init__(self):
        super().__init__()

import math


def get_moon_phase_day(isoDate):
    try:
        y, m, d = isoDate.split('-')
        year = int(y)
        month = int(m)
        day = int(d)
        r = year % 100
        r %= 19
        if r > 9:
            r -= 19
        r = ((r * 11) % 30) + month + day
        if month < 3:
            r += 2
        if year < 2000:
            r -= 4
        else:
            r -= 8.3
        r = math.floor(r + 0.5) % 30
        if r < 0:
            r += 30
    except:
        r = None
    return r


def get_moon_phase_string(isoDate):
    moonViews = [
        '🌑',
        '🌑',
        '🌒',
        '🌒',
        '🌒',
        '🌒',
        '🌓',
        '🌓',
        '🌓',
        '🌓',
        '🌔',
        '🌔',
        '🌔',
        '🌔',
        '🌕',
        '🌕',
        '🌕',
        '🌖',
        '🌖',
        '🌖',
        '🌖',
        '🌗',
        '🌗',
        '🌗',
        '🌗',
        '🌘',
        '🌘',
        '🌘',
        '🌘',
        '🌑'
    ]
    moonFractions = '00¼¼¼¼½½½½¾¾¾¾111¾¾¾¾½½½½¼¼¼¼0'
    moonPhaseDay = get_moon_phase_day(isoDate)
    if moonPhaseDay is not None:
        display = f'{moonPhaseDay} {moonViews[moonPhaseDay]} {moonFractions[moonPhaseDay]}'
    else:
        display = ''
    return display



class NvTree:

    def __init__(self):
        self.roots = {
            CH_ROOT:[],
            CR_ROOT:[],
            LC_ROOT:[],
            IT_ROOT:[],
            PL_ROOT:[],
            PN_ROOT:[],
        }
        self.srtSections = {}
        self.srtTurningPoints = {}

    def append(self, parent, iid):
        if parent in self.roots:
            self.roots[parent].append(iid)
            if parent == CH_ROOT:
                self.srtSections[iid] = []
            elif parent == PL_ROOT:
                self.srtTurningPoints[iid] = []
            return

        if parent.startswith(CHAPTER_PREFIX):
            if parent in self.srtSections:
                self.srtSections[parent].append(iid)
            else:
                self.srtSections[parent] = [iid]
            return

        if parent.startswith(PLOT_LINE_PREFIX):
            if parent in self.srtTurningPoints:
                self.srtTurningPoints[parent].append(iid)
            else:
                self.srtTurningPoints[parent] = [iid]

    def delete(self, *items):
        raise NotImplementedError

    def delete_children(self, parent):
        if parent in self.roots:
            self.roots[parent] = []
            if parent == CH_ROOT:
                self.srtSections = {}
                return

            if parent == PL_ROOT:
                self.srtTurningPoints = {}
            return

        if parent.startswith(CHAPTER_PREFIX):
            self.srtSections[parent] = []
            return

        if parent.startswith(PLOT_LINE_PREFIX):
            self.srtTurningPoints[parent] = []

    def get_children(self, item):
        if item in self.roots:
            return self.roots[item]

        if item.startswith(CHAPTER_PREFIX):
            return self.srtSections.get(item, [])

        if item.startswith(PLOT_LINE_PREFIX):
            return self.srtTurningPoints.get(item, [])

    def index(self, item):
        raise NotImplementedError

    def insert(self, parent, index, iid):
        if parent in self.roots:
            self.roots[parent].insert(index, iid)
            if parent == CH_ROOT:
                self.srtSections[iid] = []
            elif parent == PL_ROOT:
                self.srtTurningPoints[iid] = []
            return

        if parent.startswith(CHAPTER_PREFIX):
            if parent in self.srtSections:
                self.srtSections[parent].insert(index, iid)
            else:
                self.srtSections[parent] = [iid]
            return

        if parent.startswith(PLOT_LINE_PREFIX):
            if parent in self.srtTurningPoints:
                self.srtTurningPoints[parent].insert(index, iid)
            else:
                self.srtTurningPoints[parent] = [iid]

    def move(self, item, parent, index):
        raise NotImplementedError

    def next(self, item):
        raise NotImplementedError

    def parent(self, item):
        raise NotImplementedError

    def prev(self, item):
        raise NotImplementedError

    def reset(self):
        for item in self.roots:
            self.roots[item] = []
        self.srtSections = {}
        self.srtTurningPoints = {}

    def set_children(self, item, newchildren):
        if item in self.roots:
            self.roots[item] = newchildren[:]
            if item == CH_ROOT:
                self.srtSections = {}
                return

            if item == PL_ROOT:
                self.srtTurningPoints = {}
            return

        if item.startswith(CHAPTER_PREFIX):
            self.srtSections[item] = newchildren[:]
            return

        if item.startswith(PLOT_LINE_PREFIX):
            self.srtTurningPoints[item] = newchildren[:]



class MdnovService:

    def get_prj_file_extension(self):
        return MdnovFile.EXTENSION

    def make_basic_element(self, **kwargs):
        return BasicElement(**kwargs)

    def make_chapter(self, **kwargs):
        return Chapter(**kwargs)

    def make_character(self, **kwargs):
        return Character(**kwargs)

    def make_novel(self, **kwargs):
        kwargs['tree'] = kwargs.get('tree', NvTree())
        return Novel(**kwargs)

    def make_nv_tree(self, **kwargs):
        return NvTree(**kwargs)

    def make_plot_line(self, **kwargs):
        return PlotLine(**kwargs)

    def make_plot_point(self, **kwargs):
        return PlotPoint(**kwargs)

    def make_section(self, **kwargs):
        return Section(**kwargs)

    def make_world_element(self, **kwargs):
        return WorldElement(**kwargs)

    def make_prj_file(self, filePath, **kwargs):
        return MdnovFile(filePath, **kwargs)

from tkinter import ttk



class NvTreeview(ttk.Treeview):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.on_element_change = self.do_nothing

        self.append('', CH_ROOT)
        self.append('', CR_ROOT)
        self.append('', LC_ROOT)
        self.append('', IT_ROOT)
        self.append('', PL_ROOT)
        self.append('', PN_ROOT)

    def append(self, parent, iid, text=None):
        if text is None:
            text = iid
        self.insert(parent, 'end', iid, text=text)

    def delete(self, *items):
        super().delete(*items)
        self.on_element_change()

    def delete_children(self, parent):
        for child in self.get_children(parent):
            self.delete(child)

    def insert(self, parent, index, iid=None, **kw):
        super().insert(parent, index, iid, **kw)
        self.on_element_change()

    def move(self, item, parent, index):
        super().move(item, parent, index)
        self.on_element_change()

    def reset(self):
        self.on_element_change = self.do_nothing
        for rootElement in self.get_children(''):
            for child in self.get_children(rootElement):
                self.delete(child)

    def do_nothing(self):
        pass


class NvService(MdnovService):

    def get_moon_phase_str(self, isoDate):
        return get_moon_phase_string(isoDate)

    def make_configuration(self, **kwargs):
        return Configuration(**kwargs)

    def make_novel(self, **kwargs):
        kwargs['tree'] = kwargs.get('tree', NvTreeview())
        return Novel(**kwargs)

    def make_nv_tree(self, **kwargs):
        return NvTreeview(**kwargs)
from datetime import datetime



class NvWorkFile(MdnovFile):
    DESCRIPTION = _('mdnovel project')
    _LOCKFILE_PREFIX = '.LOCK.'
    _LOCKFILE_SUFFIX = '#'

    @property
    def fileDate(self):
        if self.timestamp is None:
            return _('Never')
        else:
            return datetime.fromtimestamp(self.timestamp).strftime('%c')

    def adjust_section_types(self):
        super().adjust_section_types()
        for chId in self.novel.tree.get_children(CH_ROOT):
            if self.novel.chapters[chId].isTrash and self.novel.tree.next(chId):
                self.novel.tree.move(chId, CH_ROOT, 'end')
                return

    def has_changed_on_disk(self):
        try:
            if self.timestamp != os.path.getmtime(self.filePath):
                return True
            else:
                return False

        except:
            return False

    def _split_file_path(self):
        head, tail = os.path.split(self.filePath)
        if head:
            head = f'{head}/'
        else:
            head = './'
        return head, tail



class NvModel(ModelBase):

    def __init__(self):
        super().__init__()

        self.tree = None
        self.prjFile = None
        self.novel = None

        self.trashBin = None
        self.wordCount = 0

        self.nvService = NvService()

    def add_chapter(self, **kwargs):
        targetNode = kwargs.get('targetNode', '')
        index = 'end'
        if targetNode.startswith(SECTION_PREFIX):
            targetNode = self.tree.parent(targetNode)
        if targetNode.startswith(CHAPTER_PREFIX):
            index = self.tree.index(targetNode) + 1
            targetNode = self.tree.parent(targetNode)
        chId = create_id(self.novel.chapters, prefix=CHAPTER_PREFIX)
        self.novel.chapters[chId] = self.nvService.make_chapter(
            title=kwargs.get('title', f'{_("New Chapter")} ({chId})'),
            desc='',
            chLevel=2,
            chType=kwargs.get('chType', 0),
            noNumber=kwargs.get('NoNumber', False),
            isTrash=False,
            links={},
            on_element_change=self.on_element_change,
            )
        self.tree.insert(CH_ROOT, index, chId)
        return chId

    def add_character(self, **kwargs):
        targetNode = kwargs.get('targetNode', '')
        index = 'end'
        if targetNode.startswith(CHARACTER_PREFIX):
            index = self.tree.index(targetNode) + 1
        crId = create_id(self.novel.characters, prefix=CHARACTER_PREFIX)
        self.novel.characters[crId] = self.nvService.make_character(
            title=kwargs.get('title', f'{_("New Character")} ({crId})'),
            desc='',
            aka='',
            tags='',
            notes='',
            bio='',
            goals='',
            fullName='',
            isMajor=kwargs.get('isMajor', False),
            links={},
            on_element_change=self.on_element_change,
            )
        self.tree.insert(CR_ROOT, index, crId)
        return crId

    def add_item(self, **kwargs):
        targetNode = kwargs.get('targetNode', '')
        index = 'end'
        if targetNode.startswith(ITEM_PREFIX):
            index = self.tree.index(targetNode) + 1
        itId = create_id(self.novel.items, prefix=ITEM_PREFIX)
        self.novel.items[itId] = self.nvService.make_world_element(
            title=kwargs.get('title', f'{_("New Item")} ({itId})'),
            desc='',
            aka='',
            tags='',
            links={},
            on_element_change=self.on_element_change,
            )
        self.tree.insert(IT_ROOT, index, itId)
        return itId

    def add_location(self, **kwargs):
        targetNode = kwargs.get('targetNode', '')
        index = 'end'
        if targetNode.startswith(LOCATION_PREFIX):
            index = self.tree.index(targetNode) + 1
        lcId = create_id(self.novel.locations, prefix=LOCATION_PREFIX)
        self.novel.locations[lcId] = self.nvService.make_world_element(
            title=kwargs.get('title', f'{_("New Location")} ({lcId})'),
            desc='',
            aka='',
            tags='',
            links={},
            on_element_change=self.on_element_change,
            )
        self.tree.insert(LC_ROOT, index, lcId)
        return lcId

    def add_part(self, **kwargs):
        targetNode = kwargs.get('targetNode', '')
        index = 'end'
        if targetNode.startswith(SECTION_PREFIX):
            targetNode = self.tree.parent(targetNode)
        if targetNode.startswith(CHAPTER_PREFIX):
            index = self.tree.index(targetNode) + 1
            targetNode = self.tree.parent(targetNode)
        chId = create_id(self.novel.chapters, prefix=CHAPTER_PREFIX)
        self.novel.chapters[chId] = self.nvService.make_chapter(
            title=kwargs.get('title', f'{_("New Part")} ({chId})'),
            desc='',
            chLevel=1,
            chType=kwargs.get('chType', 0),
            noNumber=kwargs.get('NoNumber', False),
            isTrash=False,
            links={},
            on_element_change=self.on_element_change,
            )
        self.tree.insert(CH_ROOT, index, chId)
        return chId

    def add_plot_line(self, **kwargs):
        targetNode = kwargs.get('targetNode', '')
        index = 'end'
        if targetNode.startswith(PLOT_LINE_PREFIX):
            index = self.tree.index(targetNode) + 1
        plId = create_id(self.novel.plotLines, prefix=PLOT_LINE_PREFIX)
        self.novel.plotLines[plId] = self.nvService.make_plot_line(
            title=kwargs.get('title', f'{_("New Plot line")} ({plId})'),
            desc='',
            shortName=plId,
            sections=[],
            links={},
            on_element_change=self.on_element_change,
            )
        self.tree.insert(PL_ROOT, index, plId)
        return plId

    def add_plot_point(self, **kwargs):
        targetNode = kwargs.get('targetNode', None)
        if targetNode is None:
            return

        index = 'end'
        if targetNode.startswith(PLOT_POINT_PREFIX):
            parent = self.tree.parent(targetNode)
            index = self.tree.index(targetNode) + 1
        elif targetNode.startswith(PLOT_LINE_PREFIX):
            parent = targetNode
        else:
            return

        ppId = create_id(self.novel.plotPoints, prefix=PLOT_POINT_PREFIX)
        self.novel.plotPoints[ppId] = self.nvService.make_plot_point(
            title=kwargs.get('title', f'{_("New Plot point")} ({ppId})'),
            desc='',
            links={},
            on_element_change=self.on_element_change,
            )
        self.tree.insert(parent, index, ppId)
        return ppId

    def add_project_note(self, **kwargs):
        targetNode = kwargs.get('targetNode', '')
        index = 'end'
        if targetNode.startswith(PRJ_NOTE_PREFIX):
            index = self.tree.index(targetNode) + 1
        pnId = create_id(self.novel.projectNotes, prefix=PRJ_NOTE_PREFIX)
        self.novel.projectNotes[pnId] = self.nvService.make_basic_element(
            title=kwargs.get('title', f'{_("New Note")} ({pnId})'),
            desc='',
            links={},
            on_element_change=self.on_element_change,
            )
        self.tree.insert(PN_ROOT, index, pnId)
        return pnId

    def add_section(self, **kwargs):
        targetNode = kwargs.get('targetNode', None)
        if targetNode is None:
            return

        if targetNode.startswith(SECTION_PREFIX):
            parent = self.tree.parent(targetNode)
            index = self.tree.index(targetNode) + 1
        elif targetNode.startswith(CHAPTER_PREFIX):
            parent = targetNode
            index = 'end'
        else:
            return

        parentType = self.novel.chapters[parent].chType
        if parentType != 0:
            newType = parentType
        else:
            newType = kwargs.get('scType', 0)
        scId = create_id(self.novel.sections, prefix=SECTION_PREFIX)
        self.novel.sections[scId] = self.nvService.make_section(
            title=kwargs.get('title', f'{_("New Section")} ({scId})'),
            desc=kwargs.get('desc', ''),
            scType=newType,
            scene=kwargs.get('scene', 0),
            status=kwargs.get('status', 1),
            appendToPrev=kwargs.get('appendToPrev', False),
            characters=[],
            locations=[],
            items=[],
            links={},
            on_element_change=self.on_element_change,
            )
        self.novel.sections[scId].sectionContent = ''
        self.tree.insert(parent, index, scId)
        return scId

    def add_stage(self, **kwargs):
        targetNode = kwargs.get('targetNode', None)
        if targetNode is None:
            return

        if targetNode.startswith(SECTION_PREFIX):
            parent = self.tree.parent(targetNode)
            index = self.tree.index(targetNode) + 1
        elif targetNode.startswith(CHAPTER_PREFIX):
            parent = targetNode
            index = 0
        else:
            return

        scId = create_id(self.novel.sections, prefix=SECTION_PREFIX)
        self.novel.sections[scId] = self.nvService.make_section(
            title=kwargs.get('title', f'{_("Stage")}'),
            desc=kwargs.get('desc', ''),
            scType=kwargs.get('scType', 3),
            status=0,
            scene=0,
            links={},
            on_element_change=self.on_element_change,
            )
        self.tree.insert(parent, index, scId)
        return scId

    def close_project(self):
        self.isModified = False
        self.tree.on_element_change = self.tree.do_nothing
        self.novel = None
        self.prjFile = None

    def delete_element(self, elemId):

        def waste_sections(elemId):
            if elemId.startswith(SECTION_PREFIX):
                if self.novel.sections[elemId].scType < 2:
                    self.tree.move(elemId, self.trashBin, 0)
                    self.novel.sections[elemId].scType = 1
                    arcReferences = self.novel.sections[elemId].scPlotLines
                    tpReferences = self.novel.sections[elemId].scPlotPoints
                    self.novel.sections[elemId].scPlotLines = []
                    self.novel.sections[elemId].scPlotPoints = {}
                    for plId in arcReferences:
                        sections = self.novel.plotLines[plId].sections
                        sections.remove(elemId)
                        self.novel.plotLines[plId].sections = sections
                    for ppId in tpReferences:
                        self.novel.plotPoints[ppId].sectionAssoc = None
                else:
                    del self.novel.sections[elemId]
                    self.tree.delete(elemId)
            else:
                for childNode in self.tree.get_children(elemId):
                    waste_sections(childNode)
                del self.novel.chapters[elemId]

        if elemId == self.trashBin:
            for scId in self.tree.get_children(elemId):
                del self.novel.sections[scId]
            del self.novel.chapters[elemId]
            self.tree.delete(elemId)
            self.trashBin = None
        elif elemId.startswith(CHARACTER_PREFIX):
            del self.novel.characters[elemId]
            self.tree.delete(elemId)
            for scId in self.novel.sections:
                try:
                    scCharacters = self.novel.sections[scId].characters
                    scCharacters.remove(elemId)
                    self.novel.sections[scId].characters = scCharacters
                except:
                    pass
        elif elemId.startswith(LOCATION_PREFIX):
            del self.novel.locations[elemId]
            self.tree.delete(elemId)
            for scId in self.novel.sections:
                try:
                    scLocations = self.novel.sections[scId].locations
                    scLocations.remove(elemId)
                    self.novel.sections[scId].locations = scLocations
                except:
                    pass
        elif elemId.startswith(ITEM_PREFIX):
            del self.novel.items[elemId]
            self.tree.delete(elemId)
            for scId in self.novel.sections:
                try:
                    scItems = self.novel.sections[scId].items
                    scItems.remove(elemId)
                    self.novel.sections[scId].items = scItems
                except:
                    pass
        elif elemId.startswith(PLOT_LINE_PREFIX):
            if self.novel.plotLines[elemId].sections:
                for scId in self.novel.plotLines[elemId].sections:
                    self.novel.sections[scId].scPlotLines.remove(elemId)
                for ppId in self.tree.get_children(elemId):
                    scId = self.novel.plotPoints[ppId].sectionAssoc
                    if scId is not None:
                        del(self.novel.sections[scId].scPlotPoints[ppId])
                    del self.novel.plotPoints[ppId]
            del self.novel.plotLines[elemId]
            self.tree.delete(elemId)
        elif elemId.startswith(PLOT_POINT_PREFIX):
            scId = self.novel.plotPoints[elemId].sectionAssoc
            if scId is not None:
                del(self.novel.sections[scId].scPlotPoints[elemId])
            del self.novel.plotPoints[elemId]
            self.tree.delete(elemId)
        elif elemId.startswith(PRJ_NOTE_PREFIX):
            del self.novel.projectNotes[elemId]
            self.tree.delete(elemId)
        else:
            if self.trashBin is None:
                self.trashBin = create_id(self.novel.chapters, prefix=CHAPTER_PREFIX)
                self.novel.chapters[self.trashBin] = self.nvService.make_chapter(
                    title=_('Trash'),
                    desc='',
                    chLevel=2,
                    chType=3,
                    noNumber=True,
                    isTrash=True,
                    on_element_change=self.on_element_change,
                    )
                self.tree.append(CH_ROOT, self.trashBin)
            if elemId.startswith(SECTION_PREFIX):
                if self.tree.parent(elemId) == self.trashBin:
                    del self.novel.sections[elemId]
                    self.tree.delete(elemId)
                else:
                    waste_sections(elemId)
            else:
                waste_sections(elemId)
                self.tree.delete(elemId)
            self.set_type(3, [self.trashBin])

    def get_counts(self):
        partCount = 0
        chapterCount = 0
        sectionCount = 0
        wordCount = 0
        for chId in self.tree.get_children(CH_ROOT):
            if self.novel.chapters[chId].chType == 0:
                for scId in self.tree.get_children(chId):
                    if self.novel.sections[scId].scType == 0:
                        sectionCount += 1
                        wordCount += self.novel.sections[scId].wordCount
                if self.novel.chapters[chId].chLevel == 1:
                    partCount += 1
                else:
                    chapterCount += 1
        self.wordCount = wordCount
        return wordCount, sectionCount, chapterCount, partCount

    def get_status_counts(self):
        counts = [None, 0, 0, 0, 0, 0]
        for scId in self.novel.sections:
            if self.novel.sections[scId].scType == 0:
                if self.novel.sections[scId].status is not None:
                    counts[self.novel.sections[scId].status] += self.novel.sections[scId].wordCount
        return counts

    def join_sections(self, ScId0, ScId1):

        def join_str(text0, text1, newline='\n'):
            if text0 is None:
                text0 = ''
            if text1 is None:
                text1 = ''
            if text0 or text1:
                text0 = f'{text0}{newline}{text1}'.strip()
            return text0

        def join_lst(list0, list1):
            if list1:
                for elemId in list1:
                    if not list0:
                        list0 = []
                    if not elemId in list0:
                        list0.append(elemId)

        if not ScId1.startswith(SECTION_PREFIX):
            return

        if self.novel.sections[ScId1].scType != self.novel.sections[ScId0].scType:
            raise Error(_('The sections are not of the same type'))

        if self.novel.sections[ScId1].characters:
            if self.novel.sections[ScId1].characters:
                if self.novel.sections[ScId0].characters:
                    if self.novel.sections[ScId1].characters[0] != self.novel.sections[ScId0].characters[0]:
                        raise Error(_('The sections have different viewpoints'))

                else:
                    self.novel.sections[ScId0].characters.append(self.novel.sections[ScId1].characters[0])

        joinedTitles = f'{self.novel.sections[ScId0].title} & {self.novel.sections[ScId1].title}'
        self.novel.sections[ScId0].title = joinedTitles

        content0 = self.novel.sections[ScId0].sectionContent
        content1 = self.novel.sections[ScId1].sectionContent
        self.novel.sections[ScId0].sectionContent = join_str(content0, content1, newline='')

        self.novel.sections[ScId0].desc = join_str(self.novel.sections[ScId0].desc, self.novel.sections[ScId1].desc)
        self.novel.sections[ScId0].goal = join_str(self.novel.sections[ScId0].goal, self.novel.sections[ScId1].goal)
        self.novel.sections[ScId0].conflict = join_str(self.novel.sections[ScId0].conflict, self.novel.sections[ScId1].conflict)
        self.novel.sections[ScId0].outcome = join_str(self.novel.sections[ScId0].outcome, self.novel.sections[ScId1].outcome)
        self.novel.sections[ScId0].notes = join_str(self.novel.sections[ScId0].notes, self.novel.sections[ScId1].notes)

        join_lst(self.novel.sections[ScId0].characters, self.novel.sections[ScId1].characters)
        join_lst(self.novel.sections[ScId0].locations, self.novel.sections[ScId1].locations)
        join_lst(self.novel.sections[ScId0].items, self.novel.sections[ScId1].items)
        join_lst(self.novel.sections[ScId0].tags, self.novel.sections[ScId1].tags)

        for scPlotLine in self.novel.sections[ScId1].scPlotLines:
            self.novel.plotLines[scPlotLine].sections.remove(ScId1)
            if not ScId0 in self.novel.plotLines[scPlotLine].sections:
                self.novel.plotLines[scPlotLine].sections.append(ScId0)
            if not scPlotLine in self.novel.sections[ScId0].scPlotLines:
                self.novel.sections[ScId0].scPlotLines.append(scPlotLine)

        for ppId in self.novel.sections[ScId1].scPlotPoints:
            self.novel.plotPoints[ppId].sectionAssoc = ScId0
            self.novel.sections[ScId0].scPlotPoints[ppId] = self.novel.sections[ScId1].scPlotPoints[ppId]

        try:
            lastsMin1 = int(self.novel.sections[ScId1].lastsMinutes)
        except:
            lastsMin1 = 0
        try:
            lastsMin0 = int(self.novel.sections[ScId0].lastsMinutes)
        except:
            lastsMin0 = 0
        hoursLeft, lastsMin0 = divmod((lastsMin0 + lastsMin1), 60)
        self.novel.sections[ScId0].lastsMinutes = str(lastsMin0)
        try:
            lastsHours1 = int(self.novel.sections[ScId1].lastsHours)
        except:
            lastsHours1 = 0
        try:
            lastsHours0 = int(self.novel.sections[ScId0].lastsHours)
        except:
            lastsHours0 = 0
        daysLeft, lastsHours0 = divmod((lastsHours0 + lastsHours1 + hoursLeft), 24)
        self.novel.sections[ScId0].lastsHours = str(lastsHours0)
        try:
            lastsDays1 = int(self.novel.sections[ScId1].lastsDays)
        except:
            lastsDays1 = 0
        try:
            LastsDays0 = int(self.novel.sections[ScId0].lastsDays)
        except:
            LastsDays0 = 0
        LastsDays0 = LastsDays0 + lastsDays1 + daysLeft
        self.novel.sections[ScId0].lastsDays = str(LastsDays0)
        del(self.novel.sections[ScId1])
        self.tree.delete(ScId1)

    def move_node(self, node, targetNode):
        if node == self.trashBin:
            return

        if node[:2] == targetNode[:2]:
            self.tree.move(node, self.tree.parent(targetNode), self.tree.index(targetNode))
        elif (node.startswith(SECTION_PREFIX) and targetNode.startswith(CHAPTER_PREFIX)
              )or (node.startswith(PLOT_POINT_PREFIX) and targetNode.startswith(PLOT_LINE_PREFIX)):
            if not self.tree.get_children(targetNode):
                self.tree.move(node, targetNode, 0)
            elif self.tree.prev(targetNode):
                self.tree.move(node, self.tree.prev(targetNode), 'end')

    def new_project(self, tree):
        self.novel = self.nvService.make_novel(
            title='',
            desc='',
            authorName='',
            wordTarget=0,
            wordCountStart=0,
            renumberChapters=False,
            renumberParts=False,
            renumberWithinParts=False,
            romanChapterNumbers=False,
            romanPartNumbers=False,
            saveWordCount=True,
            workPhase=None,
            chapterHeadingPrefix=f"{_('Chapter')} ",
            chapterHeadingSuffix='',
            partHeadingPrefix=f"{_('Part')} ",
            partHeadingSuffix='',
            customGoal='',
            customConflict='',
            customOutcome='',
            customChrBio='',
            customChrGoals='',
            links=[],
            tree=tree,
            on_element_change=self.on_element_change,
            )
        self.prjFile = NvWorkFile('')
        self.prjFile.novel = self.novel
        self._initialize_tree(self.on_element_change)

    def open_project(self, filePath):
        self.novel = self.nvService.make_novel(tree=self.tree, links={})
        self.prjFile = NvWorkFile(filePath)
        self.prjFile.novel = self.novel
        self.prjFile.read()
        if self.prjFile.wcLogUpdate and self.novel.saveWordCount:
            self.isModified = True
        else:
            self.isModified = False
        self._initialize_tree(self.on_element_change)

    def renumber_chapters(self):
        ROMAN = [
            (1000, 'M'),
            (900, 'CM'),
            (500, 'D'),
            (400, 'CD'),
            (100, 'C'),
            (90, 'XC'),
            (50, 'L'),
            (40, 'XL'),
            (10, 'X'),
            (9, 'IX'),
            (5, 'V'),
            (4, 'IV'),
            (1, 'I'),
        ]

        def number_to_roman(n):
            result = []
            for (arabic, roman) in ROMAN:
                (factor, n) = divmod(n, arabic)
                result.append(roman * factor)
                if n == 0:
                    break

            return "".join(result)

        chapterCount = 0
        partCount = 0
        for chId in self.tree.get_children(CH_ROOT):
            if self.novel.chapters[chId].noNumber:
                continue

            if self.novel.chapters[chId].chType != 0:
                continue

            if self.novel.chapters[chId].chLevel == 2:
                if not self.novel.renumberChapters:
                    continue

            else:
                if self.novel.renumberWithinParts:
                    chapterCount = 0
                if not self.novel.renumberParts:
                    continue

            headingPrefix = ''
            headingSuffix = ''
            if self.novel.chapters[chId].chLevel == 2:
                chapterCount += 1
                if self.novel.romanChapterNumbers:
                    number = number_to_roman(chapterCount)
                else:
                    number = str(chapterCount)
                if self.novel.chapterHeadingPrefix is not None:
                    headingPrefix = self.novel.chapterHeadingPrefix
                if self.novel.chapterHeadingSuffix is not None:
                    headingSuffix = self.novel.chapterHeadingSuffix
            else:
                partCount += 1
                if self.novel.romanPartNumbers:
                    number = number_to_roman(partCount)
                else:
                    number = str(partCount)
                if self.novel.partHeadingPrefix is not None:
                    headingPrefix = self.novel.partHeadingPrefix
                if self.novel.partHeadingSuffix is not None:
                    headingSuffix = self.novel.partHeadingSuffix
            self.novel.chapters[chId].title = f'{headingPrefix}{number}{headingSuffix}'

    def reset_tree(self):
        self.tree.reset()
        self.trashBin = None

    def save_project(self, filePath=None):
        if filePath is not None:
            self.prjFile.filePath = filePath
        self.prjFile.write()
        self.isModified = False

    def set_level(self, newLevel, elemIds):
        for elemId in elemIds:
            if elemId.startswith(CHAPTER_PREFIX):
                self.novel.chapters[elemId].chLevel = newLevel
            elif elemId.startswith(SECTION_PREFIX):
                if self.novel.sections[elemId].scType > 1:
                    self.novel.sections[elemId].scType = newLevel + 1

    def set_character_status(self, isMajor, elemIds):
        for crId in elemIds:
            if crId.startswith(CHARACTER_PREFIX):
                self.novel.characters[crId].isMajor = isMajor
            elif crId == CR_ROOT:
                self.set_character_status(isMajor, self.tree.get_children(crId))

    def set_completion_status(self, newStatus, elemIds):
        for elemId in elemIds:
            if elemId.startswith(SECTION_PREFIX):
                if self.novel.sections[elemId].scType < 2:
                    self.novel.sections[elemId].status = newStatus
            elif elemId.startswith(CHAPTER_PREFIX) or elemId.startswith(CH_ROOT):
                self.set_completion_status(newStatus, self.tree.get_children(elemId))

    def set_type(self, newType, elemIds):
        for elemId in elemIds:
            if elemId.startswith(SECTION_PREFIX):
                if self.novel.sections[elemId].scType < 2:
                    parentType = self.novel.chapters[self.tree.parent(elemId)].chType
                    if parentType > 0:
                        newType = parentType
                    self.novel.sections[elemId].scType = newType
            elif elemId.startswith(CHAPTER_PREFIX):
                chapter = self.novel.chapters[elemId]
                if chapter.isTrash:
                    newType = 1
                chapter.chType = newType
                if newType > 0:
                    self.set_type(newType, self.tree.get_children(elemId))

    def _initialize_tree(self, on_element_change):

        def initialize_branch(node):
            for elemId in self.tree.get_children(node):
                if elemId.startswith(SECTION_PREFIX):
                    self.novel.sections[elemId].on_element_change = on_element_change
                elif elemId.startswith(CHARACTER_PREFIX):
                    self.novel.characters[elemId].on_element_change = on_element_change
                elif elemId.startswith(LOCATION_PREFIX):
                    self.novel.locations[elemId].on_element_change = on_element_change
                elif elemId.startswith(ITEM_PREFIX):
                    self.novel.items[elemId].on_element_change = on_element_change
                elif elemId.startswith(CHAPTER_PREFIX):
                    initialize_branch(elemId)
                    self.novel.chapters[elemId].on_element_change = on_element_change
                    if self.novel.chapters[elemId].isTrash:
                        self.trashBin = elemId
                elif elemId.startswith(PLOT_LINE_PREFIX):
                    initialize_branch(elemId)
                    self.novel.plotLines[elemId].on_element_change = on_element_change
                elif elemId.startswith(PLOT_POINT_PREFIX):
                    self.novel.plotPoints[elemId].on_element_change = on_element_change
                else:
                    initialize_branch(elemId)

        self.trashBin = None
        initialize_branch('')
        self.novel.on_element_change = on_element_change
        self.tree.on_element_change = on_element_change



class PluginCollection(list):

    PLUGINS = []

    def __init__(self, model, view, controller):
        super().__init__()
        for plugin in self.PLUGINS:
            self.append(plugin(model, view, controller))

    def disable_menu(self):
        for plugin in self:
            plugin.disable_menu()

    def enable_menu(self):
        for plugin in self:
            plugin.enable_menu()

    def lock(self):
        for plugin in self:
            plugin.lock()

    def on_close(self):
        for plugin in self:
            plugin.on_close()

    def on_quit(self):
        for plugin in self:
            plugin.on_quit()

from pathlib import Path

from tkinter import messagebox
from tkinter import ttk

from tkinter import ttk


ADDITIONAL_WORD_LIMITS = re.compile(r'--|—|–')

NO_WORD_LIMITS = re.compile(r'')


class EditorBox(tk.Text):
    _TAGS = ('**', '*')

    def __init__(self, master=None, **kw):
        self.frame = ttk.Frame(master)
        self.vbar = ttk.Scrollbar(self.frame)
        self.vbar.pack(side='right', fill='y')

        kw.update({'yscrollcommand': self.vbar.set})
        tk.Text.__init__(self, self.frame, **kw)
        self.pack(side='left', fill='both', expand=True)
        self.vbar['command'] = self.yview

        text_meths = vars(tk.Text).keys()
        methods = vars(tk.Pack).keys() | vars(tk.Grid).keys() | vars(tk.Place).keys()
        methods = methods.difference(text_meths)

        for m in methods:
            if m[0] != '_' and m != 'config' and m != 'configure':
                setattr(self, m, getattr(self.frame, m))

    def check_validity(self):
        return True

    def get_text(self, start='1.0', end='end'):
        text = self.get(start, end).strip()
        if text:
            return f'{text}\n'

        else:
            return ''

    def set_text(self, text):
        startIndex = 0
        if not text:
            text = ''
        self.insert('end', text)
        self.edit_reset()
        self.mark_set('insert', f'1.{startIndex}')

    def count_words(self):
        text = self.get('1.0', 'end')
        text = ADDITIONAL_WORD_LIMITS.sub(' ', text)
        text = NO_WORD_LIMITS.sub('', text)
        return len(text.split())

    def emphasis(self, event=None):
        self._set_format(tag='*')
        return 'break'

    def strong_emphasis(self, event=None):
        self._set_format(tag='**')
        return 'break'

    def plain(self, event=None):
        self._set_format()
        return 'break'

    def _set_format(self, event=None, tag=''):
        if tag:
            if self.tag_ranges('sel'):
                text = self.get(tk.SEL_FIRST, tk.SEL_LAST)
                if text.startswith(tag):
                    if text.endswith(tag):
                        text = self._remove_format(text, tag)
                        self._replace_selected(text)
                        return

                text = self._remove_format(text, tag)
                self._replace_selected(f'{tag}{text}{tag}')
            else:
                self.insert('insert', tag)
                endTag = tag
                self.insert('insert', endTag)
                self.mark_set('insert', f'insert-{len(endTag)}c')
        elif self.tag_ranges('sel'):
            text = self.get(tk.SEL_FIRST, tk.SEL_LAST)
            for tag in self._TAGS:
                text = self._remove_format(text, tag)
            self._replace_selected(text)

    def _replace_selected(self, text):
        self.mark_set('insert', tk.SEL_FIRST)
        self.delete(tk.SEL_FIRST, tk.SEL_LAST)
        selFirst = self.index('insert')
        self.insert('insert', text)
        selLast = self.index('insert')
        self.tag_add('sel', selFirst, selLast)

    def _remove_format(self, text, tag):
        if tag in self._TAGS:
            text = text.replace(tag, '')
        return text

    def clear(self):
        self.delete('1.0', 'end')
import platform



class GenericKeys:

    ADD_CHILD = ('<Control-Alt-n>', f'{_("Ctrl")}-Alt-N')
    ADD_ELEMENT = ('<Control-n>', f'{_("Ctrl")}-N')
    ADD_PARENT = ('<Control-Alt-N>', f'{_("Ctrl")}-Alt-{_("Shift")}-N')
    APPLY_CHANGES = ('<Control-s>', f'{_("Ctrl")}-S')
    BOLD = ('<Control-b>', f'{_("Ctrl")}-B')
    CHAPTER_LEVEL = ('<Control-Alt-c>', f'{_("Ctrl")}-Alt-C')
    COPY = ('<Control-c>', f'{_("Ctrl")}-C')
    CREATE_SCENE = ('<Control-Alt-n>', f'{_("Ctrl")}-Alt-N')
    CUT = ('<Control-x>', f'{_("Ctrl")}-X')
    DELETE = ('<Delete>', _('Del'))
    DETACH_PROPERTIES = ('<Control-Alt-d>', f'{_("Ctrl")}-Alt-D')
    END_FULLSCREEN = ('<Escape>', 'Esc')
    FOLDER = ('<Control-p>', f'{_("Ctrl")}-P')
    ITALIC = ('<Control-i>', f'{_("Ctrl")}-I')
    LOCK_PROJECT = ('<Control-l>', f'{_("Ctrl")}-L')
    OPEN_HELP = ('<F1>', 'F1')
    OPEN_PROJECT = ('<Control-o>', f'{_("Ctrl")}-O')
    PASTE = ('<Control-v>', f'{_("Ctrl")}-V')
    PLAIN = ('<Control-m>', f'{_("Ctrl")}-M')
    QUIT_PROGRAM = ('<Control-q>', f'{_("Ctrl")}-Q')
    REFRESH_TREE = ('<F5>', 'F5')
    RELOAD_PROJECT = ('<Control-r>', f'{_("Ctrl")}-R')
    RESTORE_BACKUP = ('<Control-b>', f'{_("Ctrl")}-B')
    RESTORE_STATUS = ('<Escape>', 'Esc')
    SAVE_AS = ('<Control-S>', f'{_("Ctrl")}-{_("Shift")}-S')
    SAVE_PROJECT = ('<Control-s>', f'{_("Ctrl")}-S')
    SPLIT_SCENE = ('<Control-Alt-s>', f'{_("Ctrl")}-Alt-S')
    TOGGLE_PROPERTIES = ('<Control-Alt-t>', f'{_("Ctrl")}-Alt-T')
    TOGGLE_VIEWER = ('<Control-t>', f'{_("Ctrl")}-T')
    TOGGLE_FULLSCREEN = ('<F11>', 'F11')
    UNLOCK_PROJECT = ('<Control-u>', f'{_("Ctrl")}-U')
    UPDATE_WORDCOUNT = ('<F5>', 'F5')


class GenericMouse:

    LEFT_CLICK = '<Button-1>'
    MOVE_NODE = '<Alt-B1-Motion>'
    RIGHT_CLICK = '<Button-3>'
    TOGGLE_STATE = '<Control-Button-1>'


class MacKeys(GenericKeys):

    ADD_CHILD = ('<Command-Alt-n>', 'Cmd-Alt-N')
    ADD_ELEMENT = ('<Command-n>', 'Cmd-N')
    ADD_PARENT = ('<Command-Alt-Shift-N>', 'Cmd-Alt-Shift-N')
    APPLY_CHANGES = ('<Command-s>', 'Cmd-S')
    BOLD = ('<Command-b>', 'Cmd-B')
    CHAPTER_LEVEL = ('<Command-Alt-c>', 'Cmd-Alt-C')
    CREATE_SCENE = ('<Command-Alt-n>', 'Cmd-Alt-N')
    DETACH_PROPERTIES = ('<Command-Alt-d>', 'Cmd-Alt-D')
    FOLDER = ('<Command-p>', 'Cmd-P')
    ITALIC = ('<Command-i>', 'Cmd-I')
    LOCK_PROJECT = ('<Command-l>', 'Cmd-L')
    OPEN_PROJECT = ('<Command-o>', 'Cmd-O')
    PLAIN = ('<Command-m>', 'Cmd-M')
    QUIT_PROGRAM = ('<Command-q>', 'Cmd-Q')
    RELOAD_PROJECT = ('<Command-r>', 'Cmd-R')
    RESTORE_BACKUP = ('<Command-b>', 'Cmd-B')
    SAVE_AS = ('<Command-S>', 'Cmd-Shift-S')
    SAVE_PROJECT = ('<Command-s>', 'Cmd-S')
    SPLIT_SCENE = ('<Command-Alt-s>', 'Cmd-Alt-S')
    TOGGLE_PROPERTIES = ('<Command-Alt-t>', 'Cmd-Alt-T')
    TOGGLE_VIEWER = ('<Command-t>', 'Cmd-T')
    UNLOCK_PROJECT = ('<Command-u>', 'Cmd-U')


class MacMouse(GenericMouse):

    RIGHT_CLICK = '<Button-2>'
    TOGGLE_STATE = '<Command-Button-1>'


class WindowsKeys(GenericKeys):

    QUIT_PROGRAM = ('<Alt-F4>', 'Alt-F4')


class WindowsMouse(GenericMouse):

    BACK_CLICK = '<Button-4>'
    FORWARD_CLICK = '<Button-5>'

if platform.system() == 'Windows':
    PLATFORM = 'win'
    KEYS = WindowsKeys()
    MOUSE = WindowsMouse()
elif platform.system() in ('Linux', 'FreeBSD'):
    PLATFORM = 'ix'
    KEYS = GenericKeys()
    MOUSE = GenericMouse()
elif platform.system() == 'Darwin':
    PLATFORM = 'mac'
    KEYS = MacKeys()
    MOUSE = MacMouse()
else:
    PLATFORM = ''
    KEYS = GenericKeys()
    MOUSE = GenericMouse()



class EditorWindow(tk.Toplevel):
    liveWordCount = None
    colorMode = None

    def __init__(self, manager, model, view, controller, scId, size, icon=None):
        self._mdl = model
        self._ui = view
        self._ctrl = controller
        self._manager = manager
        self._section = self._mdl.novel.sections[scId]
        self._scId = scId

        self.colorModes = [
            (
                _('Bright mode'),
                manager.kwargs['ed_color_fg_bright'],
                manager.kwargs['ed_color_bg_bright'],
                ),
            (
                _('Light mode'),
                manager.kwargs['ed_color_fg_light'],
                manager.kwargs['ed_color_bg_light'],
                ),
            (
                _('Dark mode'),
                manager.kwargs['ed_color_fg_dark'],
                manager.kwargs['ed_color_bg_dark'],
                ),
            ]

        super().__init__()
        self.geometry(size)
        if icon:
            self.iconphoto(False, icon)

        self._mainMenu = tk.Menu(self)
        self.config(menu=self._mainMenu)


        self._sectionEditor = EditorBox(
            self,
            wrap='word',
            undo=True,
            autoseparators=True,
            spacing1=self._manager.kwargs['ed_paragraph_spacing'],
            spacing2=self._manager.kwargs['ed_line_spacing'],
            maxundo=-1,
            padx=self._manager.kwargs['ed_margin_x'],
            pady=self._manager.kwargs['ed_margin_y'],
            font=(self._manager.kwargs['ed_font_family'], self._manager.kwargs['ed_font_size']),
            )
        self._sectionEditor.pack(expand=True, fill='both')
        self._sectionEditor.pack_propagate(0)
        self._set_editor_colors()

        self._statusBar = tk.Label(self, text='', anchor='w', padx=5, pady=2)
        self._statusBar.pack(expand=False, side='left')

        ttk.Button(self, text=_('Next'), command=self._load_next).pack(side='right')
        ttk.Button(self, text=_('Close'), command=self.on_quit).pack(side='right')
        ttk.Button(self, text=_('Previous'), command=self._load_prev).pack(side='right')

        self._load_section()


        self._sectionMenu = tk.Menu(self._mainMenu, tearoff=0)
        self._mainMenu.add_cascade(label=_('Section'), menu=self._sectionMenu)
        self._sectionMenu.add_command(label=_('Next'), command=self._load_next)
        self._sectionMenu.add_command(label=_('Previous'), command=self._load_prev)
        self._sectionMenu.add_command(label=_('Apply changes'), accelerator=KEYS.APPLY_CHANGES[1], command=self._apply_changes)
        if PLATFORM == 'win':
            self._sectionMenu.add_command(label=_('Exit'), accelerator=KEYS.QUIT_PROGRAM[1], command=self.on_quit)
        else:
            self._sectionMenu.add_command(label=_('Quit'), accelerator=KEYS.QUIT_PROGRAM[1], command=self.on_quit)

        self._viewMenu = tk.Menu(self._mainMenu, tearoff=0)
        self._mainMenu.add_cascade(label=_('View'), menu=self._viewMenu)
        for i, cm in enumerate(self.colorModes):
            self._viewMenu.add_radiobutton(label=cm[0], variable=EditorWindow.colorMode, command=self._set_editor_colors, value=i)
        self._viewMenu.add_separator()
        self._viewMenu.add_command(label=_('Toggle full screen mode'), accelerator=KEYS.TOGGLE_FULLSCREEN[1], command=self._toggle_fullscreen)

        self._editMenu = tk.Menu(self._mainMenu, tearoff=0)
        self._mainMenu.add_cascade(label=_('Edit'), menu=self._editMenu)
        self._editMenu.add_command(label=_('Copy'), accelerator=KEYS.COPY[1], command=lambda: self._sectionEditor.event_generate("<<Copy>>"))
        self._editMenu.add_command(label=_('Cut'), accelerator=KEYS.CUT[1], command=lambda: self._sectionEditor.event_generate("<<Cut>>"))
        self._editMenu.add_command(label=_('Paste'), accelerator=KEYS.PASTE[1], command=lambda: self._sectionEditor.event_generate("<<Paste>>"))
        self._editMenu.add_separator()
        self._editMenu.add_command(label=_('Split at cursor position'), accelerator=KEYS.SPLIT_SCENE[1], command=self._split_section)
        self._editMenu.add_command(label=_('Create section'), accelerator=KEYS.CREATE_SCENE[1], command=self._create_section)

        self._formatMenu = tk.Menu(self._mainMenu, tearoff=0)
        self._mainMenu.add_cascade(label=_('Format'), menu=self._formatMenu)
        self._formatMenu.add_command(label=_('Emphasis'), accelerator=KEYS.ITALIC[1], command=self._sectionEditor.emphasis)
        self._formatMenu.add_command(label=_('Strong emphasis'), accelerator=KEYS.BOLD[1], command=self._sectionEditor.strong_emphasis)
        self._formatMenu.add_command(label=_('Plain'), accelerator=KEYS.PLAIN[1], command=self._sectionEditor.plain)

        self._wcMenu = tk.Menu(self._mainMenu, tearoff=0)
        self._mainMenu.add_cascade(label=_('Word count'), menu=self._wcMenu)
        self._wcMenu.add_command(label=_('Update'), accelerator=KEYS.UPDATE_WORDCOUNT[1], command=self.show_wordcount)
        self._wcMenu.add_checkbutton(label=_('Live update'), variable=EditorWindow.liveWordCount, command=self._set_wc_mode)

        self.helpMenu = tk.Menu(self._mainMenu, tearoff=0)
        self._mainMenu.add_cascade(label=_('Help'), menu=self.helpMenu)
        self.helpMenu.add_command(label=_('Online help'), accelerator=KEYS.OPEN_HELP[1], command=self._open_help)

        self.bind(KEYS.OPEN_HELP[0], self._open_help)
        if PLATFORM != 'win':
            self._sectionEditor.bind(KEYS.QUIT_PROGRAM[0], self.on_quit)
        self._sectionEditor.bind(KEYS.APPLY_CHANGES[0], self._apply_changes)
        self._sectionEditor.bind(KEYS.UPDATE_WORDCOUNT[0], self.show_wordcount)
        self._sectionEditor.bind(KEYS.SPLIT_SCENE[0], self._split_section)
        self._sectionEditor.bind(KEYS.CREATE_SCENE[0], self._create_section)
        self._sectionEditor.bind(KEYS.ITALIC[0], self._sectionEditor.emphasis)
        self._sectionEditor.bind(KEYS.BOLD[0], self._sectionEditor.strong_emphasis)
        self._sectionEditor.bind(KEYS.PLAIN[0], self._sectionEditor.plain)
        self.protocol("WM_DELETE_WINDOW", self.on_quit)

        self._set_wc_mode()
        self.lift()
        self.isOpen = True

        if self._manager.kwargs['ed_fullscreen']:
            self._start_fullscreen()
        self.bind(KEYS.TOGGLE_FULLSCREEN[0], self._toggle_fullscreen)
        self.bind(KEYS.END_FULLSCREEN[0], self._end_fullscreen)

    def lift(self):
        if self.state() == 'iconic':
            self.state('normal')
        super().lift()
        self._sectionEditor.focus()

    def on_quit(self, event=None):
        if not self._apply_changes_after_asking():
            return 'break'

        if not self.attributes('-fullscreen'):
            self._manager.kwargs['ed_win_geometry'] = self.winfo_geometry()
        self.destroy()
        self.isOpen = False

    def show_status(self, message=None):
        self._statusBar.config(text=message)

    def show_wordcount(self, event=None):
        wc = self._sectionEditor.count_words()
        diff = wc - self._initialWc
        self._statusBar.config(text=f'{wc} {_("words")} ({diff} {_("new")})')

    def _apply_changes(self, event=None):
        if not self._scId in self._mdl.novel.sections:
            return

        try:
            self._sectionEditor.check_validity()
        except ValueError as ex:
            self._ui.show_warning(str(ex))
            self.lift()
            return

        sectionText = self._sectionEditor.get_text()
        if sectionText or self._section.sectionContent:
            if self._section.sectionContent != sectionText:
                self._transfer_text(sectionText)

    def _apply_changes_after_asking(self, event=None):
        if not self._scId in self._mdl.novel.sections:
            return True

        sectionText = self._sectionEditor.get_text()
        if sectionText or self._section.sectionContent:
            if self._section.sectionContent != sectionText:
                if messagebox.askyesno(SC_EDITOR, _('Apply section changes?'), parent=self):
                    try:
                        self._sectionEditor.check_validity()
                    except ValueError as ex:
                        self._ui.show_warning(str(ex))
                        self.lift()
                        return False

                    self._transfer_text(sectionText)
        return True

    def _create_section(self, event=None):
        self.lift()
        thisNode = self._scId
        sceneKind = self._mdl.novel.sections[self._scId].scene
        if sceneKind == 1:
            sceneKind = 2
        elif sceneKind == 2:
            sceneKind = 1
        newId = self._ctrl.add_section(
            targetNode=thisNode,
            scType=self._mdl.novel.sections[self._scId].scType,
            scene=sceneKind,
            )
        self._load_next()
        return newId

    def _end_fullscreen(self, event=None):
        self._manager.kwargs['ed_fullscreen'] = False
        self.attributes('-fullscreen', False)

        self._sectionEditor['padx'] = self._manager.kwargs['ed_margin_x']
        return "break"

    def _load_next(self, event=None):
        if not self._apply_changes_after_asking():
            return

        nextNode = self._ui.tv.next_node(self._scId)
        if nextNode:
            self._ui.tv.go_to_node(nextNode)
            self._manager.close_editor_window(self._scId)
            self._manager.open_editor_window()

    def _load_prev(self, event=None):
        if not self._apply_changes_after_asking():
            return

        prevNode = self._ui.tv.prev_node(self._scId)
        if prevNode:
            self._ui.tv.go_to_node(prevNode)
            self._manager.close_editor_window(self._scId)
            self._manager.open_editor_window()

    def _load_section(self):
        self.title(f'{self._section.title} - {self._mdl.novel.title}, {_("Section")} ID {self._scId}')
        self._sectionEditor.set_text(self._section.sectionContent)
        self._initialWc = self._sectionEditor.count_words()
        self.show_wordcount()

    def _open_help(self, event=None):
        open_help(f'editor')

    def _set_editor_colors(self):
        cm = EditorWindow.colorMode.get()
        self._sectionEditor['fg'] = self.colorModes[cm][1]
        self._sectionEditor['bg'] = self.colorModes[cm][2]
        self._sectionEditor['insertbackground'] = self.colorModes[cm][1]

    def _set_wc_mode(self, *args):
        if EditorWindow.liveWordCount.get():
            self.bind('<KeyRelease>', self.show_wordcount)
            self.show_wordcount()
        else:
            self.unbind('<KeyRelease>')

    def _split_section(self, event=None):

        try:
            self._sectionEditor.check_validity()
        except ValueError as ex:
            self._ui.show_warning(str(ex))
            self.lift()
            return

        if messagebox.askyesno(
            SC_EDITOR,
            f'{_("Move the text from the cursor position to the end into a new section")}?',
            parent=self
            ):
            self.lift()
        else:
            self.lift()
            return

        thisNode = self._scId
        sceneKind = self._mdl.novel.sections[self._scId].scene
        if sceneKind == 1:
            sceneKind = 2
        elif sceneKind == 2:
            sceneKind = 1
        newId = self._ctrl.add_section(
            targetNode=thisNode,
            appendToPrev=True,
            scType=self._mdl.novel.sections[self._scId].scType,
            scene=sceneKind,
            status=self._mdl.novel.sections[self._scId].status
            )
        if newId:

            newContent = self._sectionEditor.get_text('insert', 'end').strip(' \n')
            self._sectionEditor.delete('insert', 'end')
            self._apply_changes()

            self._mdl.novel.sections[newId].sectionContent = newContent

            if self._mdl.novel.sections[self._scId].characters:
                viewpoint = self._mdl.novel.sections[self._scId].characters[0]
                self._mdl.novel.sections[newId].characters = [viewpoint]

            self._load_next()

    def _start_fullscreen(self, event=None):
        self._manager.kwargs['ed_win_geometry'] = self.winfo_geometry()
        self._manager.kwargs['ed_fullscreen'] = True
        self.attributes('-fullscreen', True)

        screenwidth = self.winfo_screenwidth()
        linewidth = int(self._manager.kwargs['ed_line_width'])
        padx = (screenwidth - linewidth) // 2
        if padx > int(self._manager.kwargs['ed_margin_x']):
            self._sectionEditor['padx'] = padx
        return "break"

    def _transfer_text(self, sectionText):
        try:
            self._sectionEditor.check_validity()
        except ValueError as ex:
            self._ui.show_warning(str(ex))
            self.lift()
            return

        self._section.sectionContent = sectionText

    def _toggle_fullscreen(self, event=None):
        if self.attributes('-fullscreen'):
            self._end_fullscreen()
        else:
            self._start_fullscreen()
        return "break"

from abc import ABC, abstractmethod


class PluginBase(ABC):

    @abstractmethod
    def __init__(self, model, view, controller):
        self._mdl = model
        self._ui = view
        self._ctrl = controller

    def disable_menu(self):
        pass

    def enable_menu(self):
        pass

    def lock(self):
        pass

    def on_close(self):
        pass

    def on_quit(self):
        pass

    def unlock(self):
        pass



class Editor(PluginBase):
    SETTINGS = dict(
        ed_win_geometry='600x800',
        ed_color_mode=0,
        ed_color_bg_bright='white',
        ed_color_fg_bright='black',
        ed_color_bg_light='antique white',
        ed_color_fg_light='black',
        ed_color_bg_dark='gray20',
        ed_color_fg_dark='light grey',
        ed_font_family='Courier',
        ed_font_size=12,
        ed_line_spacing=4,
        ed_line_width=600,
        ed_paragraph_spacing=4,
        ed_margin_x=40,
        ed_margin_y=20,
    )
    OPTIONS = dict(
        ed_fullscreen=False,
        ed_live_wordcount=False,
    )

    def __init__(self, model, view, controller):
        super().__init__(model, view, controller)

        try:
            homeDir = str(Path.home()).replace('\\', '/')
            configDir = f'{homeDir}/.mdnovel/config'
        except:
            configDir = '.'
        self.iniFile = f'{configDir}/editor.ini'
        self.configuration = self._mdl.nvService.make_configuration(
            settings=self.SETTINGS,
            options=self.OPTIONS
            )
        self.configuration.read(self.iniFile)
        self.kwargs = {}
        self.kwargs.update(self.configuration.settings)
        self.kwargs.update(self.configuration.options)

        self._ui.sectionMenu.add_separator()
        self._ui.sectionMenu.add_command(label=_('Edit'), underline=0, command=self.open_editor_window)

        self.sectionEditors = {}
        try:
            path = os.path.dirname(sys.argv[0])
            if not path:
                path = '.'
            self._icon = tk.PhotoImage(file=f'{path}/icons/{SC_EDITOR_ICON}.png')
        except:
            self._icon = None

        EditorWindow.colorMode = tk.IntVar(
            value=int(self.kwargs['ed_color_mode'])
            )
        EditorWindow.liveWordCount = tk.BooleanVar(
            value=self.kwargs['ed_live_wordcount']
            )

        self._ui.tv.tree.bind('<Double-1>', self.open_editor_window)
        self._ui.tv.tree.bind('<Return>', self.open_editor_window)

        self._mdl.register_client(self)

    def close_editor_window(self, nodeId):
        if nodeId in self.sectionEditors and self.sectionEditors[nodeId].isOpen:
            self.sectionEditors[nodeId].on_quit()
            del self.sectionEditors[nodeId]

    def on_close(self, event=None):
        for scId in self.sectionEditors:
            if self.sectionEditors[scId].isOpen:
                self.sectionEditors[scId].on_quit()

    def on_quit(self, event=None):
        self.on_close()

        self.kwargs['ed_color_mode'] = EditorWindow.colorMode.get()
        self.kwargs['ed_live_wordcount'] = EditorWindow.liveWordCount.get()
        for keyword in self.kwargs:
            if keyword in self.configuration.options:
                self.configuration.options[keyword] = self.kwargs[keyword]
            elif keyword in self.configuration.settings:
                self.configuration.settings[keyword] = self.kwargs[keyword]
        self.configuration.write(self.iniFile)

    def open_editor_window(self, event=None):
        try:
            nodeId = self._ui.tv.tree.selection()[0]
            if nodeId.startswith(SECTION_PREFIX):
                if self._mdl.novel.sections[nodeId].scType > 1:
                    return

                if nodeId in self.sectionEditors and self.sectionEditors[nodeId].isOpen:
                    self.sectionEditors[nodeId].lift()
                    return

                self.sectionEditors[nodeId] = EditorWindow(self, self._mdl, self._ui, self._ctrl, nodeId, self.kwargs['ed_win_geometry'], icon=self._icon)

        except IndexError:
            pass

    def refresh(self):
        for scId in list(self.sectionEditors):
            if not scId in self._mdl.novel.sections:
                self.close_editor_window(scId)
from pathlib import Path
from tkinter import ttk

from tkinter import ttk

from abc import abstractmethod

from abc import ABC
from abc import abstractmethod


class Observer(ABC):

    @abstractmethod
    def refresh(self):
        pass


class ViewComponentBase(Observer):

    @abstractmethod
    def __init__(self, model, view, controller):
        Observer.__init__(self)
        self._mdl = model
        self._ui = view
        self._ctrl = controller

    def disable_menu(self):
        pass

    def enable_menu(self):
        pass

    def lock(self):
        pass

    def refresh(self):
        pass

    def unlock(self):
        pass



class Node(tk.Label):
    marker = '⬛'

    def __init__(self, master, colorFalse='white', colorTrue='black', cnf={}, **kw):
        self.colorFg = colorTrue
        self.colorBg = colorFalse
        self._state = False
        super().__init__(master, cnf, **kw)
        self.config(background=self.colorBg)
        self.config(foreground=self.colorFg)
        self.bind(MOUSE.TOGGLE_STATE, self._toggle_state)

    @property
    def state(self):
        return self._state

    @state.setter
    def state(self, newState):
        self._state = newState
        self._set_marker()

    def _set_marker(self):
        if self._state:
            self.config(text=self.marker)
        else:
            self.config(text='')

    def _toggle_state(self, event=None):
        self.state = not self._state


class RelationsTable:

    def __init__(self, master, novel, **kwargs):
        self._novel = novel
        self._kwargs = kwargs
        self.draw_matrix(master)

    def draw_matrix(self, master):

        def fill_str(text):
            while len(text) < 7:
                text = f' {text} '
            return text

        colorsBackground = ((self._kwargs['color_bg_00'], self._kwargs['color_bg_01']),
                            (self._kwargs['color_bg_10'], self._kwargs['color_bg_11']))
        columns = []
        col = 0
        bgc = col % 2

        tk.Label(master.topLeft, text=_('Sections')).pack(fill='x')
        tk.Label(master.topLeft, bg=colorsBackground[1][1], text=' ').pack(fill='x')

        row = 0
        self._plotlineNodes = {}
        self._characterNodes = {}
        self._locationNodes = {}
        self._itemNodes = {}
        for chId in self._novel.tree.get_children(CH_ROOT):
            if self._novel.chapters[chId].chType == 0:
                for scId in self._novel.tree.get_children(chId):
                    bgr = row % 2
                    if self._novel.sections[scId].scType != 0:
                        continue

                    self._characterNodes[scId] = {}
                    self._locationNodes[scId] = {}
                    self._itemNodes[scId] = {}
                    self._plotlineNodes[scId] = {}

                    tk.Label(master.rowTitles,
                             text=self._novel.sections[scId].title,
                             bg=colorsBackground[bgr][1],
                             justify='left',
                             anchor='w'
                             ).pack(fill='x')
                    row += 1
        bgr = row % 2
        tk.Label(master.rowTitles,
                         text=' ',
                         bg=colorsBackground[bgr][1],
                         ).pack(fill='x')
        tk.Label(master.rowTitles,
                         text=_('Sections'),
                         ).pack(fill='x')

        if self._novel.plotLines:
            plotlineTitleWindow = tk.Frame(master.columnTitles)
            plotlineTitleWindow.pack(side='left', fill='both')
            tk.Label(plotlineTitleWindow, text=_('Plot lines'), bg=self._kwargs['color_arc_heading']).pack(fill='x')
            plotlineTypeColumn = tk.Frame(master.display)
            plotlineTypeColumn.pack(side='left', fill='both')
            plotlineColumn = tk.Frame(plotlineTypeColumn)
            plotlineColumn.pack(fill='both')
            for plId in self._novel.tree.get_children(PL_ROOT):
                row = 1
                bgr = row % 2
                bgc = col % 2
                plotlineTitle = fill_str(self._novel.plotLines[plId].shortName)
                tk.Label(plotlineTitleWindow,
                         text=plotlineTitle,
                         bg=colorsBackground[bgr][bgc],
                         justify='left',
                         anchor='w'
                         ).pack(side='left', fill='x', expand=True)
                row += 1

                columns.append(tk.Frame(plotlineColumn))
                columns[col].pack(side='left', fill='both', expand=True)
                for scId in self._plotlineNodes:
                    bgr = row % 2
                    node = Node(columns[col],
                         colorFalse=colorsBackground[bgr][bgc],
                         colorTrue=self._kwargs['color_arc_node']
                         )
                    node.pack(fill='x', expand=True)
                    self._plotlineNodes[scId][plId] = node
                    row += 1
                bgr = row % 2
                tk.Label(columns[col],
                         text=plotlineTitle,
                         bg=colorsBackground[bgr][bgc],
                         justify='left',
                         anchor='w'
                         ).pack(fill='x', expand=True)
                col += 1
            tk.Label(plotlineTypeColumn, text=_('Plot lines'), bg=self._kwargs['color_arc_heading']).pack(fill='x')

        if self._novel.characters:
            characterTypeColumn = tk.Frame(master.display)
            characterTypeColumn.pack(side='left', fill='both')
            characterColumn = tk.Frame(characterTypeColumn)
            characterColumn.pack(fill='both')
            characterTitleWindow = tk.Frame(master.columnTitles)
            characterTitleWindow.pack(side='left', fill='both')
            tk.Label(characterTitleWindow, text=_('Characters'), bg=self._kwargs['color_character_heading']).pack(fill='x')
            for crId in self._novel.tree.get_children(CR_ROOT):
                row = 1
                bgr = row % 2
                bgc = col % 2
                characterTitle = fill_str(self._novel.characters[crId].title)
                tk.Label(characterTitleWindow,
                         text=characterTitle,
                         bg=colorsBackground[bgr][bgc],
                         justify='left',
                         anchor='w'
                         ).pack(side='left', fill='x', expand=True)
                row += 1

                columns.append(tk.Frame(characterColumn))
                columns[col].pack(side='left', fill='both', expand=True)
                for scId in self._characterNodes:
                    bgr = row % 2
                    node = Node(columns[col],
                         colorFalse=colorsBackground[bgr][bgc],
                         colorTrue=self._kwargs['color_character_node']
                         )
                    node.pack(fill='x', expand=True)
                    self._characterNodes[scId][crId] = node
                    row += 1
                bgr = row % 2
                tk.Label(columns[col],
                         text=characterTitle,
                         bg=colorsBackground[bgr][bgc],
                         justify='left',
                         anchor='w'
                         ).pack(fill='x', expand=True)
                col += 1
            tk.Label(characterTypeColumn, text=_('Characters'), bg=self._kwargs['color_character_heading']).pack(fill='x')

        if self._novel.locations:
            locationTypeColumn = tk.Frame(master.display)
            locationTypeColumn.pack(side='left', fill='both')
            locationColumn = tk.Frame(locationTypeColumn)
            locationColumn.pack(fill='both')
            locationTitleWindow = tk.Frame(master.columnTitles)
            locationTitleWindow.pack(side='left', fill='both')
            tk.Label(locationTitleWindow, text=_('Locations'), bg=self._kwargs['color_location_heading']).pack(fill='x')
            for lcId in self._novel.tree.get_children(LC_ROOT):
                row = 1
                bgr = row % 2
                bgc = col % 2
                locationTitle = fill_str(self._novel.locations[lcId].title)
                tk.Label(locationTitleWindow,
                         text=locationTitle,
                         bg=colorsBackground[bgr][bgc],
                         justify='left',
                         anchor='w'
                         ).pack(side='left', fill='x', expand=True)
                row += 1

                columns.append(tk.Frame(locationColumn))
                columns[col].pack(side='left', fill='both', expand=True)
                for scId in self._locationNodes:
                    bgr = row % 2
                    node = Node(columns[col],
                         colorFalse=colorsBackground[bgr][bgc],
                         colorTrue=self._kwargs['color_location_node']
                         )
                    node.pack(fill='x', expand=True)
                    self._locationNodes[scId][lcId] = node
                    row += 1
                bgr = row % 2
                tk.Label(columns[col],
                         text=locationTitle,
                         bg=colorsBackground[bgr][bgc],
                         justify='left',
                         anchor='w'
                         ).pack(fill='x', expand=True)
                col += 1
            tk.Label(locationTypeColumn, text=_('Locations'), bg=self._kwargs['color_location_heading']).pack(fill='x')

        if self._novel.items:
            itemTypeColumn = tk.Frame(master.display)
            itemTypeColumn.pack(side='left', fill='both')
            itemColumn = tk.Frame(itemTypeColumn)
            itemColumn.pack(fill='both')
            itemTitleWindow = tk.Frame(master.columnTitles)
            itemTitleWindow.pack(side='left', fill='both')
            tk.Label(itemTitleWindow, text=_('Items'), bg=self._kwargs['color_item_heading']).pack(fill='x')
            for itId in self._novel.tree.get_children(IT_ROOT):
                row = 1
                bgr = row % 2
                bgc = col % 2
                itemTitle = fill_str(self._novel.items[itId].title)
                tk.Label(itemTitleWindow,
                         text=itemTitle,
                         bg=colorsBackground[bgr][bgc],
                         justify='left',
                         anchor='w'
                         ).pack(side='left', fill='x', expand=True)
                row += 1

                columns.append(tk.Frame(itemColumn))
                columns[col].pack(side='left', fill='both', expand=True)
                for scId in self._itemNodes:
                    bgr = row % 2
                    node = Node(columns[col],
                         colorFalse=colorsBackground[bgr][bgc],
                         colorTrue=self._kwargs['color_item_node']
                         )
                    node.pack(fill='x', expand=True)
                    self._itemNodes[scId][itId] = node
                    row += 1
                bgr = row % 2
                tk.Label(columns[col],
                         text=itemTitle,
                         bg=colorsBackground[bgr][bgc],
                         justify='left',
                         anchor='w'
                         ).pack(fill='x', expand=True)
                col += 1
            tk.Label(itemTypeColumn, text=_('Items'), bg=self._kwargs['color_item_heading']).pack(fill='x')

    def set_nodes(self):
        for scId in self._plotlineNodes:

            for plId in self._novel.plotLines:
                self._plotlineNodes[scId][plId].state = (plId in self._novel.sections[scId].scPlotLines)

            for crId in self._novel.characters:
                self._characterNodes[scId][crId].state = (crId in self._novel.sections[scId].characters)

            for lcId in self._novel.locations:
                self._locationNodes[scId][lcId].state = (lcId in self._novel.sections[scId].locations)

            for itId in self._novel.items:
                self._itemNodes[scId][itId].state = (itId in self._novel.sections[scId].items)

    def get_nodes(self):
        for scId in self._plotlineNodes:

            self._novel.sections[scId].scPlotLines = []
            for plId in self._novel.plotLines:
                plotlineSections = self._novel.plotLines[plId].sections
                if self._plotlineNodes[scId][plId].state:
                    self._novel.sections[scId].scPlotLines.append(plId)
                    if not scId in plotlineSections:
                        plotlineSections.append(scId)
                else:
                    if scId in plotlineSections:
                        plotlineSections.remove(scId)
                    for ppId in list(self._novel.sections[scId].scPlotPoints):
                        if self._novel.sections[scId].scPlotPoints[ppId] == plId:
                            del self._novel.sections[scId].scPlotPoints[ppId]
                            self._novel.plotPoints[ppId].sectionAssoc = None
                self._novel.plotLines[plId].sections = plotlineSections

            scCharacters = self._novel.sections[scId].characters
            for crId in self._novel.characters:
                if self._characterNodes[scId][crId].state:
                    if not crId in scCharacters:
                        scCharacters.append(crId)
                elif crId in scCharacters:
                    scCharacters.remove(crId)
            self._novel.sections[scId].characters = scCharacters

            scLocations = self._novel.sections[scId].locations
            for lcId in self._novel.locations:
                if self._locationNodes[scId][lcId].state:
                    if not lcId in scLocations:
                        scLocations.append(lcId)
                elif lcId in scLocations:
                    scLocations.remove(lcId)
            self._novel.sections[scId].locations = scLocations

            scItems = self._novel.sections[scId].items
            for itId in self._novel.items:
                if self._itemNodes[scId][itId].state:
                    if itId in scItems:
                        scItems.append(itId)
                elif itId in scItems:
                    scItems.remove(itId)

            self._novel.sections[scId].items = scItems

from tkinter import ttk



class TableFrame(ttk.Frame):

    def __init__(self, parent, *args, **kw):

        ttk.Frame.__init__(self, parent, *args, **kw)

        scrollY = ttk.Scrollbar(self, orient='vertical', command=self.yview)
        scrollY.pack(fill='y', side='right', expand=False)
        scrollX = ttk.Scrollbar(self, orient='horizontal', command=self.xview)
        scrollX.pack(fill='x', side='bottom', expand=False)

        leftColFrame = ttk.Frame(self)
        leftColFrame.pack(side='left', fill='both', expand=False)

        self.topLeft = ttk.Frame(leftColFrame)
        self.topLeft.pack(anchor='w', fill='x', expand=False)

        rowTitlesFrame = ttk.Frame(leftColFrame)
        rowTitlesFrame.pack(fill='both', expand=True)
        self._rowTitlesCanvas = tk.Canvas(rowTitlesFrame, bd=0, highlightthickness=0)
        self._rowTitlesCanvas.configure(yscrollcommand=scrollY.set)
        self._rowTitlesCanvas.pack(side='left', fill='both', expand=True)
        self._rowTitlesCanvas.xview_moveto(0)
        self._rowTitlesCanvas.yview_moveto(0)

        self.rowTitles = ttk.Frame(self._rowTitlesCanvas)
        self._rowTitlesCanvas.create_window(0, 0, window=self.rowTitles, anchor='nw', tags="self.rowTitles")

        def _configure_rowTitles(event):
            size = (self.rowTitles.winfo_reqwidth(), self.rowTitles.winfo_reqheight())
            self._rowTitlesCanvas.config(scrollregion="0 0 %s %s" % size)

            if self.rowTitles.winfo_reqwidth() != self._rowTitlesCanvas.winfo_width():
                self._rowTitlesCanvas.config(width=self.rowTitles.winfo_reqwidth())

        self.rowTitles.bind('<Configure>', _configure_rowTitles)

        rightColFrame = ttk.Frame(self)
        rightColFrame.pack(side='left', anchor='nw', fill='both', expand=True)

        columnTitlesFrame = ttk.Frame(rightColFrame)
        columnTitlesFrame.pack(fill='x', anchor='nw', expand=False)
        self._columnTitlesCanvas = tk.Canvas(columnTitlesFrame, bd=0, highlightthickness=0)
        self._columnTitlesCanvas.configure(xscrollcommand=scrollX.set)
        self._columnTitlesCanvas.pack(side='left', fill='both', expand=True)
        self._columnTitlesCanvas.xview_moveto(0)
        self._columnTitlesCanvas.yview_moveto(0)

        self.columnTitles = ttk.Frame(self._columnTitlesCanvas)
        self._columnTitlesCanvas.create_window(0, 0, window=self.columnTitles, anchor='nw', tags="self.columnTitles")

        def _configure_columnTitles(event):
            size = (self.columnTitles.winfo_reqwidth(), self.columnTitles.winfo_reqheight())
            self._columnTitlesCanvas.config(scrollregion="0 0 %s %s" % size)

            if self.columnTitles.winfo_reqwidth() != self._columnTitlesCanvas.winfo_width():
                self._columnTitlesCanvas.config(width=self.columnTitles.winfo_reqwidth())
            if self.columnTitles.winfo_reqheight() != self._columnTitlesCanvas.winfo_height():
                self._columnTitlesCanvas.config(height=self.columnTitles.winfo_reqheight())

        self.columnTitles.bind('<Configure>', _configure_columnTitles)

        displayFrame = ttk.Frame(rightColFrame)
        displayFrame.pack(fill='both', expand=True)
        self._displayCanvas = tk.Canvas(displayFrame, bd=0, highlightthickness=0)
        self._displayCanvas.configure(xscrollcommand=scrollX.set)
        self._displayCanvas.configure(yscrollcommand=scrollY.set)
        self._displayCanvas.pack(side='left', fill='both', expand=True)
        self._displayCanvas.xview_moveto(0)
        self._displayCanvas.yview_moveto(0)

        self.display = ttk.Frame(self._displayCanvas)
        self._displayCanvas.create_window(0, 0, window=self.display, anchor='nw', tags="self.display")

        def _configure_display(event):
            size = (self.display.winfo_reqwidth(), self.display.winfo_reqheight())
            self._displayCanvas.config(scrollregion="0 0 %s %s" % size)
            if self.display.winfo_reqwidth() != self._displayCanvas.winfo_width():
                self._displayCanvas.config(width=self.display.winfo_reqwidth())

        self.display.bind('<Configure>', _configure_display)
        self.bind('<Enter>', self._bind_mousewheel)
        self.bind('<Leave>', self._unbind_mousewheel)

    def destroy(self):
        self.display.unbind('<Configure>')
        self._unbind_mousewheel()
        super().destroy()

    def vertical_scroll(self, event):
        if platform.system() == 'Windows':
            self.yview_scroll(int(-1 * (event.delta / 120)), 'units')
        elif platform.system() == 'Darwin':
            self.yview_scroll(int(-1 * event.delta), 'units')
        else:
            if event.num == 4:
                self.yview_scroll(-1, 'units')
            elif event.num == 5:
                self.yview_scroll(1, 'units')

    def horizontal_scroll(self, event):
        if platform.system() == 'Windows':
            self.xview_scroll(int(-1 * (event.delta / 120)), 'units')
        elif platform.system() == 'Darwin':
            self.xview_scroll(int(-1 * event.delta), 'units')
        else:
            if event.num == 4:
                self.xview_scroll(-1, 'units')
            elif event.num == 5:
                self.xview_scroll(1, 'units')

    def xview(self, *args):
        self._columnTitlesCanvas.xview(*args)
        self._displayCanvas.xview(*args)

    def xview_scroll(self, *args):
        if not self._displayCanvas.xview() == (0.0, 1.0):
            self._columnTitlesCanvas.xview_scroll(*args)
            self._displayCanvas.xview_scroll(*args)

    def yview(self, *args):
        self._rowTitlesCanvas.yview(*args)
        self._displayCanvas.yview(*args)

    def yview_scroll(self, *args):
        if not self._displayCanvas.yview() == (0.0, 1.0):
            self._rowTitlesCanvas.yview_scroll(*args)
            self._displayCanvas.yview_scroll(*args)

    def _bind_mousewheel(self, event=None):
        if platform.system() in ('Linux', 'FreeBSD'):
            self._rowTitlesCanvas.bind_all('<Button-4>', self.vertical_scroll)
            self._rowTitlesCanvas.bind_all('<Button-5>', self.vertical_scroll)
            self._displayCanvas.bind_all('<Button-4>', self.vertical_scroll)
            self._displayCanvas.bind_all('<Button-5>', self.vertical_scroll)

            self._rowTitlesCanvas.bind_all('<Shift-Button-4>', self.horizontal_scroll)
            self._rowTitlesCanvas.bind_all('<Shift-Button-5>', self.horizontal_scroll)
            self._displayCanvas.bind_all('<Shift-Button-4>', self.horizontal_scroll)
            self._displayCanvas.bind_all('<Shift-Button-5>', self.horizontal_scroll)
        else:
            self._rowTitlesCanvas.bind_all('<MouseWheel>', self.vertical_scroll)
            self._displayCanvas.bind_all('<MouseWheel>', self.vertical_scroll)

            self._rowTitlesCanvas.bind_all('<Shift-MouseWheel>', self.horizontal_scroll)
            self._displayCanvas.bind_all('<Shift-MouseWheel>', self.horizontal_scroll)

    def _unbind_mousewheel(self, event=None):
        if platform.system() in ('Linux', 'FreeBSD'):
            self._rowTitlesCanvas.unbind_all('<Button-4>')
            self._rowTitlesCanvas.unbind_all('<Button-5>')
            self._displayCanvas.unbind_all('<Button-4>')
            self._displayCanvas.unbind_all('<Button-5>')

            self._rowTitlesCanvas.unbind_all('<Shift-Button-4>')
            self._rowTitlesCanvas.unbind_all('<Shift-Button-5>')
            self._displayCanvas.unbind_all('<Shift-Button-4>')
            self._displayCanvas.unbind_all('<Shift-Button-5>')
        else:
            self._rowTitlesCanvas.unbind_all('<MouseWheel>')
            self._displayCanvas.unbind_all('<MouseWheel>')

            self._rowTitlesCanvas.unbind_all('<Shift-MouseWheel>')
            self._displayCanvas.unbind_all('<Shift-MouseWheel>')



class TableManager(ViewComponentBase, tk.Toplevel):

    def __init__(self, model, view, controller, manager, **kwargs):
        ViewComponentBase.__init__(self, model, view, controller)
        tk.Toplevel.__init__(self)

        self._manager = manager
        self._kwargs = kwargs

        self._statusText = ''

        self.geometry(kwargs['window_geometry'])
        self.lift()
        self.focus()

        self._ui.register_client(self)

        if PLATFORM != 'win':
            self.bind(KEYS.QUIT_PROGRAM[0], self.on_quit)
        self.protocol("WM_DELETE_WINDOW", self.on_quit)

        self.mainMenu = tk.Menu(self)
        self.config(menu=self.mainMenu)

        self.mainWindow = ttk.Frame(self)
        self.mainWindow.pack(fill='both', expand=True)
        self.tableFrame = TableFrame(self.mainWindow)

        if self._mdl.novel is not None:
            self._relationsTable = RelationsTable(self.tableFrame, self._mdl.novel, **self._kwargs)
            self._relationsTable.set_nodes()
        self.isOpen = True
        self.tableFrame.pack(fill='both', expand=True, padx=2, pady=2)

        self._skipUpdate = False
        self.bind(MOUSE.TOGGLE_STATE, self.on_element_change)

        ttk.Button(self, text=_('Close'), command=self.on_quit).pack(side='right', padx=5, pady=5)

    def on_quit(self, event=None):
        self.isOpen = False
        self._manager.kwargs['window_geometry'] = self.winfo_geometry()
        self.tableFrame.destroy()
        self._ui.unregister_client(self)
        self.destroy()

    def refresh(self):
        if self.isOpen:
            if not self._skipUpdate:
                self.tableFrame.pack_forget()
                self.tableFrame.destroy()
                self.tableFrame = TableFrame(self.mainWindow)
                self.tableFrame.pack(fill='both', expand=True, padx=2, pady=2)
                self._relationsTable.draw_matrix(self.tableFrame)
                self._relationsTable.set_nodes()

    def on_element_change(self, event=None):
        self._skipUpdate = True
        self._relationsTable.get_nodes()
        self._skipUpdate = False


def set_icon(widget, icon='logo', path=None, default=True):
    if path is None:
        path = os.path.dirname(sys.argv[0])
        if not path:
            path = '.'
        path = f'{path}/icons'
    try:
        pic = tk.PhotoImage(file=f'{path}/{icon}.png')
        widget.iconphoto(default, pic)
    except:
        return False

    return True



class TooltipBase:

    def __init__(self, anchor_widget):
        self.anchor_widget = anchor_widget
        self.tipwindow = None

    def __del__(self):
        self.hidetip()

    def showtip(self):
        if self.tipwindow:
            return
        self.tipwindow = tw = tk.Toplevel(self.anchor_widget)
        tw.wm_overrideredirect(1)
        try:
            tw.tk.call("::tk::unsupported::MacWindowStyle", "style", tw._w,
                       "help", "noActivates")
        except tk.TclError:
            pass

        self.position_window()
        self.showcontents()
        self.tipwindow.update_idletasks()  # Needed on MacOS -- see #34275.
        self.tipwindow.lift()  # work around bug in Tk 8.5.18+ (issue #24570)

    def position_window(self):
        x, y = self.get_position()
        root_x = self.anchor_widget.winfo_rootx() + x
        root_y = self.anchor_widget.winfo_rooty() + y
        self.tipwindow.wm_geometry("+%d+%d" % (root_x, root_y))

    def get_position(self):
        return 20, self.anchor_widget.winfo_height() + 1

    def showcontents(self):
        raise NotImplementedError

    def hidetip(self):
        tw = self.tipwindow
        self.tipwindow = None
        if tw:
            try:
                tw.destroy()
            except tk.TclError:  # pragma: no cover
                pass


class OnHoverTooltipBase(TooltipBase):

    def __init__(self, anchor_widget, hover_delay=1000):
        super().__init__(anchor_widget)
        self.hover_delay = hover_delay

        self._after_id = None
        self._id1 = self.anchor_widget.bind("<Enter>", self._show_event)
        self._id2 = self.anchor_widget.bind("<Leave>", self._hide_event)
        self._id3 = self.anchor_widget.bind("<Button>", self._hide_event)

    def __del__(self):
        try:
            self.anchor_widget.unbind("<Enter>", self._id1)
            self.anchor_widget.unbind("<Leave>", self._id2)  # pragma: no cover
            self.anchor_widget.unbind("<Button>", self._id3)  # pragma: no cover
        except tk.TclError:
            pass
        super().__del__()

    def _show_event(self, event=None):
        if self.hover_delay:
            self.schedule()
        else:
            self.showtip()

    def _hide_event(self, event=None):
        self.hidetip()

    def schedule(self):
        self.unschedule()
        self._after_id = self.anchor_widget.after(self.hover_delay,
                                                  self.showtip)

    def unschedule(self):
        after_id = self._after_id
        self._after_id = None
        if after_id:
            self.anchor_widget.after_cancel(after_id)

    def hidetip(self):
        try:
            self.unschedule()
        except tk.TclError:  # pragma: no cover
            pass
        super().hidetip()


class Hovertip(OnHoverTooltipBase):
    "A tooltip that pops up when a mouse hovers over an anchor widget."

    def __init__(self, anchor_widget, text, hover_delay=1000):
        super().__init__(anchor_widget, hover_delay=hover_delay)
        self.text = text

    def showcontents(self):
        label = tk.Label(self.tipwindow, text=self.text, justify='left',
                      background="#ffffe0", relief='solid', borderwidth=1)
        label.pack()



class Matrix(PluginBase):
    FEATURE = _('Matrix')
    SETTINGS = dict(
        window_geometry='600x800',
        color_bg_00='gray80',
        color_bg_01='gray85',
        color_bg_10='gray95',
        color_bg_11='white',
        color_arc_heading='deepSkyBlue',
        color_arc_node='deepSkyBlue3',
        color_character_heading='goldenrod1',
        color_character_node='goldenrod3',
        color_location_heading='coral1',
        color_location_node='coral3',
        color_item_heading='aquamarine1',
        color_item_node='aquamarine3',
    )
    OPTIONS = {}

    def __init__(self, model, view, controller):
        super().__init__(model, view, controller)
        self._matrixViewer = None

        try:
            homeDir = str(Path.home()).replace('\\', '/')
            configDir = f'{homeDir}/.mdnovel/config'
        except:
            configDir = '.'
        self.iniFile = f'{configDir}/matrix.ini'
        self.configuration = self._mdl.nvService.make_configuration(
            settings=self.SETTINGS,
            options=self.OPTIONS
            )
        self.configuration.read(self.iniFile)
        self.kwargs = {}
        self.kwargs.update(self.configuration.settings)
        self.kwargs.update(self.configuration.options)

        self._ui.toolsMenu.add_command(label=self.FEATURE, command=self._start_viewer)
        self._ui.toolsMenu.entryconfig(self.FEATURE, state='disabled')

        self._configure_toolbar()

    def disable_menu(self):
        self._ui.toolsMenu.entryconfig(self.FEATURE, state='disabled')
        self._matrixButton.config(state='disabled')

    def enable_menu(self):
        self._ui.toolsMenu.entryconfig(self.FEATURE, state='normal')
        self._matrixButton.config(state='normal')

    def on_close(self):
        self.on_quit()

    def on_quit(self):
        if self._matrixViewer:
            if self._matrixViewer.isOpen:
                self._matrixViewer.on_quit()

        for keyword in self.kwargs:
            if keyword in self.configuration.options:
                self.configuration.options[keyword] = self.kwargs[keyword]
            elif keyword in self.configuration.settings:
                self.configuration.settings[keyword] = self.kwargs[keyword]
        self.configuration.write(self.iniFile)

    def _configure_toolbar(self):

        prefs = self._ctrl.get_preferences()
        if prefs.get('large_icons', False):
            size = 24
        else:
            size = 16
        try:
            iconPath = f'{os.path.dirname(sys.argv[0])}/icons/{size}'
        except:
            iconPath = None
        try:
            matrixIcon = tk.PhotoImage(file=f'{iconPath}/matrix.png')
        except:
            matrixIcon = None

        tk.Frame(self._ui.toolbar.buttonBar, bg='light gray', width=1).pack(side='left', fill='y', padx=4)

        self._matrixButton = ttk.Button(
            self._ui.toolbar.buttonBar,
            text=_('Matrix'),
            image=matrixIcon,
            command=self._start_viewer
            )
        self._matrixButton.pack(side='left')
        self._matrixButton.image = matrixIcon

        if not prefs['enable_hovertips']:
            return

        Hovertip(self._matrixButton, self._matrixButton['text'])

    def _start_viewer(self):
        if not self._mdl.prjFile:
            return

        if self._matrixViewer:
            if self._matrixViewer.isOpen:
                if self._matrixViewer.state() == 'iconic':
                    self._matrixViewer.state('normal')
                self._matrixViewer.lift()
                self._matrixViewer.focus()
                return

        self._matrixViewer = TableManager(self._mdl, self._ui, self._ctrl, self, **self.kwargs)
        self._matrixViewer.title(f'{self._mdl.novel.title} - {self.FEATURE}')
        set_icon(self._matrixViewer, icon='mLogo32', default=False)

from pathlib import Path

from datetime import date
from tkinter import ttk



class ProgressViewer(ViewComponentBase, tk.Toplevel):

    def __init__(self, model, view, controller, manager, **kwargs):
        ViewComponentBase.__init__(self, model, view, controller)
        tk.Toplevel.__init__(self)

        self._ui.register_client(self)
        self._manager = manager

        self.geometry(self._manager.kwargs['window_geometry'])
        self.lift()
        self.focus()
        self.protocol("WM_DELETE_WINDOW", self.on_quit)
        if PLATFORM != 'win':
            self.bind(KEYS.QUIT_PROGRAM[0], self.on_quit)

        columns = (
            'date',
            'wordCount',
            'wordCountDelta',
            'totalWordCount',
            'totalWordCountDelta',
            'spacer',
            )
        self.tree = ttk.Treeview(self, selectmode='none', columns=columns)
        scrollY = ttk.Scrollbar(self.tree, orient='vertical', command=self.tree.yview)
        self.tree.configure(yscrollcommand=scrollY.set)
        scrollY.pack(side='right', fill='y')
        self.tree.pack(fill='both', expand=True)
        self.tree.heading('date', text=_('Date'))
        self.tree.heading('wordCount', text=_('Words total'))
        self.tree.heading('wordCountDelta', text=_('Daily'))
        self.tree.heading('totalWordCount', text=_('With unused'))
        self.tree.heading('totalWordCountDelta', text=_('Daily'))
        self.tree.column('#0', width=0)
        self.tree.column('date', anchor='center', width=self._manager.kwargs['date_width'], stretch=False)
        self.tree.column('wordCount', anchor='center', width=self._manager.kwargs['wordcount_width'], stretch=False)
        self.tree.column('wordCountDelta', anchor='center', width=self._manager.kwargs['wordcount_delta_width'], stretch=False)
        self.tree.column('totalWordCount', anchor='center', width=self._manager.kwargs['totalcount_width'], stretch=False)
        self.tree.column('totalWordCountDelta', anchor='center', width=self._manager.kwargs['totalcount_delta_width'], stretch=False)

        self.tree.tag_configure('positive', foreground='black')
        self.tree.tag_configure('negative', foreground='red')
        self.isOpen = True
        self._build_tree()

        ttk.Button(self, text=_('Close'), command=self.on_quit).pack(side='right', padx=5, pady=5)

    def _build_tree(self):
        self._reset_tree()
        wcLog = {}

        for wcDate in self._mdl.prjFile.wcLog:
            sessionDate = date.fromisoformat(wcDate).strftime('%x')
            wcLog[sessionDate] = self._mdl.prjFile.wcLog[wcDate]

        for wcDate in self._mdl.prjFile.wcLogUpdate:
            sessionDate = date.fromisoformat(wcDate).strftime('%x')
            wcLog[sessionDate] = self._mdl.prjFile.wcLogUpdate[wcDate]

        newCountInt, newTotalCountInt = self._mdl.prjFile.count_words()
        newCount = str(newCountInt)
        newTotalCount = str(newTotalCountInt)
        today = date.today().strftime('%x')
        wcLog[today] = [newCount, newTotalCount]

        lastCount = 0
        lastTotalCount = 0
        for wc in wcLog:
            columns = []
            nodeTags = ()
            countInt = int(wcLog[wc][0])
            countDiffInt = countInt - lastCount
            totalCountInt = int(wcLog[wc][1])
            totalCountDiffInt = totalCountInt - lastTotalCount
            if countDiffInt == 0 and totalCountDiffInt == 0:
                continue

            if countDiffInt > 0:
                nodeTags = ('positive')
            else:
                nodeTags = ('negative')
            columns = [
                wc,
                str(wcLog[wc][0]),
                str(countDiffInt),
                str(wcLog[wc][1]),
                str(totalCountDiffInt),
                ]
            lastCount = countInt
            lastTotalCount = totalCountInt
            startIndex = '0'
            self.tree.insert('', startIndex, iid=wc, values=columns, tags=nodeTags, open=True)

    def on_quit(self, event=None):
        self._ui.unregister_client(self)
        self._manager.kwargs['window_geometry'] = self.winfo_geometry()
        self._manager.kwargs['date_width'] = self.tree.column('date', 'width')
        self._manager.kwargs['wordcount_width'] = self.tree.column('wordCount', 'width')
        self._manager.kwargs['wordcount_delta_width'] = self.tree.column('wordCountDelta', 'width')
        self._manager.kwargs['totalcount_width'] = self.tree.column('totalWordCount', 'width')
        self._manager.kwargs['totalcount_delta_width'] = self.tree.column('totalWordCountDelta', 'width')
        self.destroy()
        self.isOpen = False

    def refresh(self):
        self._build_tree()

    def _reset_tree(self):
        for child in self.tree.get_children(''):
            self.tree.delete(child)



class Progress(PluginBase):
    FEATURE = _('Daily progress log')
    SETTINGS = dict(
        window_geometry='510x440',
        date_width=100,
        wordcount_width=100,
        wordcount_delta_width=100,
        totalcount_width=100,
        totalcount_delta_width=100,
    )
    OPTIONS = {}

    def __init__(self, model, view, controller):
        super().__init__(model, view, controller)
        self._progress_viewer = None

        try:
            homeDir = str(Path.home()).replace('\\', '/')
            configDir = f'{homeDir}/.mdnovel/config'
        except:
            configDir = '.'
        self.iniFile = f'{configDir}/progress.ini'
        self.configuration = self._mdl.nvService.make_configuration(
            settings=self.SETTINGS,
            options=self.OPTIONS
            )
        self.configuration.read(self.iniFile)
        self.kwargs = {}
        self.kwargs.update(self.configuration.settings)
        self.kwargs.update(self.configuration.options)

        self._ui.toolsMenu.add_command(label=self.FEATURE, command=self._start_viewer)
        self._ui.toolsMenu.entryconfig(self.FEATURE, state='disabled')

    def disable_menu(self):
        self._ui.toolsMenu.entryconfig(self.FEATURE, state='disabled')

    def enable_menu(self):
        self._ui.toolsMenu.entryconfig(self.FEATURE, state='normal')

    def on_close(self):
        self.on_quit()

    def on_quit(self):
        if self._progress_viewer:
            if self._progress_viewer.isOpen:
                self._progress_viewer.on_quit()

        for keyword in self.kwargs:
            if keyword in self.configuration.options:
                self.configuration.options[keyword] = self.kwargs[keyword]
            elif keyword in self.configuration.settings:
                self.configuration.settings[keyword] = self.kwargs[keyword]
        self.configuration.write(self.iniFile)

    def _start_viewer(self):
        if self._progress_viewer:
            if self._progress_viewer.isOpen:
                if self._progress_viewer.state() == 'iconic':
                    self._progress_viewer.state('normal')
                self._progress_viewer.lift()
                self._progress_viewer.focus()
                self._progress_viewer.build_tree()
                return

        self._progress_viewer = ProgressViewer(self._mdl, self._ui, self._ctrl, self)
        self._progress_viewer.title(f'{self._mdl.novel.title} - {self.FEATURE}')
        set_icon(self._progress_viewer, icon='wLogo32', default=False)

from pathlib import Path
from tkinter import filedialog
from tkinter import messagebox



class MdTemplate:
    DESCRIPTION = _('Story Template')
    EXTENSION = '.md'

    def __init__(self, filePath, model, controller):
        self.filePath = filePath
        self._mdl = model
        self._ctrl = controller

    def read(self):
        try:
            with open(self.filePath, 'r', encoding='utf-8') as f:
                mdLines = f.readlines()
        except(FileNotFoundError):
            raise Error(f'{_("File not found")}: "{norm_path(self.filePath)}".')
        except:
            raise Error(f'{_("Cannot read file")}: "{norm_path(self.filePath)}".')

        if self._mdl.novel.chapters:
            self.list_stages(mdLines)
        else:
            self.create_chapter_structure(mdLines)

    def create_chapter_structure(self, mdLines):
        i = 0
        chId = CH_ROOT
        addChapter = True
        newElement = None
        notes = []
        for mdLine in mdLines:
            mdLine = mdLine.strip()
            if mdLine.startswith('#'):
                if newElement is not None:
                    newElement.notes = ''.join(notes).strip().replace('  ', ' ')
                    notes = []
                    newElement = None
                if mdLine.startswith('## '):
                    if addChapter:
                        i += 1
                        chId = self._ctrl.add_chapter(targetNode=chId, title=f"{_('Chapter')} {i}", chLevel=2, chType=0)
                        scId = chId
                    newTitle = mdLine[3:].strip()
                    scId = self._ctrl.add_stage(targetNode=scId, title=newTitle, scType=3)
                    newElement = self._mdl.novel.sections[scId]
                    scId = self._ctrl.add_section(targetNode=scId, title=_('New Section'), scType=0, status=1)
                    addChapter = True
                elif mdLine.startswith('# '):
                    i += 1
                    chId = self._ctrl.add_chapter(targetNode=chId, title=f"{_('Chapter')} {i}", chLevel=2, chType=0)
                    newTitle = mdLine[2:].strip()
                    scId = self._ctrl.add_stage(targetNode=chId, title=newTitle, scType=2)
                    newElement = self._mdl.novel.sections[scId]
                    addChapter = False
                else:
                    scId = None
            elif mdLine:
                notes.append(f'{mdLine} ')
            else:
                notes.append('\n')
        try:
            newElement.notes = ''.join(notes).strip().replace('  ', ' ')
        except AttributeError:
            pass

    def list_stages(self, mdLines):
        chId = self._ctrl.add_chapter(targetNode=CH_ROOT, title=_('Stages'), chLevel=2, chType=3)
        scId = chId
        newElement = None
        notes = []
        for mdLine in mdLines:
            mdLine = mdLine.strip()
            if mdLine.startswith('#'):
                if newElement is not None:
                    newElement.notes = ''.join(notes).strip().replace('  ', ' ')
                    notes = []
                    newElement = None
                if mdLine.startswith('## '):
                    newTitle = mdLine[3:].strip()
                    scId = self._ctrl.add_stage(targetNode=scId, title=newTitle, scType=3)
                elif mdLine.startswith('# '):
                    newTitle = mdLine[2:].strip()
                    scId = self._ctrl.add_stage(targetNode=scId, title=newTitle, scType=2)
                else:
                    scId = None
                if scId:
                    newElement = self._mdl.novel.sections[scId]
            elif mdLine:
                notes.append(f'{mdLine} ')
            else:
                notes.append('\n')
        try:
            newElement.notes = ''.join(notes).strip().replace('  ', ' ')
        except AttributeError:
            pass

    def write(self):
        mdLines = []
        for chId in self._mdl.novel.tree.get_children(CH_ROOT):
            for scId in self._mdl.novel.tree.get_children(chId):
                if self._mdl.novel.sections[scId].scType == 2:
                    mdLines.append(f'# {self._mdl.novel.sections[scId].title}')
                    notes = self._mdl.novel.sections[scId].notes
                    if notes:
                        mdLines.append(notes.replace('\n', '\n\n'))
                elif self._mdl.novel.sections[scId].scType == 3:
                    mdLines.append(f'## {self._mdl.novel.sections[scId].title}')
                    notes = self._mdl.novel.sections[scId].notes
                    if notes:
                        mdLines.append(notes.replace('\n', '\n\n'))

        content = '\n\n'.join(mdLines)
        try:
            with open(self.filePath, 'w', encoding='utf-8') as f:
                f.write(content)
        except:
            raise Error(f'{_("Cannot write file")}: "{norm_path(self.filePath)}".')



class Templates(PluginBase):
    FEATURE = _('Story Templates')

    def __init__(self, model, view, controller):
        super().__init__(model, view, controller)
        try:
            homeDir = str(Path.home()).replace('\\', '/')
            self._templateDir = f'{homeDir}/.mdnovel/templates'
        except:
            self._templateDir = '.'

        self._templatesMenu = tk.Menu(self._ui.toolsMenu, tearoff=0)
        self._templatesMenu.add_command(label=f"{_('Load')}...", command=self._load_template)
        self._templatesMenu.add_command(label=f"{_('Save')}...", command=self._save_template)
        self._templatesMenu.add_command(label=_('Open folder'), command=self._open_folder)

        self._ui.newMenu.add_command(label=_('Create from template...'), command=self._new_project)

        self._ui.toolsMenu.add_cascade(label=self.FEATURE, menu=self._templatesMenu)
        self._fileTypes = [(MdTemplate.DESCRIPTION, MdTemplate.EXTENSION)]

    def disable_menu(self):
        self._templatesMenu.entryconfig(f"{_('Load')}...", state='disabled')
        self._templatesMenu.entryconfig(f"{_('Save')}...", state='disabled')

    def enable_menu(self):
        self._templatesMenu.entryconfig(f"{_('Load')}...", state='normal')
        self._templatesMenu.entryconfig(f"{_('Save')}...", state='normal')

    def _load_template(self):
        fileName = filedialog.askopenfilename(
            filetypes=self._fileTypes,
            defaultextension=self._fileTypes[0][1],
            initialdir=self._templateDir
            )
        if fileName:
            try:
                templates = MdTemplate(fileName, self._mdl, self._ctrl)
                templates.read()
            except Error as ex:
                messagebox.showerror(_('Template loading aborted'), str(ex))

    def _new_project(self):
        self._ctrl.new_project()
        self._load_template()

    def _open_folder(self):
        try:
            os.startfile(norm_path(self._templateDir))
        except:
            try:
                os.system('xdg-open "%s"' % norm_path(self._templateDir))
            except:
                try:
                    os.system('open "%s"' % norm_path(self._templateDir))
                except:
                    pass

    def _save_template(self):
        fileName = filedialog.asksaveasfilename(filetypes=self._fileTypes,
                                              defaultextension=self._fileTypes[0][1],
                                              initialdir=self._templateDir)
        if not fileName:
            return

        try:
            templates = MdTemplate(fileName, self._mdl, self._ctrl)
            templates.write()
        except Error as ex:
            messagebox.showerror(_('Cannot save template'), str(ex))

        self._ui.set_status(_('Template saved.'))


from tkinter import ttk

from tkinter import ttk


class LabelCombo(ttk.Frame):

    def __init__(self, parent, text, textvariable, values, lblWidth=10):
        super().__init__(parent)
        self.pack(fill='x')
        self._label = ttk.Label(self, text=text, anchor='w', width=lblWidth)
        self._label.pack(side='left')
        self.combo = ttk.Combobox(self, textvariable=textvariable, values=values)
        self.combo.pack(side='left', fill='x', expand=True)

    def current(self):
        return self.combo.current()

    def config(self, **kwargs):
        self.configure(**kwargs)

    def configure(self, text=None, values=None, state=None):
        if text is not None:
            self._label['text'] = text
        if values is not None:
            self.combo['values'] = values
        if state is not None:
            self.combo.config(state=state)


class SettingsWindow(tk.Toplevel):

    def __init__(self, view, prefs, extraThemes, size, **kw):
        self._ui = view
        self._prefs = prefs
        self._extraThemes = extraThemes
        super().__init__(**kw)
        self.title(_('Theme Changer'))
        self.geometry(size)
        self.grab_set()
        self.focus()
        window = ttk.Frame(self)
        window.pack(fill='both')

        theme = self._ui.guiStyle.theme_use()
        themeList = list(self._ui.guiStyle.theme_names())
        themeList.sort()
        self._theme = tk.StringVar(value=theme)
        self._theme.trace('w', self._change_theme)
        themeCombobox = LabelCombo(
            window,
            text=_('GUI Theme'),
            textvariable=self._theme,
            values=themeList,
            lblWidth=20
            )
        themeCombobox.pack(padx=5, pady=5)

        ttk.Button(window, text=_('Close'), command=self.destroy).pack(side='right', padx=5, pady=5)

    def _change_theme(self, *args, **kwargs):
        theme = self._theme.get()
        self._prefs['gui_theme'] = theme
        if self._extraThemes:
            self._ui.guiStyle.set_theme(self._prefs['gui_theme'])
        else:
            self._ui.guiStyle.theme_use(self._prefs['gui_theme'])


try:
    from ttkthemes import ThemedStyle
    extraThemes = True
except ModuleNotFoundError:
    extraThemes = False


class Themes(PluginBase):

    def __init__(self, model, view, controller):
        super().__init__(model, view, controller)
        prefs = self._ctrl.get_preferences()
        __, x, y = self._ui.root.geometry().split('+')
        offset = 300
        windowGeometry = f'+{int(x)+offset}+{int(y)+offset}'
        if extraThemes:
            self._ui.guiStyle = ThemedStyle(self._ui.root)
        if not prefs.get('gui_theme', ''):
            prefs['gui_theme'] = self._ui.guiStyle.theme_use()

        if not prefs['gui_theme'] in self._ui.guiStyle.theme_names():
            prefs['gui_theme'] = self._ui.guiStyle.theme_use()
        if extraThemes:
            self._ui.guiStyle.set_theme(prefs['gui_theme'])
        else:
            self._ui.guiStyle.theme_use(prefs['gui_theme'])

        self._ui.viewMenu.insert_command(
            _('Options'),
            label=_('Change theme'),
            command=lambda: SettingsWindow(view, prefs, extraThemes, windowGeometry)
            )
        self._ui.viewMenu.insert_separator(_('Options'))

from datetime import datetime
from pathlib import Path
from tkinter import filedialog
from tkinter import messagebox
from tkinter import ttk

from datetime import datetime
from datetime import timedelta



def fix_iso_dt(tlDateTime):
    if tlDateTime.startswith('-'):
        tlDateTime = tlDateTime.strip('-')
        isBc = True
    else:
        isBc = False
    dt = tlDateTime.split('-', 1)
    dt[0] = dt[0].zfill(4)
    tlDateTime = ('-').join(dt)
    if isBc:
        tlDateTime = f'-{tlDateTime}'
    return tlDateTime
from datetime import date, datetime, timedelta, MINYEAR

import xml.etree.ElementTree as ET


class SectionEvent(Section):
    defaultDateTime = '1900-01-01 00:00:00'
    sectionColor = '170,240,160'

    def __init__(self, section):
        super().__init__()
        self.scType = section.scType
        self.scene = section.scene
        self.status = section.status
        self.appendToPrev = section.appendToPrev
        self.goal = section.goal
        self.conflict = section.conflict
        self.outcome = section.outcome
        self.plotlineNotes = section.plotlineNotes
        self.date = section.date
        self.time = section.time
        self.day = section.day
        self.lastsMinutes = section.lastsMinutes
        self.lastsHours = section.lastsHours
        self.lastsDays = section.lastsDays
        self.characters = section.characters
        self.locations = section.locations
        self.items = section.items

        self.title = section.title
        self.desc = section.desc
        self.sectionContent = section.sectionContent
        self.notes = section.notes
        self.tags = section.tags
        self.wordCount = section.wordCount

        self.contId = None
        self._startDateTime = None
        self._endDateTime = None

        self.NULL_DATE = section.NULL_DATE
        self.NULL_TIME = section.NULL_TIME

    def set_date_time(self, startDateTime, endDateTime, isUnspecific):
        self._startDateTime = startDateTime
        self._endDateTime = endDateTime

        dtIsValid = True

        dt = startDateTime.split(' ')
        if dt[0].startswith('-'):
            startYear = -1 * int(dt[0].split('-')[1])
            dtIsValid = False
        else:
            startYear = int(dt[0].split('-')[0])
        if startYear < MINYEAR:
            self.date = self.NULL_DATE
            self.time = self.NULL_TIME
            dtIsValid = False
        else:
            self.date = dt[0]
            self.time = dt[1]
        if dtIsValid:
            sectionStart = datetime.fromisoformat(startDateTime)
            sectionEnd = datetime.fromisoformat(endDateTime)
            sectionDuration = sectionEnd - sectionStart
            lastsHours = sectionDuration.seconds // 3600
            lastsMinutes = (sectionDuration.seconds % 3600) // 60
            self.lastsDays = str(sectionDuration.days)
            self.lastsHours = str(lastsHours)
            self.lastsMinutes = str(lastsMinutes)
            if isUnspecific:
                try:
                    sectionDate = date.fromisoformat(self.date)
                    referenceDate = date.fromisoformat(self.defaultDateTime.split(' ')[0])
                    self.day = str((sectionDate - referenceDate).days)
                except:
                    self.day = None
                self.date = None

    def merge_date_time(self, source, defaultDay=0):
        if source.date is not None and source.date != self.NULL_DATE:
            if source.time:
                self._startDateTime = f'{source.date} {source.time}'
            else:
                self._startDateTime = f'{source.date} 00:00:00'
        elif source.date is None:
            if source.day:
                dayInt = int(source.day)
            else:
                dayInt = defaultDay
            if source.time:
                startTime = source.time
            else:
                startTime = '00:00:00'
            sectionDelta = timedelta(days=dayInt)
            defaultDate = self.defaultDateTime.split(' ')[0]
            startDate = (date.fromisoformat(defaultDate) + sectionDelta).isoformat()
            self._startDateTime = f'{startDate} {startTime}'
        elif self._startDateTime is None:
            self._startDateTime = self.defaultDateTime
        else:
            pass

        if source.date is not None and source.date == self.NULL_DATE:
            if self._endDateTime is None:
                self._endDateTime = self._startDateTime
        else:
            if source.lastsDays:
                lastsDays = int(source.lastsDays)
            else:
                lastsDays = 0
            if source.lastsHours:
                lastsSeconds = int(source.lastsHours) * 3600
            else:
                lastsSeconds = 0
            if source.lastsMinutes:
                lastsSeconds += int(source.lastsMinutes) * 60
            sectionDuration = timedelta(days=lastsDays, seconds=lastsSeconds)
            sectionStart = datetime.fromisoformat(self._startDateTime)
            sectionEnd = sectionStart + sectionDuration
            self._endDateTime = sectionEnd.isoformat(' ')
        if self._startDateTime > self._endDateTime:
            self._endDateTime = self._startDateTime

    def build_branch(self, xmlEvent, scId, dtMin, dtMax):
        scIndex = 0
        try:
            xmlEvent.find('start').text = self._startDateTime
        except(AttributeError):
            ET.SubElement(xmlEvent, 'start').text = self._startDateTime
        if (not dtMin) or (self._startDateTime < dtMin):
            dtMin = self._startDateTime
        scIndex += 1
        try:
            xmlEvent.find('end').text = self._endDateTime
        except(AttributeError):
            ET.SubElement(xmlEvent, 'end').text = self._endDateTime
        if (not dtMax) or (self._endDateTime > dtMax):
            dtMax = self._endDateTime
        scIndex += 1
        if not self.title:
            self.title = f'Unnamed section ID{scId}'
        try:
            xmlEvent.find('text').text = self.title
        except(AttributeError):
            ET.SubElement(xmlEvent, 'text').text = self.title
        scIndex += 1
        if xmlEvent.find('progress') is None:
            ET.SubElement(xmlEvent, 'progress').text = '0'
        scIndex += 1
        if xmlEvent.find('fuzzy') is None:
            ET.SubElement(xmlEvent, 'fuzzy').text = 'False'
        scIndex += 1
        if xmlEvent.find('fuzzy_start') is not None:
            scIndex += 1
        if xmlEvent.find('fuzzy_end') is not None:
            scIndex += 1
        if xmlEvent.find('locked') is None:
            ET.SubElement(xmlEvent, 'locked').text = 'False'
        scIndex += 1
        if xmlEvent.find('ends_today') is None:
            ET.SubElement(xmlEvent, 'ends_today').text = 'False'
        scIndex += 1
        if self.desc is not None:
            try:
                xmlEvent.find('description').text = self.desc
            except(AttributeError):
                if xmlEvent.find('labels') is None:
                    ET.SubElement(xmlEvent, 'description').text = self.desc
                else:
                    if xmlEvent.find('category') is not None:
                        scIndex += 1
                    desc = ET.Element('description')
                    desc.text = self.desc
                    xmlEvent.insert(scIndex, desc)
        elif xmlEvent.find('description') is not None:
            xmlEvent.remove(xmlEvent.find('description'))
        if xmlEvent.find('labels') is None:
            ET.SubElement(xmlEvent, 'labels').text = scId
        if xmlEvent.find('default_color') is None:
            ET.SubElement(xmlEvent, 'default_color').text = self.sectionColor
        return dtMin, dtMax



class TlFile(File):
    DESCRIPTION = 'Timeline'
    EXTENSION = '.timeline'
    SUFFIX = None

    def __init__(self, filePath, **kwargs):
        super().__init__(filePath, **kwargs)
        self._nvSvc = kwargs['nv_service']
        self._xmlTree = None
        self._sectionMarker = kwargs['section_label']
        SectionEvent.sectionColor = kwargs['section_color']

        try:
            self._newEventSpacing = int(kwargs['new_event_spacing'])
        except:
            self._newEventSpacing = 0

    def read(self):

        def remove_contId(event, text):
            if text:
                match = re.match(r'([\(\[][0-9]+[\)\]])', text)
                if match:
                    contId = match.group()
                    event.contId = contId
                    text = text.split(contId, 1)[1]
            return text

        if self.novel.referenceDate:
            SectionEvent.defaultDateTime = f'{self.novel.referenceDate} 00:00:00'
        else:
            SectionEvent.defaultDateTime = datetime.today().isoformat(' ', 'seconds')

        if not self.novel.sections:
            isOutline = True
        else:
            isOutline = False

        try:
            self._xmlTree = ET.parse(self.filePath)
        except:
            raise Error(f'{_("Can not process file")}: "{norm_path(self.filePath)}".')
        root = self._xmlTree.getroot()
        sectionCount = 0
        scIdsByDate = {}
        for event in root.iter('event'):
            scId = None
            sectionMatch = None
            if event.find('labels') is not None:
                labels = event.find('labels').text
                sectionMatch = re.search(fr'{SECTION_PREFIX}[0-9]+', labels)
                if isOutline and sectionMatch is None:
                    sectionMatch = re.search(self._sectionMarker, labels)
            if sectionMatch is None:
                continue

            sectionDate = None
            if isOutline:
                sectionCount += 1
                sectionMarker = sectionMatch.group()
                scId = f'{SECTION_PREFIX}{sectionCount}'
                event.find('labels').text = labels.replace(sectionMarker, scId)
                self.novel.sections[scId] = SectionEvent(
                        self._nvSvc.make_section(
                            status=1,
                            scType=0,
                            scene=0,
                        )
                    )

            else:
                try:
                    scId = sectionMatch.group()
                    self.novel.sections[scId] = SectionEvent(self.novel.sections[scId])
                except:
                    continue

            try:
                title = event.find('text').text
                title = remove_contId(self.novel.sections[scId], title)
                title = self._convert_to_mdnov(title)
                self.novel.sections[scId].title = title
            except:
                self.novel.sections[scId].title = f'Section {scId}'
            try:
                self.novel.sections[scId].desc = event.find('description').text
            except:
                pass

            startDateTime = fix_iso_dt(event.find('start').text)
            endDateTime = fix_iso_dt(event.find('end').text)

            if isOutline:
                isUnspecific = False
            else:
                if self.novel.sections[scId].day is not None:
                    isUnspecific = True
                else:
                    isUnspecific = False
            self.novel.sections[scId].set_date_time(startDateTime, endDateTime, isUnspecific)
            if not startDateTime in scIdsByDate:
                scIdsByDate[startDateTime] = []
            scIdsByDate[startDateTime].append(scId)

        srtSections = sorted(scIdsByDate.items())
        if isOutline:
            chId = f'{CHAPTER_PREFIX}1'
            self.novel.chapters[chId] = self._nvSvc.make_chapter(
                chType=0,
                title=f'{_("Chapter")} 1'
                )
            self.novel.tree.append(CH_ROOT, chId)
            for __, scList in srtSections:
                for scId in scList:
                    self.novel.tree.append(chId, scId)
            os.replace(self.filePath, f'{self.filePath}.bak')
            try:
                self._xmlTree.write(self.filePath, xml_declaration=True, encoding='utf-8')
            except:
                os.replace(f'{self.filePath}.bak', self.filePath)
                raise Error(f'{_("Cannot write file")}: "{norm_path(self.filePath)}".')

    def write(self, source):

        def add_contId(event, text):
            if event.contId is not None:
                return f'{event.contId}{text}'
            return text

        def indent(elem, level=0):
            i = f'\n{level * "  "}'
            if len(elem):
                if not elem.text or not elem.text.strip():
                    elem.text = f'{i}  '
                if not elem.tail or not elem.tail.strip():
                    elem.tail = i
                for elem in elem:
                    indent(elem, level + 1)
                if not elem.tail or not elem.tail.strip():
                    elem.tail = i
            else:
                if level and (not elem.tail or not elem.tail.strip()):
                    elem.tail = i

        def set_view_range(dtMin, dtMax):
            if dtMin is None:
                dtMin = SectionEvent.defaultDateTime
            if dtMax is None:
                dtMax = dtMin
            TIME_LIMIT = '0100-01-01 00:00:00'
            SEC_PER_DAY = 24 * 3600
            dt = dtMin.split(' ')
            if dt[0].startswith('-'):
                startYear = -1 * int(dt[0].split('-')[1])
            else:
                startYear = int(dt[0].split('-')[0])
            if startYear < 100:
                if dtMax == dtMin:
                    dtMax = TIME_LIMIT
                return dtMin, dtMax
            vrMax = datetime.fromisoformat(dtMax)
            vrMin = datetime.fromisoformat(dtMin)
            viewRange = (vrMax - vrMin).total_seconds()

            if viewRange > SEC_PER_DAY:
                margin = viewRange / 10
            else:
                margin = 3600
            dtMargin = timedelta(seconds=margin)
            try:
                vrMin -= dtMargin
                dtMin = vrMin.isoformat(' ', 'seconds')
            except OverflowError:
                pass
            try:
                vrMax += dtMargin
                dtMax = vrMax.isoformat(' ', 'seconds')
            except OverflowError:
                pass
            return dtMin, dtMax

        self.novel.chapters = {}
        self.novel.tree = self._nvSvc.make_nv_tree()

        if source.referenceDate:
            SectionEvent.defaultDateTime = f'{source.referenceDate} 00:00:00'
            ignoreUnspecific = False
        else:
            SectionEvent.defaultDateTime = datetime.today().isoformat(' ', 'seconds')
            ignoreUnspecific = True

        defaultDay = 0
        for chId in source.tree.get_children(CH_ROOT):
            self.novel.chapters[chId] = self._nvSvc.make_chapter()
            self.novel.tree.append(CH_ROOT, chId)
            for scId in source.tree.get_children(chId):
                if ignoreUnspecific and source.sections[scId].date is None:
                    continue

                if not scId in self.novel.sections:
                    self.novel.sections[scId] = SectionEvent(self._nvSvc.make_section())
                self.novel.tree.append(chId, scId)
                if source.sections[scId].title:
                    title = source.sections[scId].title
                    title = self._convert_from_mdnov(title)
                    title = add_contId(self.novel.sections[scId], title)
                    self.novel.sections[scId].title = title
                self.novel.sections[scId].desc = source.sections[scId].desc
                defaultDay += self._newEventSpacing
                self.novel.sections[scId].merge_date_time(source.sections[scId], defaultDay=defaultDay)
                self.novel.sections[scId].scType = source.sections[scId].scType
        sections = list(self.novel.sections)
        for scId in sections:
            if not scId in source.sections:
                del self.novel.sections[scId]

        dtMin = None
        dtMax = None

        srtSections = []
        for chId in self.novel.tree.get_children(CH_ROOT):
            for scId in self.novel.tree.get_children(chId):
                if self.novel.sections[scId].scType == 0:
                    srtSections.append(scId)
        if self._xmlTree is not None:
            root = self._xmlTree.getroot()
            events = root.find('events')
            trash = []
            scIds = []

            for event in events.iter('event'):
                if event.find('labels') is not None:
                    labels = event.find('labels').text
                    sectionMatch = re.search(fr'{SECTION_PREFIX}[0-9]+', labels)
                else:
                    continue

                if sectionMatch is not None:
                    scId = sectionMatch.group()
                    if scId in srtSections:
                        scIds.append(scId)
                        dtMin, dtMax = self.novel.sections[scId].build_branch(event, scId, dtMin, dtMax)
                    else:
                        trash.append(event)

            for scId in srtSections:
                if not scId in scIds:
                    event = ET.SubElement(events, 'event')
                    dtMin, dtMax = self.novel.sections[scId].build_branch(event, scId, dtMin, dtMax)
            for event in trash:
                events.remove(event)

            dtMin, dtMax = set_view_range(dtMin, dtMax)
            view = root.find('view')
            period = view.find('displayed_period')
            period.find('start').text = dtMin
            period.find('end').text = dtMax
        else:
            root = ET.Element('timeline')
            ET.SubElement(root, 'version').text = '2.4.0 (3f207fbb63f0 2021-04-07)'
            ET.SubElement(root, 'timetype').text = 'gregoriantime'
            ET.SubElement(root, 'categories')
            events = ET.SubElement(root, 'events')
            for scId in srtSections:
                event = ET.SubElement(events, 'event')
                dtMin, dtMax = self.novel.sections[scId].build_branch(event, scId, dtMin, dtMax)

            dtMin, dtMax = set_view_range(dtMin, dtMax)
            view = ET.SubElement(root, 'view')
            period = ET.SubElement(view, 'displayed_period')
            ET.SubElement(period, 'start').text = dtMin
            ET.SubElement(period, 'end').text = dtMax
        indent(root)
        self._xmlTree = ET.ElementTree(root)

        backedUp = False
        if os.path.isfile(self.filePath):
            try:
                os.replace(self.filePath, f'{self.filePath}.bak')
            except:
                raise Error(f'{_("Cannot overwrite file")}: "{norm_path(self.filePath)}".')
            else:
                backedUp = True
        try:
            self._xmlTree.write(self.filePath, xml_declaration=True, encoding='utf-8')
        except:
            if backedUp:
                os.replace(f'{self.filePath}.bak', self.filePath)
            raise Error(f'{_("Cannot write file")}: "{norm_path(self.filePath)}".')

    def _convert_to_mdnov(self, text):
        if text is not None:
            if text.startswith(' ('):
                text = text.lstrip()
            elif text.startswith(' ['):
                text = text.lstrip()
        return text

    def _convert_from_mdnov(self, text, **kwargs):
        if text is not None:
            if text.startswith('('):
                text = f' {text}'
            elif text.startswith('['):
                text = f' {text}'
        return text



class Timeline(PluginBase):

    FEATURE = 'Timeline'
    SETTINGS = dict(
        section_label='Section',
        section_color='170,240,160',
        new_event_spacing='1'
    )
    OPTIONS = {}

    def __init__(self, model, view, controller):
        super().__init__(model, view, controller)

        self._timelineMenu = tk.Menu(self._ui.toolsMenu, tearoff=0)
        self._ui.toolsMenu.add_cascade(label=self.FEATURE, menu=self._timelineMenu)
        self._ui.toolsMenu.entryconfig(self.FEATURE, state='disabled')
        self._timelineMenu.add_command(label=_('Information'), command=self._info)
        self._timelineMenu.add_separator()
        self._timelineMenu.add_command(label=_('Create or update the timeline'), command=self._export_from_mdnov)
        self._timelineMenu.add_command(label=_('Update the project'), command=self._import_to_mdnov)
        self._timelineMenu.add_separator()
        self._timelineMenu.add_command(label=_('Open Timeline'), command=self._launch_application)

        self._ui.newMenu.add_command(label=_('Create from Timeline...'), command=self._create_mdnov)

        self._configure_toolbar()

    def disable_menu(self):
        self._ui.toolsMenu.entryconfig(self.FEATURE, state='disabled')
        self._timelineButton.config(state='disabled')

    def enable_menu(self):
        self._ui.toolsMenu.entryconfig(self.FEATURE, state='normal')
        self._timelineButton.config(state='normal')

    def _configure_toolbar(self):

        prefs = self._ctrl.get_preferences()
        if prefs.get('large_icons', False):
            size = 24
        else:
            size = 16
        try:
            iconPath = f'{os.path.dirname(sys.argv[0])}/icons/{size}'
        except:
            iconPath = None
        try:
            tlIcon = tk.PhotoImage(file=f'{iconPath}/tl.png')
        except:
            tlIcon = None

        tk.Frame(self._ui.toolbar.buttonBar, bg='light gray', width=1).pack(side='left', fill='y', padx=4)

        self._timelineButton = ttk.Button(
            self._ui.toolbar.buttonBar,
            text=_('Open Timeline'),
            image=tlIcon,
            command=self._launch_application
            )
        self._timelineButton.pack(side='left')
        self._timelineButton.image = tlIcon

        if not prefs['enable_hovertips']:
            return

        Hovertip(self._timelineButton, self._timelineButton['text'])

    def _create_mdnov(self):
        timelinePath = filedialog.askopenfilename(
            filetypes=[(TlFile.DESCRIPTION, TlFile.EXTENSION)],
            defaultextension=TlFile.EXTENSION,
            )
        if not timelinePath:
            return

        self._ctrl.close_project()
        root, __ = os.path.splitext(timelinePath)
        novxPath = f'{root}{self._mdl.nvService.get_prj_file_extension()}'
        kwargs = self._get_configuration(timelinePath)
        kwargs['nv_service'] = self._mdl.nvService
        source = TlFile(timelinePath, **kwargs)
        target = self._mdl.nvService.make_prj_file(novxPath)

        if os.path.isfile(target.filePath):
            self._ui.set_status(f'!{_("File already exists")}: "{norm_path(target.filePath)}".')
            return

        message = ''
        try:
            source.novel = self._mdl.nvService.make_novel()
            source.read()
            target.novel = source.novel
            target.write()
        except Error as ex:
            message = f'!{str(ex)}'
        else:
            message = f'{_("File written")}: "{norm_path(target.filePath)}".'
            self._ctrl.open_project(filePath=target.filePath, doNotSave=True)
        finally:
            self._ui.set_status(message)

    def _export_from_mdnov(self):
        if not self._mdl.prjFile:
            return

        self._ui.propertiesView.apply_changes()
        self._ui.restore_status()
        if not self._mdl.prjFile.filePath:
            if not self._ctrl.save_project():
                return

        timelinePath = f'{os.path.splitext(self._mdl.prjFile.filePath)[0]}{TlFile.EXTENSION}'
        if os.path.isfile(timelinePath):
            action = _('update')
        else:
            action = _('create')
        if self._mdl.isModified:
            if not self._ui.ask_yes_no(_('Save the project and {} the timeline?').format(action)):
                return

            self._ctrl.save_project()
        elif action == _('update') and not self._ui.ask_yes_no(_('Update the timeline?')):
            return

        kwargs = self._get_configuration(self._mdl.prjFile.filePath)
        kwargs['nv_service'] = self._mdl.nvService
        source = self._mdl.nvService.make_prj_file(self._mdl.prjFile.filePath)
        source.novel = self._mdl.nvService.make_novel()
        target = TlFile(timelinePath, **kwargs)
        target.novel = self._mdl.nvService.make_novel()
        try:
            source.read()
            if os.path.isfile(target.filePath):
                target.read()
            target.write(source.novel)
            message = f'{_("File written")}: "{norm_path(target.filePath)}".'
        except Error as ex:
            message = f'!{str(ex)}'
        self._ui.set_status(message)

    def _get_configuration(self, sourcePath):
        sourceDir = os.path.dirname(sourcePath)
        if not sourceDir:
            sourceDir = '.'
        try:
            homeDir = str(Path.home()).replace('\\', '/')
            pluginCnfDir = f'{homeDir}/.mdnovel/config'
        except:
            pluginCnfDir = '.'
        iniFiles = [f'{pluginCnfDir}/timeline.ini', f'{sourceDir}/timeline.ini']
        configuration = self._mdl.nvService.make_configuration(
            settings=self.SETTINGS,
            options=self.OPTIONS
            )
        for iniFile in iniFiles:
            configuration.read(iniFile)
        configData = {}
        configData.update(configuration.settings)
        configData.update(configuration.options)
        return configData

    def _import_to_mdnov(self):
        if not self._mdl.prjFile:
            return

        self._ui.restore_status()
        self._ui.propertiesView.apply_changes()
        timelinePath = f'{os.path.splitext(self._mdl.prjFile.filePath)[0]}{TlFile.EXTENSION}'
        if not os.path.isfile(timelinePath):
            self._ui.set_status(_('!No {} file available for this project.').format(self.FEATURE))
            return

        if self._mdl.isModified and not self._ui.ask_yes_no(_('Save the project and update it?')):
            return

        self._ctrl.save_project()
        kwargs = self._get_configuration(timelinePath)
        kwargs['nv_service'] = self._mdl.nvService
        source = TlFile(timelinePath, **kwargs)
        target = self._mdl.nvService.make_prj_file(self._mdl.prjFile.filePath, **kwargs)
        message = ''
        try:
            target.novel = self._mdl.nvService.make_novel()
            target.read()
            source.novel = target.novel
            source.read()
            target.novel = source.novel
            target.write()
            message = f'{_("File written")}: "{norm_path(target.filePath)}".'
            self._ctrl.open_project(filePath=self._mdl.prjFile.filePath, doNotSave=True)
        except Error as ex:
            message = f'!{str(ex)}'
        self._ui.set_status(f'{message}')

    def _info(self):
        if not self._mdl.prjFile:
            return

        timelinePath = f'{os.path.splitext(self._mdl.prjFile.filePath)[0]}{TlFile.EXTENSION}'
        if os.path.isfile(timelinePath):
            try:
                timestamp = os.path.getmtime(timelinePath)
                if timestamp > self._mdl.prjFile.timestamp:
                    cmp = _('newer')
                else:
                    cmp = _('older')
                fileDate = datetime.fromtimestamp(timestamp).strftime('%c')
                message = _('{0} file is {1} than the mdnovel project.\n (last saved on {2})').format(self.FEATURE, cmp, fileDate)
            except:
                message = _('Cannot determine file date.')
        else:
            message = _('No {} file available for this project.').format(self.FEATURE)
        messagebox.showinfo(self.FEATURE, message)

    def _launch_application(self):
        if self._mdl.prjFile:
            timelinePath = f'{os.path.splitext(self._mdl.prjFile.filePath)[0]}{TlFile.EXTENSION}'
            if os.path.isfile(timelinePath):
                open_document(timelinePath)
            else:
                self._ui.set_status(_('!No {} file available for this project.').format(self.FEATURE))



class NvPluginCollection(PluginCollection):

    PLUGINS = [
        Editor,
        Templates,
        Timeline,
        Matrix,
        Progress,
        Themes,
    ]

from tkinter import ttk

from abc import abstractmethod
from tkinter import messagebox

from abc import abstractmethod



class ViewComponentNode(Observable, ViewComponentBase):

    @abstractmethod
    def __init__(self, model, view, controller):
        Observable.__init__(self)
        ViewComponentBase.__init__(self, model, view, controller)

    def disable_menu(self):
        for client in self._clients:
            client.disable_menu()

    def enable_menu(self):
        for client in self._clients:
            client.enable_menu()

    def lock(self):
        for client in self._clients:
            client.lock()

    def refresh(self):
        self.refresh_clients()

    def unlock(self):
        for client in self._clients:
            client.unlock()



class ViewBase(ViewComponentNode):

    @abstractmethod
    def __init__(self, model, controller, title):
        ViewComponentNode.__init__(self, model, self, controller)

        self.root = tk.Tk()
        self.root.protocol("WM_DELETE_WINDOW", self._ctrl.on_quit)
        self.root.title(title)
        self.title = title
        self._mdl.register_client(self)

        self.infoWhatText = ''
        self.infoHowText = ''

    def ask_yes_no(self, text, title=None):
        if title is None:
            title = self.title
        return messagebox.askyesno(title, text)

    def on_quit(self):
        self.root.quit()

    def set_info(self, message):
        self.infoWhatText = message

    def set_status(self, message):
        if message.startswith('!'):
            message = f'Error: {message.split("!", maxsplit=1)[1].strip()}'
        elif message.startswith('#'):
            message = f'Notification: {message.split("#", maxsplit=1)[1].strip()}'
        self.infoHowText = message

    def show_error(self, message, title=None):
        if title is None:
            title = self.title
        messagebox.showerror(title, message)

    def show_info(self, message, title=None):
        if title is None:
            title = self.title
        messagebox.showinfo(title, message)

    def show_warning(self, message, title=None):
        if title is None:
            title = self.title
        messagebox.showwarning(title, message)

    def start(self):
        self.root.mainloop()


from tkinter import font as tkFont
from tkinter import font as tkFont
from tkinter import ttk


class RichTextTk(tk.Text):
    H1_TAG = 'h1'
    H2_TAG = 'h2'
    H3_TAG = 'h3'
    ITALIC_TAG = 'italic'
    BOLD_TAG = 'bold'
    CENTER_TAG = 'center'
    BULLET_TAG = 'bullet'

    H1_SIZE = 1.2
    H2_SIZE = 1.1
    H3_SIZE = 1.0
    H1_SPACING = 2
    H2_SPACING = 2
    H3_SPACING = 1.5
    CENTER_SPACING = 1.5

    def __init__(self, master=None, **kw):
        self.frame = ttk.Frame(master)
        self.vbar = ttk.Scrollbar(self.frame)
        self.vbar.pack(side='right', fill='y')

        kw.update({'yscrollcommand': self.vbar.set})
        tk.Text.__init__(self, self.frame, **kw)
        self.pack(side='left', fill='both', expand=True)
        self.vbar['command'] = self.yview

        text_meths = vars(tk.Text).keys()
        methods = vars(tk.Pack).keys() | vars(tk.Grid).keys() | vars(tk.Place).keys()
        methods = methods.difference(text_meths)

        for m in methods:
            if m[0] != '_' and m != 'config' and m != 'configure':
                setattr(self, m, getattr(self.frame, m))

        defaultFont = tkFont.nametofont(self.cget('font'))

        em = defaultFont.measure('m')
        defaultSize = defaultFont.cget('size')
        boldFont = tkFont.Font(**defaultFont.configure())
        italicFont = tkFont.Font(**defaultFont.configure())
        h1Font = tkFont.Font(**defaultFont.configure())
        h2Font = tkFont.Font(**defaultFont.configure())
        h3Font = tkFont.Font(**defaultFont.configure())

        boldFont.configure(weight='bold')
        italicFont.configure(slant='italic')
        h1Font.configure(size=int(defaultSize * self.H1_SIZE), weight='bold')
        h2Font.configure(size=int(defaultSize * self.H2_SIZE), weight='bold')
        h3Font.configure(size=int(defaultSize * self.H3_SIZE), slant='italic')

        self.tag_configure(self.BOLD_TAG, font=boldFont)
        self.tag_configure(self.ITALIC_TAG, font=italicFont)
        self.tag_configure(self.H1_TAG, font=h1Font, spacing3=defaultSize,
                           justify='center', spacing1=defaultSize * self.H1_SPACING)
        self.tag_configure(self.H2_TAG, font=h2Font, spacing3=defaultSize,
                           justify='center', spacing1=defaultSize * self.H2_SPACING)
        self.tag_configure(self.H3_TAG, font=h3Font, spacing3=defaultSize,
                           justify='center', spacing1=defaultSize * self.H3_SPACING)
        self.tag_configure(self.CENTER_TAG, justify='center', spacing1=defaultSize * self.CENTER_SPACING)

        lmargin2 = em + defaultFont.measure('\u2022 ')
        self.tag_configure(self.BULLET_TAG, lmargin1=em, lmargin2=lmargin2)

    def insert_bullet(self, index, text):
        self.insert(index, f'\u2022 {text}', self.BULLET_TAG)


class RichTextNv(RichTextTk):
    H1_NOTES_TAG = 'h1Notes'
    H1_TODO_TAG = 'h1Todo'
    H1_UNUSED_TAG = 'h1Unused'
    H2_NOTES_TAG = 'h2Notes'
    H2_TODO_TAG = 'h2Todo'
    H2_UNUSED_TAG = 'h2Unused'
    H3_NOTES_TAG = 'h3Notes'
    H3_TODO_TAG = 'h3Todo'
    H3_UNUSED_TAG = 'h3Unused'
    TODO_TAG = 'todo'
    UNUSED_TAG = 'unused'
    STAGE1_TAG = 'stage1'
    STAGE2_TAG = 'stage2'
    EM_TAG = 'emTag'
    STRONG_TAG = 'strongTag'

    COLOR_MD_TAG = 'black'

    def __init__(self, *args, **kwargs):
        super().__init__(*args,
                height=20,
                width=60,
                spacing1=2,
                spacing2=2,
                wrap='word',
                padx=10,
                bg=kwargs['color_text_bg'],
                fg=kwargs['color_text_fg'],
                )
        defaultFont = tkFont.nametofont(self.cget('font'))

        defaultSize = defaultFont.cget('size')
        boldFont = tkFont.Font(**defaultFont.configure())
        italicFont = tkFont.Font(**defaultFont.configure())
        h1Font = tkFont.Font(**defaultFont.configure())
        h2Font = tkFont.Font(**defaultFont.configure())
        h3Font = tkFont.Font(**defaultFont.configure())

        boldFont.configure(weight='bold')
        italicFont.configure(slant='italic')
        h1Font.configure(size=int(defaultSize * self.H1_SIZE),
                         weight='bold',
                         )
        h2Font.configure(size=int(defaultSize * self.H2_SIZE),
                         weight='bold',
                         )
        h3Font.configure(size=int(defaultSize * self.H3_SIZE),
                         slant='italic',
                         )
        self.tag_configure(self.EM_TAG,
                           font=italicFont,
                           )
        self.tag_configure(self.STRONG_TAG,
                           font=boldFont,
                           )
        self.tag_configure(self.H1_TAG,
                           font=h1Font,
                           spacing3=defaultSize,
                           foreground=kwargs['color_chapter'],
                           justify='center',
                           spacing1=defaultSize * self.H1_SPACING,
                           )
        self.tag_configure(self.H1_UNUSED_TAG,
                           font=h1Font,
                           spacing3=defaultSize,
                           foreground=kwargs['color_unused'],
                           justify='center',
                           spacing1=defaultSize * self.H1_SPACING,
                           )
        self.tag_configure(self.H2_TAG,
                           font=h2Font,
                           spacing3=defaultSize,
                           foreground=kwargs['color_chapter'],
                           justify='center',
                           spacing1=defaultSize * self.H2_SPACING,
                           )
        self.tag_configure(self.H2_UNUSED_TAG,
                           font=h2Font,
                           spacing3=defaultSize,
                           foreground=kwargs['color_unused'],
                           justify='center',
                           spacing1=defaultSize * self.H2_SPACING,
                           )
        self.tag_configure(self.H3_UNUSED_TAG,
                           font=h3Font,
                           spacing3=defaultSize,
                           foreground=kwargs['color_unused'],
                           justify='center',
                           spacing1=defaultSize * self.H3_SPACING,
                           )
        self.tag_configure(self.UNUSED_TAG,
                           foreground=kwargs['color_unused'],
                           )
        self.tag_configure(self.STAGE1_TAG,
                           font=h1Font,
                           spacing3=defaultSize,
                           foreground=kwargs['color_stage'],
                           justify='center',
                           spacing1=defaultSize * self.H1_SPACING,
                           )
        self.tag_configure(self.STAGE2_TAG,
                           font=h3Font,
                           spacing3=defaultSize,
                           foreground=kwargs['color_stage'],
                           justify='center',
                           spacing1=defaultSize * self.H3_SPACING,
                           )



class ContentsViewer(ViewComponentBase, RichTextNv):
    NO_TEXT = re.compile(r'\<note\>.*?\<\/note\>|\<comment\>.*?\<\/comment\>|\<.+?\>')

    def __init__(self, parent, model, view, controller):
        ViewComponentBase.__init__(self, model, view, controller)
        RichTextNv.__init__(self, parent, **prefs)
        self.pack(expand=True, fill='both')
        self.showMarkup = tk.BooleanVar(parent, value=prefs['show_markdown'])
        self.showMarkup.trace('w', self.refresh)
        self._textMarks = {}
        self._index = '1.0'
        self._parent = parent

    def reset_view(self):
        self.config(state='normal')
        self.delete('1.0', 'end')
        self.config(state='disabled')

    def see(self, idStr):
        try:
            self._index = self._textMarks[idStr]
            super().see(self._index)
        except KeyError:
            pass

    def refresh(self, event=None, *args):
        if self._mdl.prjFile is None:
            return

        if self._parent.winfo_manager():
            self.view_text()
            try:
                super().see(self._index)
            except KeyError:
                pass

    def view_text(self):

        taggedText = []
        for chId in self._mdl.novel.tree.get_children(CH_ROOT):
            chapter = self._mdl.novel.chapters[chId]
            taggedText.append(chId)
            if chapter.chLevel == 2:
                if chapter.chType == 0:
                    headingTag = self.H2_TAG
                else:
                    headingTag = self.H2_UNUSED_TAG
            else:
                if chapter.chType == 0:
                    headingTag = self.H1_TAG
                else:
                    headingTag = self.H1_UNUSED_TAG
            if chapter.title:
                heading = f'{chapter.title}\n'
            else:
                    heading = f"[{_('Unnamed')}]\n"
            taggedText.append((heading, headingTag))

            for scId in self._mdl.novel.tree.get_children(chId):
                section = self._mdl.novel.sections[scId]
                taggedText.append(scId)
                textTag = ''
                if section.scType == 3:
                    headingTag = self.STAGE2_TAG
                elif section.scType == 2:
                    headingTag = self.STAGE1_TAG
                elif section.scType == 0:
                    headingTag = self.H3_TAG
                else:
                    headingTag = self.H3_UNUSED_TAG
                    textTag = self.UNUSED_TAG
                if section.title:
                    heading = f'[{section.title}]\n'
                else:
                    heading = f"[{_('Unnamed')}]\n"
                taggedText.append((heading, headingTag))

                if section.sectionContent:
                    taggedText.append((section.sectionContent, textTag))

        if not taggedText:
            taggedText.append((f'({_("No text available")})', self.ITALIC_TAG))
        self._textMarks = {}

        self.config(state='normal')
        self.delete('1.0', 'end')

        for entry in taggedText:
            if len(entry) == 2:
                text, tag = entry
                self.insert('end', text, tag)
            else:
                index = f"{self.count('1.0', 'end', 'lines')[0]}.0"
                self._textMarks[entry] = index
        self.config(state='disabled')




class Icons:

    def __init__(self):
        if prefs.get('large_icons', False):
            size = 24
        else:
            size = 16
        try:
            iconPath = f'{os.path.dirname(sys.argv[0])}/icons/{size}'
        except:
            iconPath = None
        try:
            self.addIcon = tk.PhotoImage(file=f'{iconPath}/add.png')
        except:
            self.addIcon = None
        try:
            self.addChildIcon = tk.PhotoImage(file=f'{iconPath}/addChild.png')
        except:
            self.addChildIcon = None
        try:
            self.addParentIcon = tk.PhotoImage(file=f'{iconPath}/addParent.png')
        except:
            self.addParentIcon = None
        try:
            self.goBackIcon = tk.PhotoImage(file=f'{iconPath}/goBack.png')
        except:
            self.goBackIcon = None
        try:
            self.goForwardIcon = tk.PhotoImage(file=f'{iconPath}/goForward.png')
        except:
            self.goForwardIcon = None
        try:
            self.gotoIcon = tk.PhotoImage(file=f'{iconPath}/goto.png')
        except:
            self.gotoIcon = None
        try:
            self.manuscriptIcon = tk.PhotoImage(file=f'{iconPath}/manuscript.png')
        except:
            self.manuscriptIcon = None
        try:
            self.propertiesIcon = tk.PhotoImage(file=f'{iconPath}/properties.png')
        except:
            self.propertiesIcon = None
        try:
            self.removeIcon = tk.PhotoImage(file=f'{iconPath}/remove.png')
        except:
            self.removeIcon = None
        try:
            self.saveIcon = tk.PhotoImage(file=f'{iconPath}/save.png')
        except:
            self.saveIcon = None
        try:
            self.updateFromManuscriptIcon = tk.PhotoImage(file=f'{iconPath}/updateFromManuscript.png')
        except:
            self.updateFromManuscriptIcon = None
        try:
            self.viewPlotLinesIcon = tk.PhotoImage(file=f'{iconPath}/viewArcs.png')
        except:
            self.viewPlotLinesIcon = None
        try:
            self.viewBookIcon = tk.PhotoImage(file=f'{iconPath}/viewBook.png')
        except:
            self.viewBookIcon = None
        try:
            self.viewCharactersIcon = tk.PhotoImage(file=f'{iconPath}/viewCharacters.png')
        except:
            self.viewCharactersIcon = None
        try:
            self.viewItemsIcon = tk.PhotoImage(file=f'{iconPath}/viewItems.png')
        except:
            self.viewItemsIcon = None
        try:
            self.viewLocationsIcon = tk.PhotoImage(file=f'{iconPath}/viewLocations.png')
        except:
            self.viewLocationsIcon = None
        try:
            self.viewProjectnotesIcon = tk.PhotoImage(file=f'{iconPath}/viewProjectnotes.png')
        except:
            self.viewProjectnotesIcon = None
        try:
            self.viewerIcon = tk.PhotoImage(file=f'{iconPath}/viewer.png')
        except:
            self.viewerIcon = None
from tkinter import ttk

from abc import abstractmethod


class ModalDialog(tk.Toplevel):
    OFFSET = 300

    @abstractmethod
    def __init__(self, model, view, controller, **kw):
        tk.Toplevel.__init__(self, **kw)
        self._mdl = model
        self._ui = view
        self._ctrl = controller
        __, x, y = self._ui.root.geometry().split('+')
        windowGeometry = f'+{int(x)+self.OFFSET}+{int(y)+self.OFFSET}'
        self.geometry(windowGeometry)
        self.grab_set()
        self.focus()



class ExportOptionsWindow(ModalDialog):

    def __init__(self, model, view, controller, **kw):
        ModalDialog.__init__(self, model, view, controller, **kw)
        self.title(_('"Export" options'))
        window = ttk.Frame(self)
        window.pack(
            fill='both',
            padx=5,
            pady=5
            )
        frame1 = ttk.Frame(window)
        frame1.pack(fill='both', side='left')

        self._askDocOpen = tk.BooleanVar(frame1, value=prefs['ask_doc_open'])
        ttk.Checkbutton(
            frame1,
            text=_('Ask before opening exported documents'),
            variable=self._askDocOpen
            ).pack(padx=5, pady=5, anchor='w')
        self._askDocOpen.trace('w', self._change_ask_doc_open)

        ttk.Separator(self, orient='horizontal').pack(fill='x')

        ttk.Button(
            self,
            text=_('Close'),
            command=self.destroy
            ).pack(padx=5, pady=5, side='right')

        ttk.Button(
            self,
            text=_('Online help'),
            command=self._open_help
            ).pack(padx=5, pady=5, side='right')

        self.bind(KEYS.OPEN_HELP[0], self._open_help)

    def _change_ask_doc_open(self, *args):
        prefs['ask_doc_open'] = self._askDocOpen.get()

    def _open_help(self, event=None):
        open_help('export_menu#options')
from tkinter import ttk



class DragDropListbox(tk.Listbox):

    def __init__(self, master, **kw):
        kw['selectmode'] = 'single'
        tk.Listbox.__init__(self, master, kw)
        self.bind('<Button-1>', self._set_current)
        self.bind('<B1-Motion>', self._shift_selection)
        self.curIndex = None

    def _set_current(self, event):
        self.curIndex = self.nearest(event.y)

    def _shift_selection(self, event):
        i = self.nearest(event.y)
        if i < self.curIndex:
            x = self.get(i)
            self.delete(i)
            self.insert(i + 1, x)
            self.curIndex = i
        elif i > self.curIndex:
            x = self.get(i)
            self.delete(i)
            self.insert(i - 1, x)
            self.curIndex = i


class ViewOptionsWindow(ModalDialog):

    def __init__(self, model, view, controller, **kw):
        ModalDialog.__init__(self, model, view, controller, **kw)
        self.title(_('"View" options'))
        window = ttk.Frame(self)
        window.pack(
            fill='both',
            padx=5,
            pady=5
            )
        frame1 = ttk.Frame(window)
        frame1.pack(fill='both', side='left')

        ttk.Separator(window, orient='vertical').pack(fill='y', padx=10, side='left')
        frame2 = ttk.Frame(window)
        frame2.pack(fill='both', side='left')

        self._coloringModeStr = tk.StringVar(value=self._ui.tv.COLORING_MODES[self._ui.tv.coloringMode])
        self._coloringModeStr.trace('w', self._change_colors)
        ttk.Label(
            frame1,
            text=_('Coloring mode')
            ).pack(padx=5, pady=5, anchor='w')
        ttk.Combobox(
            frame1,
            textvariable=self._coloringModeStr,
            values=self._ui.tv.COLORING_MODES,
            width=20
            ).pack(padx=5, pady=5, anchor='w')

        ttk.Separator(frame1, orient='horizontal').pack(fill='x', pady=10)

        self._largeIcons = tk.BooleanVar(frame1, value=prefs['large_icons'])
        ttk.Checkbutton(
            frame1,
            text=_('Large toolbar icons'),
            variable=self._largeIcons,
            command=self._change_icon_size,
            ).pack(padx=5, pady=5, anchor='w')

        self._localizeDate = tk.BooleanVar(frame1, value=prefs['localize_date'])
        ttk.Checkbutton(
            frame1,
            text=_('Display localized dates'),
            variable=self._localizeDate,
            command=self._change_localize_date,
            ).pack(padx=5, pady=5, anchor='w')

        ttk.Label(
            frame2,
            text=_('Columns')
            ).pack(padx=5, pady=5, anchor='w')
        self._coIdsByTitle = {}
        for coId, title, __ in self._ui.tv.columns:
            self._coIdsByTitle[title] = coId
        self._colEntries = tk.Variable(value=list(self._coIdsByTitle))
        DragDropListbox(
            frame2,
            listvariable=self._colEntries,
            width=20
            ).pack(padx=5, pady=5, anchor='w')
        ttk.Button(
            frame2,
            text=_('Apply'),
            command=self._change_column_order
            ).pack(padx=5, pady=5, anchor='w')

        ttk.Separator(self, orient='horizontal').pack(fill='x')

        ttk.Button(
            self,
            text=_('Close'),
            command=self.destroy
            ).pack(padx=5, pady=5, side='right')

        ttk.Button(
            self,
            text=_('Online help'),
            command=self._open_help
            ).pack(padx=5, pady=5, side='right')

        self.bind(KEYS.OPEN_HELP[0], self._open_help)

    def _change_colors(self, *args, **kwargs):
        cmStr = self._coloringModeStr.get()
        self._ui.tv.coloringMode = self._ui.tv.COLORING_MODES.index(cmStr)
        self._ui.tv.refresh()

    def _change_column_order(self, *args, **kwargs):
        srtColumns = []
        titles = self._colEntries.get()
        for title in titles:
            srtColumns.append(self._coIdsByTitle[title])
        prefs['column_order'] = list_to_string(srtColumns)
        self._ui.tv.configure_columns()
        self._ui.tv.refresh()

    def _change_icon_size(self, *args):
        prefs['large_icons'] = self._largeIcons.get()
        self._ui.show_info(_('The change takes effect after next startup.'), title=f'{_("Change icon size")}')

    def _change_localize_date(self, *args):
        prefs['localize_date'] = self._localizeDate.get()
        self._ui.tv.refresh()
        self._ui.propertiesView.refresh()

    def _open_help(self, event=None):
        open_help('view_menu#options')
from tkinter import ttk

from tkinter import ttk

from abc import abstractmethod
from tkinter import filedialog
from tkinter import ttk

from tkinter import ttk



class CollectionBox(ttk.Frame):

    def __init__(
            self,
            master,
            cmdAdd=None, lblAdd=None, iconAdd=None,
            cmdOpen=None, lblOpen=None, iconOpen=None,
            cmdRemove=None, lblRemove=None, iconRemove=None,
            cmdActivate=None, cmdSelect=None,
            **kw
            ):
        super().__init__(master, **kw)
        if cmdActivate is None:
            cmdActivate = self.enable_buttons

        listFrame = ttk.Frame(self)
        listFrame.pack(side='left', fill='both', expand=True)
        self.cList = tk.StringVar()
        self.cListbox = tk.Listbox(listFrame, listvariable=self.cList, selectmode='single')
        vbar = ttk.Scrollbar(listFrame, orient='vertical', command=self.cListbox.yview)
        vbar.pack(side='right', fill='y')
        self.cListbox.pack(side='left', fill='both', expand=True)
        self.cListbox.config(yscrollcommand=vbar.set)

        self.cListbox.bind('<FocusIn>', cmdActivate)
        self.cListbox.bind('<<ListboxSelect>>', self._on_change_selection)

        buttonbar = ttk.Frame(self)
        buttonbar.pack(anchor='n', side='right', fill='x', padx=5)
        self.inputWidgets = []

        self._cmdSelect = cmdSelect

        kwargs = dict(
            command=cmdOpen,
            image=iconOpen,
            )
        if lblOpen is None:
            kwargs['text'] = _('Open')
        else:
            kwargs['text'] = lblOpen
        self.btnOpen = ttk.Button(buttonbar, **kwargs)
        if cmdOpen is not None:
            self.btnOpen.pack(fill='x', expand=True)
            self.cListbox.bind('<Double-1>', cmdOpen)
            self.cListbox.bind('<Return>', cmdOpen)

        kwargs = dict(
            command=cmdAdd,
            image=iconAdd,
            )
        if lblAdd is None:
            kwargs['text'] = _('Add')
        else:
            kwargs['text'] = lblAdd
        self.btnAdd = ttk.Button(buttonbar, **kwargs)
        if cmdAdd is not None:
            self.btnAdd.pack(fill='x', expand=True)
            self.inputWidgets.append(self.btnAdd)

        kwargs = dict(
            command=cmdRemove,
            image=iconRemove,
            )
        if lblRemove is None:
            kwargs['text'] = _('Remove')
        else:
            kwargs['text'] = lblRemove
        self.btnRemove = ttk.Button(buttonbar, **kwargs)
        if cmdRemove is not None:
            self.btnRemove.pack(fill='x', expand=True)
            self.inputWidgets.append(self.btnRemove)
            self.cListbox.bind(KEYS.DELETE[0], cmdRemove)

        self._set_hovertips()

    def enable_buttons(self, event=None):
        self.btnOpen.config(state='normal')
        self.btnRemove.config(state='normal')

    def disable_buttons(self, event=None):
        self.btnOpen.config(state='disabled')
        self.btnRemove.config(state='disabled')

    def _on_change_selection(self, event=None):
        self.enable_buttons()
        if self._cmdSelect is not None:
            try:
                self._cmdSelect(self.cListbox.curselection()[0])
            except:
                pass

    def _set_hovertips(self):
        if not prefs['enable_hovertips']:
            return

        Hovertip(self.btnAdd, self.btnAdd['text'])
        Hovertip(self.btnOpen, self.btnOpen['text'])
        Hovertip(self.btnRemove, f"{self.btnRemove['text']} ({KEYS.DELETE[1]})")
from tkinter import ttk


class FoldingFrame(ttk.Frame):
    _PREFIX_SHOW = '▽  '
    _PREFIX_HIDE = '▷  '

    def __init__(self, parent, buttonText, command, **kw):
        super().__init__(parent, **kw)
        self.buttonText = buttonText
        self._toggleButton = ttk.Label(parent)
        self._toggleButton['text'] = f'{self._PREFIX_HIDE}{self.buttonText}'
        self._toggleButton.pack(fill='x', pady=2)
        self._toggleButton.bind('<Button-1>', command)

    def show(self, event=None):
        self._toggleButton['text'] = f'{self._PREFIX_SHOW}{self.buttonText}'
        self.pack(after=self._toggleButton, fill='x', pady=5)

    def hide(self, event=None):
        self._toggleButton['text'] = f'{self._PREFIX_HIDE}{self.buttonText}'
        self.pack_forget()

from tkinter import ttk



class TextBox(tk.Text):

    def __init__(self, master=None, scrollbar=True, **kw):
        if kw.get('font', None) is None:
            kw['font'] = 'Courier 10'
        if scrollbar:
            self.frame = ttk.Frame(master)
            self.vbar = ttk.Scrollbar(self.frame)
            self.vbar.pack(side='right', fill='y')

            kw.update({'yscrollcommand': self.vbar.set})
            tk.Text.__init__(self, self.frame, **kw)
            self.pack(side='left', fill='both', expand=True)
            self.vbar['command'] = self.yview

            text_meths = vars(tk.Text).keys()
            methods = vars(tk.Pack).keys() | vars(tk.Grid).keys() | vars(tk.Place).keys()
            methods = methods.difference(text_meths)

            for m in methods:
                if m[0] != '_' and m != 'config' and m != 'configure':
                    setattr(self, m, getattr(self.frame, m))
        else:
            tk.Text.__init__(self, master, **kw)

        self.hasChanged = False
        self.bind('<KeyRelease>', self._on_edit)

    def clear(self):
        self.delete('1.0', 'end')
        self.hasChanged = False

    def get_text(self):
        text = self.get('1.0', 'end').strip(' \n')
        return text

    def set_text(self, text):
        self.clear()
        if text:
            self.insert('end', text)
            self.edit_reset()

    def _on_edit(self, event=None):
        self.hasChanged = True



class MyStringVar(tk.StringVar):

    def set(self, value):
        if value is None:
            value = ''
        super().set(value)

    def get(self):
        value = super().get()
        if value == '':
            value = None
        return value


class IndexCard(tk.Frame):

    def __init__(self, master=None, cnf={}, fg='black', bg='white', font=None, scrollbar=True, **kw):
        super().__init__(master=master, cnf=cnf, **kw)
        self.title = MyStringVar(value='')
        self.titleEntry = tk.Entry(
            self,
            bg=bg,
            bd=0,
            textvariable=self.title,
            relief='flat',
            font=font,
            )
        self.titleEntry.config({
            'background': bg,
            'foreground': fg,
            'insertbackground': fg,
            })
        self.titleEntry.pack(fill='x', ipady=6)

        tk.Frame(self, bg='red', height=1, bd=0).pack(fill='x')
        tk.Frame(self, bg=bg, height=1, bd=0).pack(fill='x')

        self.bodyBox = TextBox(
            self,
            scrollbar=scrollbar,
            wrap='word',
            undo=True,
            autoseparators=True,
            maxundo=-1,
            padx=5,
            pady=5,
            bg=bg,
            fg=fg,
            insertbackground=fg,
            font=font,
            )
        self.bodyBox.pack(fill='both', expand=True)

    def lock(self):
        self.titleEntry.config(state='disabled')
        self.bodyBox.config(state='disabled')

    def unlock(self):
        self.titleEntry.config(state='normal')
        self.bodyBox.config(state='normal')


class BasicView(ViewComponentBase, ttk.Frame):
    _HEIGHT_LIMIT = 10

    _LBL_X = 10

    def __init__(self, parent, model, view, controller, **kw):
        ViewComponentBase.__init__(self, model, view, controller)
        ttk.Frame.__init__(self, parent, **kw)

        self._elementId = None
        self._element = None
        self._tagsStr = ''
        self._parent = parent
        self._inputWidgets = []

        self._pickingMode = False
        self._pickCommand = None
        self._uiEscBinding = ''
        self._uiBtn1Binding = ''

        self.doNotUpdate = False

        self._propertiesFrame = ttk.Frame(self)
        self._propertiesFrame.pack(expand=True, fill='both')

        self._prefsShowLinks = None
        self._create_frames()

    def _activate_link_buttons(self, event=None):
        if self._element.links:
            self._linkCollection.enable_buttons()
        else:
            self._linkCollection.disable_buttons()

    def apply_changes(self, event=None):
        if self._element is None:
            return

        titleStr = self._indexCard.title.get()
        if titleStr:
            titleStr = titleStr.strip()
        self._element.title = titleStr

        if self._indexCard.bodyBox.hasChanged:
            self._element.desc = self._indexCard.bodyBox.get_text()

        if hasattr(self._element, 'notes') and self._notesWindow.hasChanged:
            self._element.notes = self._notesWindow.get_text()

    def focus_title(self):
        self._indexCard.titleEntry.focus()
        self._indexCard.titleEntry.icursor(0)
        self._indexCard.titleEntry.selection_range(0, 'end')

    def hide(self):
        self.pack_forget()

    @abstractmethod
    def set_data(self, elementId):
        self._elementId = elementId
        self._tagsStr = ''
        if self._element is not None:

            self._indexCard.title.set(self._element.title)

            self._indexCard.bodyBox.clear()
            self._indexCard.bodyBox.set_text(self._element.desc)

            if hasattr(self._element, 'links'):
                if prefs[self._prefsShowLinks]:
                    self._linksWindow.show()
                else:
                    self._linksWindow.hide()
                linkList = []
                for path in self._element.links:
                    linkList.append(os.path.split(path)[1])
                self._linkCollection.cList.set(linkList)
                listboxSize = len(linkList)
                if listboxSize > self._HEIGHT_LIMIT:
                    listboxSize = self._HEIGHT_LIMIT
                self._linkCollection.cListbox.config(height=listboxSize)
                if not self._linkCollection.cListbox.curselection() or not self._linkCollection.cListbox.focus_get():
                    self._linkCollection.disable_buttons()

            if hasattr(self._element, 'notes'):
                self._notesWindow.clear()
                self._notesWindow.set_text(self._element.notes)

    def show(self):
        self.pack(expand=True, fill='both')

    def _add_link(self):
        fileTypes = [
            (_('Image file'), '.jpg'),
            (_('Image file'), '.jpeg'),
            (_('Image file'), '.png'),
            (_('Image file'), '.gif'),
            (_('Text file'), '.txt'),
            (_('Text file'), '.md'),
            (_('ODF document'), '.odt'),
            (_('ODF document'), '.ods'),
            (_('All files'), '.*'),
            ]
        selectedPath = filedialog.askopenfilename(filetypes=fileTypes)
        if selectedPath:
            shortPath = self._ctrl.linkProcessor.shorten_path(selectedPath)
            links = self._element.links
            if links is None:
                links = {}
            links[shortPath] = selectedPath
            self._element.links = links

    def _add_separator(self):
        ttk.Separator(self._propertiesFrame, orient='horizontal').pack(fill='x')

    def _create_button_bar(self):
        self._buttonBar = ttk.Frame(self)
        self._buttonBar.pack(fill='x')

        ttk.Button(self._buttonBar, text=_('Previous'), command=self._load_prev).pack(side='left', fill='x', expand=True, padx=1, pady=2)

        ttk.Button(self._buttonBar, text=_('Next'), command=self._load_next).pack(side='left', fill='x', expand=True, padx=1, pady=2)

    def _create_element_info_window(self):
        self._elementInfoWindow = ttk.Frame(self._propertiesFrame)
        self._elementInfoWindow.pack(fill='x')

    @abstractmethod
    def _create_frames(self):
        pass

    def _create_index_card(self):
        self._indexCard = IndexCard(
            self._propertiesFrame,
            bd=2,
            fg=prefs['color_text_fg'],
            bg=prefs['color_text_bg'],
            relief='ridge'
            )
        self._indexCard.bodyBox['height'] = prefs['index_card_height']
        self._indexCard.pack(expand=False, fill='both')
        self._indexCard.titleEntry.bind('<Return>', self.apply_changes)
        self._indexCard.titleEntry.bind('<FocusOut>', self.apply_changes)
        self._indexCard.bodyBox.bind('<FocusOut>', self.apply_changes)

    def _create_links_window(self):
        ttk.Separator(self._propertiesFrame, orient='horizontal').pack(fill='x')
        self._linksWindow = FoldingFrame(self._propertiesFrame, _('Links'), self._toggle_links_window)
        self._linksWindow.pack(fill='x')
        self._linkCollection = CollectionBox(
            self._linksWindow,
            cmdAdd=self._add_link,
            cmdRemove=self._remove_link,
            cmdOpen=self._open_link,
            cmdActivate=self._activate_link_buttons,
            lblOpen=_('Open link'),
            iconAdd=self._ui.icons.addIcon,
            iconRemove=self._ui.icons.removeIcon,
            iconOpen=self._ui.icons.gotoIcon
            )
        self._inputWidgets.extend(self._linkCollection.inputWidgets)
        self._linkCollection.pack(fill='x')

    def _create_notes_window(self):
        self._notesWindow = TextBox(
            self._propertiesFrame,
            wrap='word',
            undo=True,
            autoseparators=True,
            maxundo=-1,
            height=0,
            width=10,
            padx=5,
            pady=5,
            bg=prefs['color_notes_bg'],
            fg=prefs['color_notes_fg'],
            insertbackground=prefs['color_notes_fg'],
            )
        self._notesWindow.pack(expand=True, fill='both')
        self._notesWindow.bind('<FocusOut>', self.apply_changes)

    def _end_picking_mode(self, event=None):
        if self._pickingMode:
            if self._pickCommand is not None:
                self._pickCommand()
                self._pickCommand = None
            self._ui.root.bind('<Button-1>', self._uiBtn1Binding)
            self._ui.root.bind('<Escape>', self._uiEscBinding)
            self._ui.tv.config(cursor='arrow')
            self._ui.tv.see_node(self._lastSelected)
            self._ui.tv.tree.selection_set(self._lastSelected)
            self._pickingMode = False
        self._ui.restore_status()

    def _load_next(self):
        thisNode = self._ui.tv.tree.selection()[0]
        nextNode = self._ui.tv.next_node(thisNode)
        if nextNode:
            self._ui.tv.see_node(nextNode)
            self._ui.tv.tree.selection_set(nextNode)

    def _load_prev(self):
        thisNode = self._ui.tv.tree.selection()[0]
        prevNode = self._ui.tv.prev_node(thisNode)
        if prevNode:
            self._ui.tv.see_node(prevNode)
            self._ui.tv.tree.selection_set(prevNode)

    def _open_link(self, event=None):
        try:
            selection = self._linkCollection.cListbox.curselection()[0]
        except:
            return

        self._ctrl.open_link(self._element, selection)

    def _remove_link(self, event=None):
        try:
            selection = self._linkCollection.cListbox.curselection()[0]
        except:
            return

        linkPath = list(self._element.links)[selection]
        if self._ui.ask_yes_no(f'{_("Remove link")}: "{self._element.links[linkPath]}"?'):
            links = self._element.links
            try:
                del links[linkPath]
            except:
                pass
            else:
                self._element.links = links

    def _show_missing_date_message(self):
        self._ui.show_error(
            _('Please enter either a section date or a day and a reference date.'),
            title=_('Date information is missing'))

    def _show_missing_reference_date_message(self):
        self._ui.show_error(
            _('Please enter a reference date.'),
            title=_('Cannot convert date/days'))

    def _start_picking_mode(self, event=None, command=None):
        self._pickCommand = command
        if not self._pickingMode:
            self._lastSelected = self._ui.tv.tree.selection()[0]
            self._ui.tv.config(cursor='plus')
            self._ui.tv.open_children('')
            self._uiEscBinding = self._ui.root.bind('<Escape>')
            self._ui.root.bind('<Escape>', self._end_picking_mode)
            self._uiBtn1Binding = self._ui.root.bind('<Button-1>')
            self._ui.root.bind('<Button-1>', self._end_picking_mode)
            self._pickingMode = True
        self._ui.set_status(_('Pick Mode (click here or press Esc to exit)'), colors=('maroon', 'white'))

    def _toggle_links_window(self, event=None):
        if prefs[self._prefsShowLinks]:
            self._linksWindow.hide()
            prefs[self._prefsShowLinks] = False
        else:
            self._linksWindow.show()
            prefs[self._prefsShowLinks] = True



class ChapterView(BasicView):

    def __init__(self, parent, model, view, controller):
        super().__init__(parent, model, view, controller)
        inputWidgets = []

        self._isUnused = tk.BooleanVar()
        self._isUnusedCheckbox = ttk.Checkbutton(
            self._elementInfoWindow,
            text=_('Unused'),
            variable=self._isUnused,
            onvalue=True,
            offvalue=False,
            command=self.apply_changes,
            )
        self._isUnusedCheckbox.pack(anchor='w')
        inputWidgets.append(self._isUnusedCheckbox)

        self._noNumber = tk.BooleanVar()
        self._noNumberCheckbox = ttk.Checkbutton(
            self._elementInfoWindow,
            variable=self._noNumber,
            onvalue=True,
            offvalue=False,
            command=self.apply_changes,
            )
        self._noNumberCheckbox.pack(anchor='w')
        inputWidgets.append(self._noNumberCheckbox)

        for widget in inputWidgets:
            widget.bind('<FocusOut>', self.apply_changes)
            self._inputWidgets.append(widget)

        self._prefsShowLinks = 'show_ch_links'

    def apply_changes(self, event=None):
        if self._element.isTrash:
            return

        super().apply_changes()

        if self._isUnused.get():
            self._ctrl.set_type(1, [self._elementId])
        else:
            self._ctrl.set_type(0, [self._elementId])

        self._element.noNumber = self._noNumber.get()

    def set_data(self, elementId):
        self._element = self._mdl.novel.chapters[elementId]
        super().set_data(elementId)

        if self._element.chType > 0:
            self._isUnused.set(True)
        else:
            self._isUnused.set(False)

        if self._element.chLevel == 1:
            labelText = _('Do not auto-number this part')
        else:
            labelText = _('Do not auto-number this chapter')
        self._noNumberCheckbox.configure(text=labelText)
        if self._element.noNumber:
            self._noNumber.set(True)
        else:
            self._noNumber.set(False)

    def _create_frames(self):
        self._create_index_card()
        self._create_element_info_window()
        self._create_links_window()
        self._add_separator()
        self._create_notes_window()
        self._create_button_bar()

from datetime import date
from tkinter import ttk

from abc import ABC, abstractmethod
from tkinter import ttk

from tkinter import ttk


class LabelEntry(ttk.Frame):

    def __init__(self, parent, text, textvariable, command, lblWidth=10):
        super().__init__(parent)
        self.pack(fill='x')
        self._label = ttk.Label(self, text=text, anchor='w', width=lblWidth)
        self._label.pack(side='left')
        self.entry = ttk.Entry(self, textvariable=textvariable)
        self.entry.pack(side='left', fill='x', expand=True)
        self.entry.bind('<Return>', command)

    def config(self, **kwargs):
        self.configure(**kwargs)

    def configure(self, text=None, state=None):
        if text is not None:
            self._label['text'] = text
        if state is not None:
            self.entry.config(state=state)


class WorldElementView(BasicView, ABC):

    def __init__(self, parent, model, view, controller):
        super().__init__(parent, model, view, controller)
        inputWidgets = []

        self._fullNameFrame = ttk.Frame(self._elementInfoWindow)
        self._fullNameFrame.pack(anchor='w', fill='x')

        self._aka = MyStringVar()
        self._akaEntry = LabelEntry(
            self._elementInfoWindow,
            text=_('AKA'),
            textvariable=self._aka,
            command=self.apply_changes,
            lblWidth=self._LBL_X
            )
        self._akaEntry.pack(anchor='w', pady=2)
        inputWidgets.append(self._akaEntry)

        self._tags = MyStringVar()
        self._tagsEntry = LabelEntry(
            self._elementInfoWindow,
            text=_('Tags'),
            textvariable=self._tags,
            command=self.apply_changes,
            lblWidth=self._LBL_X
            )
        self._tagsEntry.pack(anchor='w', pady=2)
        inputWidgets.append(self._tagsEntry)

        for widget in inputWidgets:
            widget.bind('<FocusOut>', self.apply_changes)
            self._inputWidgets.append(widget)

    def apply_changes(self, event=None):
        super().apply_changes()

        self._element.aka = self._aka.get()

        newTags = self._tags.get()
        self._element.tags = string_to_list(newTags)

    @abstractmethod
    def set_data(self, elementId):
        super().set_data(elementId)

        self._aka.set(self._element.aka)

        if self._element.tags is not None:
            self._tagsStr = list_to_string(self._element.tags)
        else:
            self._tagsStr = ''
        self._tags.set(self._tagsStr)

    def _create_frames(self):
        self._create_index_card()
        self._create_element_info_window()
        self._create_links_window()
        self._add_separator()
        self._create_notes_window()
        self._create_button_bar()



class CharacterView(WorldElementView):
    _LBL_X = 15

    def __init__(self, parent, model, view, controller):
        super().__init__(parent, model, view, controller)
        inputWidgets = []

        self._fullName = MyStringVar()
        self._fullNameEntry = LabelEntry(
            self._fullNameFrame,
            text=_('Full name'),
            textvariable=self._fullName,
            command=self.apply_changes,
            lblWidth=self._LBL_X
            )
        self._fullNameEntry.pack(anchor='w', pady=2)
        inputWidgets.append(self._fullNameEntry)

        ttk.Separator(self._elementInfoWindow, orient='horizontal').pack(fill='x')

        self._bioFrame = FoldingFrame(self._elementInfoWindow, '', self._toggle_bio_window)

        self._birthDate = MyStringVar()
        self._birthDateEntry = LabelEntry(
            self._bioFrame,
            text=_('Birth date'),
            textvariable=self._birthDate,
            command=self.apply_changes,
            lblWidth=self._LBL_X
            )
        self._birthDateEntry.pack(anchor='w', pady=2)
        inputWidgets.append(self._birthDateEntry)

        self._deathDate = MyStringVar()
        self._deathDateEntry = LabelEntry(
            self._bioFrame,
            text=_('Death date'),
            textvariable=self._deathDate,
            command=self.apply_changes,
            lblWidth=self._LBL_X
            )
        self._deathDateEntry.pack(anchor='w', pady=2)
        inputWidgets.append(self._deathDateEntry)

        self._bioEntry = TextBox(self._bioFrame,
            wrap='word',
            undo=True,
            autoseparators=True,
            maxundo=-1,
            height=10,
            width=10,
            padx=5,
            pady=5,
            bg=prefs['color_text_bg'],
            fg=prefs['color_text_fg'],
            insertbackground=prefs['color_text_fg'],
            )
        self._bioEntry.pack(fill='x')
        inputWidgets.append(self._bioEntry)

        ttk.Separator(self._elementInfoWindow, orient='horizontal').pack(fill='x')

        self._goalsFrame = FoldingFrame(self._elementInfoWindow, '', self._toggle_goals_window)
        self._goalsEntry = TextBox(self._goalsFrame,
            wrap='word',
            undo=True,
            autoseparators=True,
            maxundo=-1,
            height=10,
            width=10,
            padx=5,
            pady=5,
            bg=prefs['color_text_bg'],
            fg=prefs['color_text_fg'],
            insertbackground=prefs['color_text_fg'],
            )
        self._goalsEntry.pack(fill='x')
        inputWidgets.append(self._goalsEntry)

        for widget in inputWidgets:
            widget.bind('<FocusOut>', self.apply_changes)
            self._inputWidgets.append(widget)

        self._prefsShowLinks = 'show_cr_links'

    def apply_changes(self, event=None):
        super().apply_changes()

        self._element.fullName = self._fullName.get()

        if self._bioEntry.hasChanged:
            self._element.bio = self._bioEntry.get_text()

        birthDateStr = self._birthDate.get()
        if not birthDateStr:
            self._element.birthDate = None
        elif birthDateStr != self._element.birthDate:
            try:
                date.fromisoformat(birthDateStr)
            except:
                self._birthDate.set(self._element.birthDate)
                self._ui.show_error(
                    f'{_("Wrong date")}: "{birthDateStr}"\n{_("Required")}: {_("YYYY-MM-DD")}',
                    title=_('Input rejected')
                    )
            else:
                self._element.birthDate = birthDateStr

        deathDateStr = self._deathDate.get()
        if not deathDateStr:
            self._element.deathDate = None
        elif deathDateStr != self._element.deathDate:
            try:
                date.fromisoformat(deathDateStr)
            except:
                self._deathDate.set(self._element.deathDate)
                self._ui.show_error(
                    f'{_("Wrong date")}: "{deathDateStr}"\n{_("Required")}: {_("YYYY-MM-DD")}',
                    title=_('Input rejected')
                    )
            else:
                self._element.deathDate = deathDateStr

        if self._goalsEntry.hasChanged:
            self._element.goals = self._goalsEntry.get_text()

    def set_data(self, elementId):
        self._element = self._mdl.novel.characters[elementId]
        super().set_data(elementId)

        self._fullName.set(self._element.fullName)

        if self._mdl.novel.customChrBio:
            self._bioFrame.buttonText = self._mdl.novel.customChrBio
        else:
            self._bioFrame.buttonText = _('Bio')
        if prefs['show_cr_bio']:
            self._bioFrame.show()
        else:
            self._bioFrame.hide()
        self._bioEntry.set_text(self._element.bio)

        self._birthDate.set(self._element.birthDate)
        self._deathDate.set(self._element.deathDate)

        if self._mdl.novel.customChrGoals:
            self._goalsFrame.buttonText = self._mdl.novel.customChrGoals
        else:
            self._goalsFrame.buttonText = _('Goals')
        if prefs['show_cr_goals']:
            self._goalsFrame.show()
        else:
            self._goalsFrame.hide()
        self._goalsEntry.set_text(self._element.goals)

    def _create_frames(self):
        self._create_index_card()
        self._create_element_info_window()
        self._create_links_window()
        self._add_separator()
        self._create_notes_window()
        self._create_button_bar()

    def _toggle_bio_window(self, event=None):
        if prefs['show_cr_bio']:
            self._bioFrame.hide()
            prefs['show_cr_bio'] = False
        else:
            self._bioFrame.show()
            prefs['show_cr_bio'] = True

    def _toggle_goals_window(self, event=None):
        if prefs['show_cr_goals']:
            self._goalsFrame.hide()
            prefs['show_cr_goals'] = False
        else:
            self._goalsFrame.show()
            prefs['show_cr_goals'] = True

from tkinter import ttk

from datetime import date
from datetime import datetime
from datetime import time
from datetime import timedelta
from tkinter import ttk

from tkinter import ttk



class RelatedSectionView(BasicView):
    _HEIGHT_LIMIT = 10

    def __init__(self, parent, model, view, controller):
        super().__init__(parent, model, view, controller)
        inputWidgets = []

        self._tags = MyStringVar()
        self._tagsEntry = LabelEntry(
            self._elementInfoWindow,
            text=_('Tags'),
            textvariable=self._tags,
            command=self.apply_changes,
            lblWidth=self._LBL_X
            )
        self._tagsEntry.pack(anchor='w', pady=2)
        inputWidgets.append(self._tagsEntry)

        self._sectionExtraFrame = ttk.Frame(self._elementInfoWindow)
        self._sectionExtraFrame.pack(anchor='w', fill='x')

        ttk.Separator(self._elementInfoWindow, orient='horizontal').pack(fill='x')

        self._relationFrame = FoldingFrame(self._elementInfoWindow, _('Relationships'), self._toggle_relation_frame)

        self._crTitles = ''
        crHeading = ttk.Frame(self._relationFrame)
        self._characterLabel = ttk.Label(crHeading, text=_('Characters'))
        self._characterLabel.pack(anchor='w', side='left')
        ttk.Button(crHeading, text=_('Show ages'), command=self._show_ages).pack(anchor='e')
        crHeading.pack(fill='x')
        self._characterCollection = CollectionBox(
            self._relationFrame,
            cmdAdd=self._pick_character,
            cmdRemove=self._remove_character,
            cmdOpen=self._go_to_character,
            cmdActivate=self._activate_character_buttons,
            lblOpen=_('Go to'),
            iconAdd=self._ui.icons.addIcon,
            iconRemove=self._ui.icons.removeIcon,
            iconOpen=self._ui.icons.gotoIcon
            )
        self._characterCollection.pack(fill='x')
        inputWidgets.extend(self._characterCollection.inputWidgets)

        self._lcTitles = ''
        self._locationLabel = ttk.Label(self._relationFrame, text=_('Locations'))
        self._locationLabel.pack(anchor='w')
        self._locationCollection = CollectionBox(
            self._relationFrame,
            cmdAdd=self._pick_location,
            cmdRemove=self._remove_location,
            cmdOpen=self._go_to_location,
            cmdActivate=self._activate_location_buttons,
            lblOpen=_('Go to'),
            iconAdd=self._ui.icons.addIcon,
            iconRemove=self._ui.icons.removeIcon,
            iconOpen=self._ui.icons.gotoIcon
            )
        self._locationCollection.pack(fill='x')
        inputWidgets.extend(self._locationCollection.inputWidgets)

        self._itTitles = ''
        self._itemLabel = ttk.Label(self._relationFrame, text=_('Items'))
        self._itemLabel.pack(anchor='w')
        self._itemCollection = CollectionBox(
            self._relationFrame,
            cmdAdd=self._pick_item,
            cmdRemove=self._remove_item,
            cmdOpen=self._go_to_item,
            cmdActivate=self._activate_item_buttons,
            lblOpen=_('Go to'),
            iconAdd=self._ui.icons.addIcon,
            iconRemove=self._ui.icons.removeIcon,
            iconOpen=self._ui.icons.gotoIcon
            )
        self._itemCollection.pack(fill='x')
        inputWidgets.extend(self._itemCollection.inputWidgets)

        for widget in inputWidgets:
            widget.bind('<FocusOut>', self.apply_changes)
            self._inputWidgets.append(widget)

        self._prefsShowLinks = 'show_sc_links'

    def apply_changes(self, event=None):
        super().apply_changes()

        newTags = self._tags.get()
        if self._tagsStr or newTags:
            self._element.tags = string_to_list(newTags)

    def set_data(self, elementId):
        self._element = self._mdl.novel.sections[elementId]
        super().set_data(elementId)

        self._tagsStr = list_to_string(self._element.tags)
        self._tags.set(self._tagsStr)

        if prefs['show_relationships']:
            self._relationFrame.show()
        else:
            self._relationFrame.hide()

        self._crTitles = self._get_element_titles(self._element.characters, self._mdl.novel.characters)
        self._characterCollection.cList.set(self._crTitles)
        listboxSize = len(self._crTitles)
        if listboxSize > self._HEIGHT_LIMIT:
            listboxSize = self._HEIGHT_LIMIT
        self._characterCollection.cListbox.config(height=listboxSize)
        if not self._characterCollection.cListbox.curselection() or not self._characterCollection.cListbox.focus_get():
            self._characterCollection.disable_buttons()

        self._lcTitles = self._get_element_titles(self._element.locations, self._mdl.novel.locations)
        self._locationCollection.cList.set(self._lcTitles)
        listboxSize = len(self._lcTitles)
        if listboxSize > self._HEIGHT_LIMIT:
            listboxSize = self._HEIGHT_LIMIT
        self._locationCollection.cListbox.config(height=listboxSize)
        if not self._locationCollection.cListbox.curselection() or not self._locationCollection.cListbox.focus_get():
            self._locationCollection.disable_buttons()

        self._itTitles = self._get_element_titles(self._element.items, self._mdl.novel.items)
        self._itemCollection.cList.set(self._itTitles)
        listboxSize = len(self._itTitles)
        if listboxSize > self._HEIGHT_LIMIT:
            listboxSize = self._HEIGHT_LIMIT
        self._itemCollection.cListbox.config(height=listboxSize)
        if not self._itemCollection.cListbox.curselection() or not self._itemCollection.cListbox.focus_get():
            self._itemCollection.disable_buttons()

    def _activate_character_buttons(self, event=None):
        if self._element.characters:
            self._characterCollection.enable_buttons()
        else:
            self._characterCollection.disable_buttons()

    def _activate_location_buttons(self, event=None):
        if self._element.locations:
            self._locationCollection.enable_buttons()
        else:
            self._locationCollection.disable_buttons()

    def _activate_item_buttons(self, event=None):
        if self._element.items:
            self._itemCollection.enable_buttons()
        else:
            self._itemCollection.disable_buttons()

    def _add_character(self, event=None):
        crList = self._element.characters
        crId = self._ui.tv.tree.selection()[0]
        if crId.startswith(CHARACTER_PREFIX) and not crId in crList:
            crList.append(crId)
            self._element.characters = crList

    def _add_location(self, event=None):
        lcList = self._element.locations
        lcId = self._ui.tv.tree.selection()[0]
        if lcId.startswith(LOCATION_PREFIX)and not lcId in lcList:
            lcList.append(lcId)
            self._element.locations = lcList

    def _add_item(self, event=None):
        itList = self._element.items
        itId = self._ui.tv.tree.selection()[0]
        if itId.startswith(ITEM_PREFIX)and not itId in itList:
            itList.append(itId)
            self._element.items = itList

    def _create_frames(self):
        self._create_index_card()
        self._create_element_info_window()
        self._create_links_window()
        self._add_separator()
        self._create_notes_window()
        self._create_button_bar()

    def _get_relation_id_list(self, newTitleStr, oldTitleStr, elements):
        if newTitleStr or oldTitleStr:
            if oldTitleStr != newTitleStr:
                elemIds = []
                for elemTitle in string_to_list(newTitleStr):
                    for elemId in elements:
                        if elements[elemId].title == elemTitle:
                            elemIds.append(elemId)
                            break
                    else:
                        self._ui.show_error(f'{_("Wrong name")}: "{elemTitle}"', title=_('Input rejected'))
                return elemIds

        return None

    def _get_element_titles(self, elemIds, elements):
        elemTitles = []
        if elemIds:
            for elemId in elemIds:
                try:
                    elemTitles.append(elements[elemId].title)
                except:
                    pass
        return elemTitles

    def _go_to_character(self, event=None):
        try:
            selection = self._characterCollection.cListbox.curselection()[0]
        except:
            return

        self._ui.tv.go_to_node(self._element.characters[selection])

    def _go_to_location(self, event=None):
        try:
            selection = self._locationCollection.cListbox.curselection()[0]
        except:
            return

        self._ui.tv.go_to_node(self._element.locations[selection])

    def _go_to_item(self, event=None):
        try:
            selection = self._itemCollection.cListbox.curselection()[0]
        except:
            return

        self._ui.tv.go_to_node(self._element.items[selection])

    def _pick_character(self, event=None):
        self._start_picking_mode(command=self._add_character)
        self._ui.tv.see_node(CR_ROOT)

    def _pick_location(self, event=None):
        self._start_picking_mode(command=self._add_location)
        self._ui.tv.see_node(LC_ROOT)

    def _pick_item(self, event=None):
        self._start_picking_mode(command=self._add_item)
        self._ui.tv.see_node(IT_ROOT)

    def _remove_character(self, event=None):
        try:
            selection = self._characterCollection.cListbox.curselection()[0]
        except:
            return

        crId = self._element.characters[selection]
        title = self._mdl.novel.characters[crId].title
        if self._ui.ask_yes_no(f'{_("Remove character")}: "{title}"?'):
            crList = self._element.characters
            del crList[selection]
            self._element.characters = crList

    def _remove_location(self, event=None):
        try:
            selection = self._locationCollection.cListbox.curselection()[0]
        except:
            return

        lcId = self._element.locations[selection]
        title = self._mdl.novel.locations[lcId].title
        if self._ui.ask_yes_no(f'{_("Remove location")}: "{title}"?'):
            lcList = self._element.locations
            del lcList[selection]
            self._element.locations = lcList

    def _remove_item(self, event=None):
        try:
            selection = self._itemCollection.cListbox.curselection()[0]
        except:
            return

        itId = self._element.items[selection]
        title = self._mdl.novel.items[itId].title
        if self._ui.ask_yes_no(f'{_("Remove item")}: "{title}"?'):
            itList = self._element.items
            del itList[selection]
            self._element.items = itList

    def _show_ages(self, event=None):
        if self._element.date is not None:
            now = self._element.date
        else:
            try:
                now = get_specific_date(
                    self._element.day,
                    self._mdl.novel.referenceDate
                    )
            except:
                self._show_missing_date_message()
                return

        charList = []
        for crId in self._element.characters:
            birthDate = self._mdl.novel.characters[crId].birthDate
            deathDate = self._mdl.novel.characters[crId].deathDate
            try:
                years = get_age(now, birthDate, deathDate)
                if years < 0:
                    years *= -1
                    suffix = _('years after death')
                else:
                    suffix = _('years old')
                charList.append(f'{self._mdl.novel.characters[crId].title}: {years} {suffix}')
            except:
                charList.append(f'{self._mdl.novel.characters[crId].title}: ({_("no data")})')

        if charList:
            self._ui.show_info(
                '\n'.join(charList),
                title=f'{_("Date")}: {datestr(now)}'
                )

    def _toggle_relation_frame(self, event=None):
        if prefs['show_relationships']:
            self._relationFrame.hide()
            prefs['show_relationships'] = False
        else:
            self._relationFrame.show()
            prefs['show_relationships'] = True



class DatedSectionView(RelatedSectionView):
    _DATE_TIME_LBL_X = 15

    def __init__(self, parent, model, view, controller):
        super().__init__(parent, model, view, controller)
        inputWidgets = []

        ttk.Separator(self._elementInfoWindow, orient='horizontal').pack(fill='x')

        self._dateTimeFrame = FoldingFrame(
            self._elementInfoWindow,
            _('Date/Time'),
            self._toggle_date_time_frame)
        sectionStartFrame = ttk.Frame(self._dateTimeFrame
                                      )
        sectionStartFrame.pack(fill='x')
        localeDateFrame = ttk.Frame(sectionStartFrame)
        localeDateFrame.pack(fill='x')
        ttk.Label(localeDateFrame, text=_('Start'), width=self._DATE_TIME_LBL_X).pack(side='left')

        self._startDate = MyStringVar()
        self._startDateEntry = LabelEntry(
            sectionStartFrame,
            text=_('Date'),
            textvariable=self._startDate,
            command=self.apply_changes,
            lblWidth=self._DATE_TIME_LBL_X
            )
        self._startDateEntry.pack(anchor='w')
        inputWidgets.append(self._startDateEntry)

        self._startTime = MyStringVar()
        self._startTimeEntry = LabelEntry(
            sectionStartFrame,
            text=_('Time'),
            textvariable=self._startTime,
            command=self.apply_changes,
            lblWidth=self._DATE_TIME_LBL_X
            )
        self._startTimeEntry.pack(anchor='w')
        inputWidgets.append(self._startTimeEntry)

        self._startDay = MyStringVar()
        self._startDayEntry = LabelEntry(
            sectionStartFrame,
            text=_('Day'),
            textvariable=self._startDay,
            command=self.apply_changes,
            lblWidth=self._DATE_TIME_LBL_X
            )
        self._startDayEntry.pack(anchor='w')
        inputWidgets.append(self._startDayEntry)
        self._startDayEntry.entry.bind('<Return>', self._change_day)

        self._weekDay = MyStringVar()
        ttk.Label(localeDateFrame, textvariable=self._weekDay).pack(side='left')

        self._localeDate = MyStringVar()
        ttk.Label(localeDateFrame, textvariable=self._localeDate).pack(side='left')

        ttk.Label(localeDateFrame, textvariable=self._startTime).pack(side='left')

        ttk.Button(
            localeDateFrame,
            text=_('Moon phase'),
            command=self._show_moonphase
            ).pack(anchor='e')

        self._clearDateButton = ttk.Button(
            sectionStartFrame,
            text=_('Clear date/time'),
            command=self._clear_start
            )
        self._clearDateButton.pack(side='left', fill='x', expand=True, padx=1, pady=2)
        inputWidgets.append(self._clearDateButton)

        self._generateDateButton = ttk.Button(
            sectionStartFrame,
            text=_('Generate'),
            command=self._auto_set_date
            )
        self._generateDateButton.pack(side='left', fill='x', expand=True, padx=1, pady=2)
        inputWidgets.append(self._generateDateButton)

        self._toggleDateButton = ttk.Button(
            sectionStartFrame,
            text=_('Convert date/day'),
            command=self._toggle_date
            )
        self._toggleDateButton.pack(side='left', fill='x', expand=True, padx=1, pady=2)
        inputWidgets.append(self._toggleDateButton)

        ttk.Separator(self._dateTimeFrame, orient='horizontal').pack(fill='x', pady=2)

        sectionDurationFrame = ttk.Frame(self._dateTimeFrame)
        sectionDurationFrame.pack(fill='x')
        ttk.Label(sectionDurationFrame, text=_('Duration')).pack(anchor='w')

        self._lastsDays = MyStringVar()
        self._lastsDaysEntry = LabelEntry(
            sectionDurationFrame,
            text=_('Days'),
            textvariable=self._lastsDays,
            command=self.apply_changes,
            lblWidth=self._DATE_TIME_LBL_X
            )
        self._lastsDaysEntry.pack(anchor='w')
        inputWidgets.append(self._lastsDaysEntry)

        self._lastsHours = MyStringVar()
        self._lastsHoursEntry = LabelEntry(
            sectionDurationFrame,
            text=_('Hours'),
            textvariable=self._lastsHours,
            command=self.apply_changes,
            lblWidth=self._DATE_TIME_LBL_X
            )
        self._lastsHoursEntry.pack(anchor='w')
        inputWidgets.append(self._lastsHoursEntry)

        self._lastsMinutes = MyStringVar()
        self._lastsMinutesEntry = LabelEntry(
            sectionDurationFrame,
            text=_('Minutes'),
            textvariable=self._lastsMinutes,
            command=self.apply_changes,
            lblWidth=self._DATE_TIME_LBL_X
            )
        self._lastsMinutesEntry.pack(anchor='w')
        inputWidgets.append(self._lastsMinutesEntry)

        self._clearDurationButton = ttk.Button(
            sectionDurationFrame,
            text=_('Clear duration'),
            command=self._clear_duration
            )
        self._clearDurationButton.pack(side='left', padx=1, pady=2)
        inputWidgets.append(self._clearDurationButton)

        self._generatDurationButton = ttk.Button(
            sectionDurationFrame,
            text=_('Generate'),
            command=self._auto_set_duration
            )
        self._generatDurationButton.pack(side='left', padx=1, pady=2)
        inputWidgets.append(self._generatDurationButton)


        for widget in inputWidgets:
            widget.bind('<FocusOut>', self.apply_changes)
            self._inputWidgets.append(widget)

    def _change_day(self, event=None):
            dayStr = self._startDay.get()
            if dayStr or self._element.day:
                if dayStr != self._element.day:
                    if not dayStr:
                        self._element.day = None
                    else:
                        try:
                            int(dayStr)
                        except ValueError:
                            self._startDay.set(self._element.day)
                            self._ui.show_error(
                                f'{_("Wrong entry: number required")}.',
                                title=_('Input rejected')
                                )
                        else:
                            self._element.day = dayStr
                            self._element.date = None

    def apply_changes(self, event=None):
        super().apply_changes()


        dateStr = self._startDate.get()
        if not dateStr:
            self._element.date = None
        elif dateStr != self._element.date:
            try:
                date.fromisoformat(dateStr)
            except ValueError:
                self._startDate.set(self._element.date)
                self._ui.show_error(
                    f'{_("Wrong date")}: "{dateStr}"\n{_("Required")}: {_("YYYY-MM-DD")}',
                    title=_('Input rejected')
                    )
            else:
                self._element.date = dateStr

        timeStr = self._startTime.get()
        if not timeStr:
            self._element.time = None
        else:
            if self._element.time:
                dispTime = self._element.time.rsplit(':', 1)[0]
            else:
                dispTime = ''
            if timeStr != dispTime:
                try:
                    time.fromisoformat(timeStr)
                except ValueError:
                    self._startTime.set(dispTime)
                    self._ui.show_error(
                        f'{_("Wrong time")}: "{timeStr}"\n{_("Required")}: {_("hh:mm")}',
                        title=_('Input rejected')
                        )
                else:
                    while timeStr.count(':') < 2:
                        timeStr = f'{timeStr}:00'
                    self._element.time = timeStr
                    dispTime = self._element.time.rsplit(':', 1)[0]
                    self._startTime.set(dispTime)

        if self._element.date:
            self._element.day = None
        else:
            self._change_day()

        wrongEntry = False
        newEntry = False

        hoursLeft = 0
        lastsMinutesStr = self._lastsMinutes.get()
        if lastsMinutesStr or self._element.lastsMinutes:
            if lastsMinutesStr != self._element.lastsMinutes:
                if not lastsMinutesStr:
                    lastsMinutesStr = 0
                try:
                    minutes = int(lastsMinutesStr)
                except ValueError:
                    wrongEntry = True
                else:
                    hoursLeft, minutes = divmod(minutes, 60)
                    if minutes > 0:
                        lastsMinutesStr = str(minutes)
                    else:
                        lastsMinutesStr = None
                    self._lastsMinutes.set(lastsMinutesStr)
                    newEntry = True

        daysLeft = 0
        lastsHoursStr = self._lastsHours.get()
        if hoursLeft or lastsHoursStr or self._element.lastsHours:
            if hoursLeft or lastsHoursStr != self._element.lastsHours:
                try:
                    if lastsHoursStr:
                        hoursLeft += int(lastsHoursStr)
                    daysLeft, hoursLeft = divmod(hoursLeft, 24)
                    if hoursLeft > 0:
                        lastsHoursStr = str(hoursLeft)
                    else:
                        lastsHoursStr = None
                    self._lastsHours.set(lastsHoursStr)
                except ValueError:
                    wrongEntry = True
                else:
                    newEntry = True

        lastsDaysStr = self._lastsDays.get()
        if daysLeft or lastsDaysStr or self._element.lastsDays:
            if daysLeft or lastsDaysStr != self._element.lastsDays:
                try:
                    if lastsDaysStr:
                        daysLeft += int(lastsDaysStr)
                    if daysLeft > 0:
                        lastsDaysStr = str(daysLeft)
                    else:
                        lastsDaysStr = None
                    self._lastsDays.set(lastsDaysStr)
                except ValueError:
                    wrongEntry = True
                else:
                    newEntry = True

        if wrongEntry:
            self._lastsMinutes.set(self._element.lastsMinutes)
            self._lastsHours.set(self._element.lastsHours)
            self._lastsDays.set(self._element.lastsDays)
            self._ui.show_error(f'{_("Wrong entry: number required")}.', title=_('Input rejected'))
        elif newEntry:
            self._element.lastsMinutes = lastsMinutesStr
            self._element.lastsHours = lastsHoursStr
            self._element.lastsDays = lastsDaysStr

    def set_data(self, elementId):
        self._element = self._mdl.novel.sections[elementId]
        super().set_data(elementId)

        if self._element.date and self._element.weekDay is not None:
            self._weekDay.set(WEEKDAYS[self._element.weekDay])
        elif self._element.day and self._mdl.novel.referenceWeekDay is not None:
            self._weekDay.set(WEEKDAYS[(int(self._element.day) + self._mdl.novel.referenceWeekDay) % 7])
        else:
            self._weekDay.set('')
        self._startDate.set(self._element.date)
        if self._element.localeDate:
            displayDate = get_section_date_str(self._element)
        elif self._element.day:
            displayDate = f'{_("Day")} {self._element.day}'
        else:
            displayDate = ''
        self._localeDate.set(displayDate)

        if self._element.time:
            dispTime = self._element.time.rsplit(':', 1)[0]
        else:
            dispTime = ''
        self._startTime.set(dispTime)

        self._startDay.set(self._element.day)
        self._lastsDays.set(self._element.lastsDays)
        self._lastsHours.set(self._element.lastsHours)
        self._lastsMinutes.set(self._element.lastsMinutes)

        if prefs['show_date_time']:
            self._dateTimeFrame.show()
        else:
            self._dateTimeFrame.hide()

    def _auto_set_date(self):
        prevScId = self._ui.tv.prev_node(self._elementId)
        if not prevScId:
            return

        newDate, newTime, newDay = self._mdl.novel.sections[prevScId].get_end_date_time()
        if newTime is None:
            self._ui.show_error(
                _('The previous section has no time set.'),
                title=_('Cannot generate date/time')
                )
            return

        self._element.date = newDate
        self._element.time = newTime
        self._element.day = newDay
        self._startDate.set(newDate)
        self._startTime.set(newTime.rsplit(':', 1)[0])
        self._startDay.set(newDay)

    def _auto_set_duration(self):

        def day_to_date(day, refDate):
            deltaDays = timedelta(days=int(day))
            return date.isoformat(refDate + deltaDays)

        nextScId = self._ui.tv.next_node(self._elementId)
        if not nextScId:
            return

        thisTimeIso = self._element.time
        if not thisTimeIso:
            self._ui.show_error(
                _('This section has no time set.'),
                title=_('Cannot generate duration')
                )
            return

        nextTimeIso = self._mdl.novel.sections[nextScId].time
        if not nextTimeIso:
            self._ui.show_error(
                _('The next section has no time set.'),
                title=_('Cannot generate duration')
                )
            return

        try:
            refDateIso = self._mdl.novel.referenceDate
            refDate = date.fromisoformat(refDateIso)
        except:
            refDate = date.today()
            refDateIso = date.isoformat(refDate)
        if self._mdl.novel.sections[nextScId].date:
            nextDateIso = self._mdl.novel.sections[nextScId].date
        elif self._mdl.novel.sections[nextScId].day:
            nextDateIso = day_to_date(self._mdl.novel.sections[nextScId].day, refDate)
        elif self._element.day:
            nextDateIso = self._element.day
        else:
            nextDateIso = refDateIso
        if self._element.date:
            thisDateIso = self._element.date
        elif self._element.day:
            thisDateIso = day_to_date(self._element.day, refDate)
        else:
            thisDateIso = nextDateIso

        StartDateTime = datetime.fromisoformat(f'{thisDateIso}T{thisTimeIso}')
        endDateTime = datetime.fromisoformat(f'{nextDateIso}T{nextTimeIso}')
        sectionDuration = endDateTime - StartDateTime
        lastsHours = sectionDuration.seconds // 3600
        lastsMinutes = (sectionDuration.seconds % 3600) // 60
        if sectionDuration.days:
            newDays = str(sectionDuration.days)
        else:
            newDays = None
        if lastsHours:
            newHours = str(lastsHours)
        else:
            newHours = None
        if lastsMinutes:
            newMinutes = str(lastsMinutes)
        else:
            newMinutes = None

        self.doNotUpdate = True
        self._element.lastsDays = newDays
        self._element.lastsHours = newHours
        self._element.lastsMinutes = newMinutes
        self.doNotUpdate = False
        self._lastsDays.set(newDays)
        self._lastsHours.set(newHours)
        self._lastsMinutes.set(newMinutes)

    def _clear_duration(self):
        durationData = [
            self._element.lastsDays,
            self._element.lastsHours,
            self._element.lastsMinutes,
            ]
        hasData = False
        for dataElement in durationData:
            if dataElement:
                hasData = True
        if hasData and self._ui.ask_yes_no(_('Clear duration from this section?')):
            self._element.lastsDays = None
            self._element.lastsHours = None
            self._element.lastsMinutes = None

    def _clear_start(self):
        startData = [
            self._element.date,
            self._element.time,
            self._element.day,
            ]
        hasData = False
        for dataElement in startData:
            if dataElement:
                hasData = True
        if hasData and self._ui.ask_yes_no(_('Clear date/time from this section?')):
            self._element.date = None
            self._element.time = None
            self._element.day = None

    def _show_moonphase(self, event=None):
        if self._element.date is not None:
            now = self._element.date
        else:
            try:
                now = get_specific_date(
                    self._element.day,
                    self._mdl.novel.referenceDate
                    )
            except:
                self._show_missing_date_message()
                return

        self._ui.show_info(
            f'{_("Moon phase")}: '\
            f'{self._mdl.nvService.get_moon_phase_str(now)}',
            title=f'{_("Date")}: {datestr(now)}'
            )

    def _toggle_date(self, event=None):
        if not self._mdl.novel.referenceDate:
            self._show_missing_reference_date_message()
            return

        self.doNotUpdate = True
        if self._element.date:
            self._element.date_to_day(self._mdl.novel.referenceDate)
        elif self._element.day:
            self._element.day_to_date(self._mdl.novel.referenceDate)
        else:
            self._show_missing_date_message()
            return

        self.doNotUpdate = False
        self.set_data(self._elementId)

    def _toggle_date_time_frame(self, event=None):
        if prefs['show_date_time']:
            self._dateTimeFrame.hide()
            prefs['show_date_time'] = False
        else:
            self._dateTimeFrame.show()
            prefs['show_date_time'] = True



class FullSectionView(DatedSectionView):

    def __init__(self, parent, model, view, controller):
        super().__init__(parent, model, view, controller)
        inputWidgets = []

        self._viewpoint = MyStringVar()
        self._characterCombobox = LabelCombo(
            self._sectionExtraFrame,
            text=_('Viewpoint'),
            textvariable=self._viewpoint,
            values=[],
            )
        self._characterCombobox.pack(anchor='w', pady=2)
        inputWidgets.append(self._characterCombobox)
        self._characterCombobox.combo.bind('<<ComboboxSelected>>', self.apply_changes)
        self._vpList = []

        self._isUnused = tk.BooleanVar()
        self._isUnusedCheckbox = ttk.Checkbutton(
            self._sectionExtraFrame,
            text=_('Unused'),
            variable=self._isUnused,
            onvalue=True,
            offvalue=False,
            command=self.apply_changes,
            )
        self._isUnusedCheckbox.pack(anchor='w')
        inputWidgets.append(self._isUnusedCheckbox)

        self._appendToPrev = tk.BooleanVar()
        self._appendToPrevCheckbox = ttk.Checkbutton(
            self._sectionExtraFrame,
            text=_('Append to previous section'),
            variable=self._appendToPrev,
            onvalue=True,
            offvalue=False,
            command=self.apply_changes,
            )
        self._appendToPrevCheckbox.pack(anchor='w')
        inputWidgets.append(self._appendToPrevCheckbox)

        ttk.Separator(self._sectionExtraFrame, orient='horizontal').pack(fill='x')

        self._plotFrame = FoldingFrame(self._sectionExtraFrame, _('Plot'), self._toggle_plot_frame)

        self._plotlineTitles = ''
        self._plotlineLabel = ttk.Label(self._plotFrame, text=_('Plot lines'))
        self._plotlineLabel.pack(anchor='w')
        self._plotlineCollection = CollectionBox(
            self._plotFrame,
            cmdAdd=self._pick_plotline,
            cmdRemove=self._remove_plotline,
            cmdOpen=self._go_to_arc,
            cmdActivate=self._activate_arc_buttons,
            cmdSelect=self._on_select_plotline,
            lblOpen=_('Go to'),
            iconAdd=self._ui.icons.addIcon,
            iconRemove=self._ui.icons.removeIcon,
            iconOpen=self._ui.icons.gotoIcon
            )
        self._plotlineCollection.pack(fill='x')
        inputWidgets.extend(self._plotlineCollection.inputWidgets)
        self._selectedPlotline = None

        ttk.Label(self._plotFrame, text=_('Notes on the selected plot line')).pack(anchor='w')
        self._plotNotesWindow = TextBox(
            self._plotFrame,
            wrap='word',
            undo=True,
            autoseparators=True,
            maxundo=-1,
            height=prefs['gco_height'],
            padx=5,
            pady=5,
            bg=prefs['color_text_bg'],
            fg=prefs['color_text_fg'],
            insertbackground=prefs['color_text_fg'],
            )
        self._plotNotesWindow.pack(fill='x')
        inputWidgets.append(self._plotNotesWindow)

        tk.Label(self._plotFrame, text=_('Plot points')).pack(anchor='w')

        self._plotPointsDisplay = tk.Label(self._plotFrame, anchor='w', bg='white')
        self._plotPointsDisplay.pack(anchor='w', fill='x')

        ttk.Separator(self._sectionExtraFrame, orient='horizontal').pack(fill='x')

        self._sceneFrame = FoldingFrame(self._sectionExtraFrame, _('Scene'), self._toggle_scene_frame)

        selectionFrame = ttk.Frame(self._sceneFrame)
        self._customPlotProgress = ''
        self._customCharacterization = ''
        self._customWorldBuilding = ''
        self._customGoal = ''
        self._customConflict = ''
        self._customOutcome = ''
        self._scene = tk.IntVar()

        self._notApplicableRadiobutton = ttk.Radiobutton(
            selectionFrame,
            text=_('Not a scene'),
            variable=self._scene,
            value=0, command=self._set_not_applicable,
            )
        self._notApplicableRadiobutton.pack(side='left', anchor='w')
        inputWidgets.append(self._notApplicableRadiobutton)

        self._actionRadiobutton = ttk.Radiobutton(
            selectionFrame,
            text=_('Action'),
            variable=self._scene,
            value=1, command=self._set_action_scene,
            )
        self._actionRadiobutton.pack(side='left', anchor='w')
        inputWidgets.append(self._actionRadiobutton)

        self._reactionRadiobutton = ttk.Radiobutton(
            selectionFrame,
            text=_('Reaction'),
            variable=self._scene,
            value=2,
            command=self._set_reaction_scene,
            )
        self._reactionRadiobutton.pack(side='left', anchor='w')
        inputWidgets.append(self._reactionRadiobutton)

        self._customRadiobutton = ttk.Radiobutton(
            selectionFrame,
            text=_('Other'),
            variable=self._scene,
            value=3,
            command=self._set_custom_scene
            )
        self._customRadiobutton.pack(anchor='w')
        inputWidgets.append(self._customRadiobutton)

        selectionFrame.pack(fill='x')

        self._goalLabel = ttk.Label(self._sceneFrame)
        self._goalLabel.pack(anchor='w')
        self._goalWindow = TextBox(
            self._sceneFrame,
            wrap='word',
            undo=True,
            autoseparators=True,
            maxundo=-1,
            height=prefs['gco_height'],
            padx=5,
            pady=5,
            bg=prefs['color_text_bg'],
            fg=prefs['color_text_fg'],
            insertbackground=prefs['color_text_fg'],
            )
        self._goalWindow.pack(fill='x')
        inputWidgets.append(self._goalWindow)

        self._conflictLabel = ttk.Label(self._sceneFrame)
        self._conflictLabel.pack(anchor='w')
        self._conflictWindow = TextBox(
            self._sceneFrame,
            wrap='word',
            undo=True,
            autoseparators=True,
            maxundo=-1,
            height=prefs['gco_height'],
            padx=5,
            pady=5,
            bg=prefs['color_text_bg'],
            fg=prefs['color_text_fg'],
            insertbackground=prefs['color_text_fg'],
            )
        self._conflictWindow.pack(fill='x')
        inputWidgets.append(self._conflictWindow)

        self._outcomeLabel = ttk.Label(self._sceneFrame)
        self._outcomeLabel.pack(anchor='w')
        self._outcomeWindow = TextBox(
            self._sceneFrame,
            wrap='word',
            undo=True,
            autoseparators=True,
            maxundo=-1,
            height=prefs['gco_height'],
            padx=5,
            pady=5,
            bg=prefs['color_text_bg'],
            fg=prefs['color_text_fg'],
            insertbackground=prefs['color_text_fg'],
            )
        self._outcomeWindow.pack(fill='x')
        inputWidgets.append(self._outcomeWindow)

        for widget in inputWidgets:
            widget.bind('<FocusOut>', self.apply_changes)
            self._inputWidgets.append(widget)

    def apply_changes(self, event=None):
        super().apply_changes()

        option = self._characterCombobox.current()
        if option >= 0:
            vpId = self._vpList[option]
            scCharacters = self._element.characters
            if scCharacters:
                    if vpId in scCharacters:
                        scCharacters.remove(vpId)
                    scCharacters.insert(0, vpId)
            else:
                scCharacters = [vpId]
            self._element.characters = scCharacters

        if self._isUnused.get():
            self._ctrl.set_type(1)
        else:
            self._ctrl.set_type(0)
        if self._element.scType > 0:
            self._isUnused.set(True)

        self._element.appendToPrev = self._appendToPrev.get()

        self._save_plot_notes()

        if self._goalWindow.hasChanged:
            self._element.goal = self._goalWindow.get_text()
        if self._conflictWindow.hasChanged:
            self._element.conflict = self._conflictWindow.get_text()

        if self._outcomeWindow.hasChanged:
            self._element.outcome = self._outcomeWindow.get_text()

    def set_data(self, elementId):
        self._element = self._mdl.novel.sections[elementId]
        super().set_data(elementId)

        charNames = []
        self._vpList = []
        for crId in self._mdl.novel.tree.get_children(CR_ROOT):
            charNames.append(self._mdl.novel.characters[crId].title)
            self._vpList.append(crId)
        self._characterCombobox.configure(values=charNames)
        if self._element.characters:
            vp = self._mdl.novel.characters[self._element.characters[0]].title
        else:
            vp = ''
        self._viewpoint.set(value=vp)

        self._plotlineTitles = self._get_plotline_titles(self._element.scPlotLines, self._mdl.novel.plotLines)
        self._plotlineCollection.cList.set(self._plotlineTitles)
        listboxSize = len(self._plotlineTitles)
        if listboxSize > self._HEIGHT_LIMIT:
            listboxSize = self._HEIGHT_LIMIT
        self._plotlineCollection.cListbox.config(height=listboxSize)
        if not self._plotlineCollection.cListbox.curselection() or not self._plotlineCollection.cListbox.focus_get():
            self._plotlineCollection.disable_buttons()

        self._plotNotesWindow.clear()
        self._plotNotesWindow.config(state='disabled')
        self._plotNotesWindow.config(bg='light gray')
        if self._plotlineTitles:
            self._plotlineCollection.cListbox.select_clear(0, 'end')
            self._plotlineCollection.cListbox.select_set('end')
            self._selectedPlotline = -1
            self._on_select_plotline(-1)
        else:
            self._selectedPlotline = None

        plotPointTitles = []
        for ppId in self._element.scPlotPoints:
            plId = self._element.scPlotPoints[ppId]
            plotPointTitles.append(f'{self._mdl.novel.plotLines[plId].shortName}: {self._mdl.novel.plotPoints[ppId].title}')
        self._plotPointsDisplay.config(text=list_to_string(plotPointTitles))

        if self._element.scType > 0:
            self._isUnused.set(True)
        else:
            self._isUnused.set(False)

        if self._element.appendToPrev:
            self._appendToPrev.set(True)
        else:
            self._appendToPrev.set(False)

        if self._mdl.novel.customPlotProgress:
            self._customPlotProgress = self._mdl.novel.customPlotProgress
        else:
            self._customPlotProgress = ''

        if self._mdl.novel.customCharacterization:
            self._customCharacterization = self._mdl.novel.customCharacterization
        else:
            self._customCharacterization = ''

        if self._mdl.novel.customWorldBuilding:
            self._customWorldBuilding = self._mdl.novel.customWorldBuilding
        else:
            self._customWorldBuilding = ''

        if self._mdl.novel.customGoal:
            self._customGoal = self._mdl.novel.customGoal
        else:
            self._customGoal = ''

        if self._mdl.novel.customConflict:
            self._customConflict = self._mdl.novel.customConflict
        else:
            self._customConflict = ''

        if self._mdl.novel.customOutcome:
            self._customOutcome = self._mdl.novel.customOutcome
        else:
            self._customOutcome = ''

        if prefs['show_plot']:
            self._plotFrame.show()
        else:
            self._plotFrame.hide()

        if prefs['show_scene']:
            self._sceneFrame.show()
        else:
            self._sceneFrame.hide()

        self._scene.set(self._element.scene)

        self._goalWindow.set_text(self._element.goal)

        self._conflictWindow.set_text(self._element.conflict)

        self._outcomeWindow.set_text(self._element.outcome)

        if self._element.scene == 3:
            self._set_custom_scene()
        elif self._element.scene == 2:
            self._set_reaction_scene()
        elif self._element.scene == 1:
            self._set_action_scene()
        else:
            self._set_not_applicable()

    def _activate_arc_buttons(self, event=None):
        if self._element.scPlotLines:
            self._plotlineCollection.enable_buttons()
        else:
            self._plotlineCollection.disable_buttons()

    def _add_plotline(self, event=None):
        plotlineList = self._element.scPlotLines
        plId = self._ui.tv.tree.selection()[0]
        if plId.startswith(PLOT_LINE_PREFIX) and not plId in plotlineList:
            plotlineList.append(plId)
            self._element.scPlotLines = plotlineList
            plotlineSections = self._mdl.novel.plotLines[plId].sections
            if not self._elementId in plotlineSections:
                plotlineSections.append(self._elementId)
                self._mdl.novel.plotLines[plId].sections = plotlineSections


    def _get_plotline_titles(self, elemIds, elements):
        elemTitles = []
        if elemIds:
            for elemId in elemIds:
                try:
                    elemTitles.append(f'({elements[elemId].shortName}) {elements[elemId].title}')
                except:
                    pass
        return elemTitles

    def _get_relation_id_list(self, newTitleStr, oldTitleStr, elements):
        if newTitleStr or oldTitleStr:
            if oldTitleStr != newTitleStr:
                elemIds = []
                for elemTitle in string_to_list(newTitleStr):
                    for elemId in elements:
                        if elements[elemId].title == elemTitle:
                            elemIds.append(elemId)
                            break
                    else:
                        self._ui.show_error(f'{_("Wrong name")}: "{elemTitle}"', title=_('Input rejected'))
                return elemIds

        return None

    def _go_to_arc(self, event=None):
        try:
            selection = self._plotlineCollection.cListbox.curselection()[0]
        except:
            return

        self._ui.tv.go_to_node(self._element.scPlotLines[selection])

    def _on_select_plotline(self, selection):
        self._save_plot_notes()
        self._selectedPlotline = self._element.scPlotLines[selection]
        self._plotNotesWindow.config(state='normal')
        if self._element.plotlineNotes:
            self._plotNotesWindow.set_text(self._element.plotlineNotes.get(self._selectedPlotline, ''))
        else:
            self._plotNotesWindow.clear()
        self._plotNotesWindow.config(bg='white')

    def _pick_plotline(self, event=None):
        self._start_picking_mode(command=self._add_plotline)
        self._ui.tv.see_node(PL_ROOT)

    def _remove_plotline(self, event=None):
        try:
            selection = self._plotlineCollection.cListbox.curselection()[0]
        except:
            return

        plId = self._element.scPlotLines[selection]
        title = self._mdl.novel.plotLines[plId].title
        if not self._ui.ask_yes_no(f'{_("Remove plot line")}: "{title}"?'):
            return

        arcList = self._element.scPlotLines
        del arcList[selection]
        self._element.scPlotLines = arcList

        arcSections = self._mdl.novel.plotLines[plId].sections
        if self._elementId in arcSections:
            arcSections.remove(self._elementId)
            self._mdl.novel.plotLines[plId].sections = arcSections

            for ppId in list(self._element.scPlotPoints):
                if self._element.scPlotPoints[ppId] == plId:
                    del(self._element.scPlotPoints[ppId])
                    self._mdl.novel.plotPoints[ppId].sectionAssoc = None

    def _save_plot_notes(self):
        if self._selectedPlotline and self._plotNotesWindow.hasChanged:
            plotlineNotes = self._element.plotlineNotes
            if plotlineNotes is None:
                plotlineNotes = {}
            plotlineNotes[self._selectedPlotline] = self._plotNotesWindow.get_text()
            self.doNotUpdate = True
            self._element.plotlineNotes = plotlineNotes
            self.doNotUpdate = False

    def _set_action_scene(self, event=None):
        self._goalLabel.config(text=_('Goal'))
        self._conflictLabel.config(text=_('Conflict'))
        self._outcomeLabel.config(text=_('Outcome'))
        self._element.scene = self._scene.get()

    def _set_custom_scene(self, event=None):
        if self._customGoal:
            self._goalLabel.config(text=self._customGoal)
        else:
            self._goalLabel.config(text=_('Opening'))

        if self._customConflict:
            self._conflictLabel.config(text=self._customConflict)
        else:
            self._conflictLabel.config(text=_('Peak emotional moment'))

        if self._customOutcome:
            self._outcomeLabel.config(text=self._customOutcome)
        else:
            self._outcomeLabel.config(text=_('Ending'))

        self._element.scene = self._scene.get()

    def _set_not_applicable(self, event=None):
        if self._customPlotProgress:
            self._goalLabel.config(text=self._customPlotProgress)
        else:
            self._goalLabel.config(text=_('Plot progress'))

        if self._customCharacterization:
            self._conflictLabel.config(text=self._customCharacterization)
        else:
            self._conflictLabel.config(text=_('Characterization'))

        if self._customWorldBuilding:
            self._outcomeLabel.config(text=self._customWorldBuilding)
        else:
            self._outcomeLabel.config(text=_('World building'))

        self._element.scene = self._scene.get()

    def _set_reaction_scene(self, event=None):
        self._goalLabel.config(text=_('Reaction'))
        self._conflictLabel.config(text=_('Dilemma'))
        self._outcomeLabel.config(text=_('Choice'))
        self._element.scene = self._scene.get()

    def _toggle_plot_frame(self, event=None):
        if prefs['show_plot']:
            self._plotFrame.hide()
            prefs['show_plot'] = False
        else:
            self._plotFrame.show()
            prefs['show_plot'] = True

    def _toggle_scene_frame(self, event=None):
        if prefs['show_scene']:
            self._sceneFrame.hide()
            prefs['show_scene'] = False
        else:
            self._sceneFrame.show()
            prefs['show_scene'] = True



class ItemView(WorldElementView):

    def __init__(self, parent, model, view, controller):
        super().__init__(parent, model, view, controller)
        self._prefsShowLinks = 'show_it_links'

    def set_data(self, elementId):
        self._element = self._mdl.novel.items[elementId]
        super().set_data(elementId)


class LocationView(WorldElementView):

    def __init__(self, parent, model, view, controller):
        super().__init__(parent, model, view, controller)
        self._prefsShowLinks = 'show_lc_links'

    def set_data(self, elementId):
        self._element = self._mdl.novel.locations[elementId]
        super().set_data(elementId)


class NoView(BasicView):

    def focus_title(self):
        pass

    def set_data(self, elementId):
        super().set_data(elementId)

    def _create_frames(self):
        pass
from tkinter import ttk



class PlotLineView(BasicView):

    def __init__(self, parent, model, view, controller):
        super().__init__(parent, model, view, controller)
        inputWidgets = []

        self._lastSelected = ''

        self._shortName = MyStringVar()
        self._shortNameEntry = LabelEntry(
            self._elementInfoWindow,
            text=_('Short name'),
            textvariable=self._shortName,
            command=self.apply_changes,
            lblWidth=22
            )
        self._shortNameEntry.pack(anchor='w')
        inputWidgets.append(self._shortNameEntry)

        self._plotFrame = ttk.Frame(self._elementInfoWindow)
        self._plotFrame.pack(fill='x')
        self._nrSections = ttk.Label(self._plotFrame)
        self._nrSections.pack(side='left')
        self._clearButton = ttk.Button(self._plotFrame, text=_('Clear section assignments'), command=self._remove_sections)
        self._clearButton.pack(padx=1, pady=2)
        inputWidgets.append(self._clearButton)

        for widget in inputWidgets:
            widget.bind('<FocusOut>', self.apply_changes)
            self._inputWidgets.append(widget)

        self._prefsShowLinks = 'show_pl_links'

    def apply_changes(self, event=None):
        super().apply_changes()

        self._element.shortName = self._shortName.get()

    def set_data(self, elementId):
        self._element = self._mdl.novel.plotLines[elementId]
        super().set_data(elementId)

        self._shortName.set(self._element.shortName)

        if self._element.sections is not None:
            self._nrSections['text'] = f'{_("Number of sections")}: {len(self._element.sections)}'

    def _create_frames(self):
        self._create_index_card()
        self._create_element_info_window()
        self._create_links_window()
        self._add_separator()
        self._create_notes_window()
        self._create_button_bar()

    def _remove_sections(self):
        if self._ui.ask_yes_no(f'{_("Remove all sections from the plot line")} "{self._element.shortName}"?'):
            if self._element.sections:
                self.doNotUpdate = True
                for scId in self._element.sections:
                    self._mdl.novel.sections[scId].scPlotLines.remove(self._elementId)
                for ppId in self._mdl.novel.tree.get_children(self._elementId):
                    scId = self._mdl.novel.plotPoints[ppId].sectionAssoc
                    if scId is not None:
                        del(self._mdl.novel.sections[scId].scPlotPoints[ppId])
                        self._mdl.novel.plotPoints[ppId].sectionAssoc = None
                self._element.sections = []
                self.set_data(self._elementId)
                self.doNotUpdate = False

from tkinter import ttk



class TurningPointView(BasicView):

    def __init__(self, parent, model, view, controller):
        super().__init__(parent, model, view, controller)
        inputWidgets = []

        self._lastSelected = ''
        self._treeSelectBinding = None
        self._uiEscBinding = None

        ttk.Separator(self._elementInfoWindow, orient='horizontal').pack(fill='x')

        self._sectionFrame = ttk.Frame(self._elementInfoWindow)
        self._sectionFrame.pack(anchor='w', fill='x')
        ttk.Label(self._sectionFrame, text=f"{_('Section')}:").pack(anchor='w')
        self.sectionAssocTitle = tk.Label(self._sectionFrame, anchor='w', bg='white')
        self.sectionAssocTitle.pack(anchor='w', pady=2, fill='x')

        self._assignSectionButton = ttk.Button(self._sectionFrame, text=_('Assign section'), command=self._pick_section)
        self._assignSectionButton.pack(side='left', fill='x', expand=True)
        inputWidgets.append(self._assignSectionButton)

        self._clearAssignmentButton = ttk.Button(self._sectionFrame, text=_('Clear assignment'), command=self._clear_assignment)
        self._clearAssignmentButton.pack(side='left', fill='x', expand=True)
        inputWidgets.append(self._clearAssignmentButton)

        ttk.Button(self._sectionFrame, text=_('Go to section'), command=self._select_assigned_section).pack(side='left', fill='x', expand=True)

        for widget in inputWidgets:
            self._inputWidgets.append(widget)

        self._prefsShowLinks = 'show_pp_links'

    def set_data(self, elementId):
        self._element = self._mdl.novel.plotPoints[elementId]
        super().set_data(elementId)

        try:
            sectionTitle = self._mdl.novel.sections[self._element.sectionAssoc].title
        except:
            sectionTitle = ''
        self.sectionAssocTitle['text'] = sectionTitle

    def _assign_section(self, event=None):
        nodeId = self._ui.tv.tree.selection()[0]
        if nodeId.startswith(SECTION_PREFIX):
            if self._mdl.novel.sections[nodeId].scType == 0:
                self._clear_assignment()
                plId = self._ui.tv.tree.parent(self._elementId)
                arcSections = self._mdl.novel.plotLines[plId].sections
                if arcSections is None:
                    arcSections = [nodeId]
                elif not nodeId in arcSections:
                    arcSections.append(nodeId)
                self._mdl.novel.plotLines[plId].sections = arcSections
                self._mdl.novel.sections[nodeId].scPlotPoints[self._elementId] = plId
                if not plId in self._mdl.novel.sections[nodeId].scPlotLines:
                    self._mdl.novel.sections[nodeId].scPlotLines.append(plId)
                self._element.sectionAssoc = nodeId

    def _clear_assignment(self):
        scId = self._element.sectionAssoc
        if scId is not None:
            del(self._mdl.novel.sections[scId].scPlotPoints[self._elementId])
            self._element.sectionAssoc = None

    def _create_frames(self):
        self._create_index_card()
        self._create_element_info_window()
        self._create_links_window()
        self._add_separator()
        self._create_notes_window()
        self._create_button_bar()

    def _select_assigned_section(self):
        if self._element.sectionAssoc is not None:
            targetNode = self._element.sectionAssoc
            self._ui.tv.see_node(targetNode)
            self._ui.tv.tree.selection_set(targetNode)

    def _pick_section(self):
        self._start_picking_mode(command=self._assign_section)
        self._ui.tv.see_node(CH_ROOT)



class ProjectNoteView(BasicView):

    def __init__(self, parent, model, view, controller):
        super().__init__(parent, model, view, controller)
        self._prefsShowLinks = 'show_pn_links'

    def set_data(self, elementId):
        self._element = self._mdl.novel.projectNotes[elementId]
        super().set_data(elementId)

    def _create_frames(self):
        self._create_index_card()
        self._create_element_info_window()
        self._create_links_window()
        self._add_separator()
        self._create_button_bar()
from datetime import date
from tkinter import ttk

from tkinter import ttk


class LabelDisp(ttk.Frame):

    def __init__(self, parent, text, textvariable, lblWidth=10):
        super().__init__(parent)
        self.pack(fill='x')
        self._leftLabel = ttk.Label(self, text=text, anchor='w', width=lblWidth)
        self._leftLabel.pack(side='left')
        self._rightLabel = ttk.Label(self, textvariable=textvariable, anchor='w')
        self._rightLabel.pack(side='left', fill='x', expand=True)

    def config(self, **kwargs):
        self.configure(**kwargs)

    def configure(self, text=None):
        if text is not None:
            self._leftLabel['text'] = text


class ProjectView(BasicView):

    def __init__(self, parent, model, view, controller):
        super().__init__(parent, model, view, controller)
        inputWidgets = []

        self._authorName = MyStringVar()
        self._authorNameEntry = LabelEntry(
            self._elementInfoWindow,
            text=_('Author'),
            textvariable=self._authorName,
            command=self.apply_changes,
            lblWidth=20
            )
        self._authorNameEntry.pack(anchor='w')
        inputWidgets.append(self._authorNameEntry)

        ttk.Separator(self._elementInfoWindow, orient='horizontal').pack(fill='x')

        self._numberingFrame = FoldingFrame(self._elementInfoWindow, _('Auto numbering'), self._toggle_numbering_frame)

        ttk.Separator(self._elementInfoWindow, orient='horizontal').pack(fill='x')

        self._renumberChapters = tk.BooleanVar(value=False)
        self._renumberChaptersCheckbox = ttk.Checkbutton(
            self._numberingFrame,
            text=_('Auto number chapters when refreshing the tree'),
            variable=self._renumberChapters,
            onvalue=True,
            offvalue=False,
            command=self.apply_changes,
            )
        self._renumberChaptersCheckbox.pack(anchor='w')
        inputWidgets.append(self._renumberChaptersCheckbox)

        self._chapterHeadingPrefix = MyStringVar()
        self._chapterHeadingPrefixEntry = LabelEntry(
            self._numberingFrame,
            text=_('Chapter number prefix'),
            textvariable=self._chapterHeadingPrefix,
            command=self.apply_changes,
            lblWidth=20
            )
        self._chapterHeadingPrefixEntry.pack(anchor='w')
        inputWidgets.append(self._chapterHeadingPrefixEntry)

        self._chapterHeadingSuffix = MyStringVar()
        self._chapterHeadingSuffixEntry = LabelEntry(
            self._numberingFrame,
            text=_('Chapter number suffix'),
            textvariable=self._chapterHeadingSuffix,
            command=self.apply_changes,
            lblWidth=20
            )
        self._chapterHeadingSuffixEntry.pack(anchor='w')
        inputWidgets.append(self._chapterHeadingSuffixEntry)

        self._romanChapterNumbers = tk.BooleanVar()
        self._romanChapterNumbersCheckbox = ttk.Checkbutton(
            self._numberingFrame,
            text=_('Use Roman chapter numbers'),
            variable=self._romanChapterNumbers,
            onvalue=True,
            offvalue=False,
            command=self.apply_changes,
            )
        self._romanChapterNumbersCheckbox.pack(anchor='w')
        inputWidgets.append(self._romanChapterNumbersCheckbox)

        self._renumberWithinParts = tk.BooleanVar()
        self._renumberWithinPartsCheckbox = ttk.Checkbutton(
            self._numberingFrame,
            text=_('Restart chapter numbering at part beginning'),
            variable=self._renumberWithinParts,
            onvalue=True,
            offvalue=False,
            command=self.apply_changes,
            )
        self._renumberWithinPartsCheckbox.pack(anchor='w')
        inputWidgets.append(self._renumberWithinPartsCheckbox)

        self._renumberParts = tk.BooleanVar()
        self._renumberPartsCheckbox = ttk.Checkbutton(
            self._numberingFrame,
            text=_('Auto number parts when refreshing the tree'),
            variable=self._renumberParts,
            onvalue=True,
            offvalue=False,
            command=self.apply_changes,
            )
        self._renumberPartsCheckbox.pack(anchor='w')
        inputWidgets.append(self._renumberPartsCheckbox)

        self._partHeadingPrefix = MyStringVar()
        self._partHeadingPrefixEntry = LabelEntry(
            self._numberingFrame,
            text=_('Part number prefix'),
            textvariable=self._partHeadingPrefix,
            command=self.apply_changes,
            lblWidth=20
            )
        self._partHeadingPrefixEntry.pack(anchor='w')
        inputWidgets.append(self._partHeadingPrefixEntry)

        self._partHeadingSuffix = MyStringVar()
        self._partHeadingSuffixEntry = LabelEntry(
            self._numberingFrame,
            text=_('Part number suffix'),
            textvariable=self._partHeadingSuffix,
            command=self.apply_changes,
            lblWidth=20
            )
        self._partHeadingSuffixEntry.pack(anchor='w')
        inputWidgets.append(self._partHeadingSuffixEntry)

        self._romanPartNumbers = tk.BooleanVar()
        self._romanPartNumbersCheckbox = ttk.Checkbutton(
            self._numberingFrame,
            text=_('Use Roman part numbers'),
            variable=self._romanPartNumbers,
            onvalue=True,
            offvalue=False,
            command=self.apply_changes,
            )
        self._romanPartNumbersCheckbox.pack(anchor='w')
        inputWidgets.append(self._romanPartNumbersCheckbox)

        self._renamingsFrame = FoldingFrame(self._elementInfoWindow, _('Renamings'), self._toggle_renamings_frame)

        ttk.Separator(self._elementInfoWindow, orient='horizontal').pack(fill='x')
        ttk.Label(self._renamingsFrame, text=_('Not a scene')).pack(anchor='w')

        self._customPlotProgress = MyStringVar()
        self._customPlotProgressEntry = LabelEntry(
            self._renamingsFrame,
            text=_('Plot progress'),
            textvariable=self._customPlotProgress,
            command=self.apply_changes,
            lblWidth=20
            )
        self._customPlotProgressEntry.pack(anchor='w')
        inputWidgets.append(self._customPlotProgressEntry)

        self._customCharacterization = MyStringVar()
        self._customCharacterizationEntry = LabelEntry(
            self._renamingsFrame,
            text=_('Characterization'),
            textvariable=self._customCharacterization,
            command=self.apply_changes,
            lblWidth=20
            )
        self._customCharacterizationEntry.pack(anchor='w')
        inputWidgets.append(self._customCharacterizationEntry)

        self._customWorldBuilding = MyStringVar()
        self.__customWorldBuildingEntry = LabelEntry(
            self._renamingsFrame,
            text=_('World building'),
            textvariable=self._customWorldBuilding,
            command=self.apply_changes,
            lblWidth=20
            )
        self.__customWorldBuildingEntry.pack(anchor='w')
        inputWidgets.append(self.__customWorldBuildingEntry)

        ttk.Separator(self._renamingsFrame, orient='horizontal').pack(fill='x', pady=5)
        ttk.Label(self._renamingsFrame, text=_('Other scene')).pack(anchor='w')

        self._customGoal = MyStringVar()
        self._customGoalEntry = LabelEntry(
            self._renamingsFrame,
            text=_('Opening'),
            textvariable=self._customGoal,
            command=self.apply_changes,
            lblWidth=20
            )
        self._customGoalEntry.pack(anchor='w')
        inputWidgets.append(self._customGoalEntry)

        self._customConflict = MyStringVar()
        self._customConflictEntry = LabelEntry(
            self._renamingsFrame,
            text=_('Peak em. moment'),
            textvariable=self._customConflict,
            command=self.apply_changes,
            lblWidth=20
            )
        self._customConflictEntry.pack(anchor='w')
        inputWidgets.append(self._customConflictEntry)

        self._customOutcome = MyStringVar()
        self._customOutcomeEntry = LabelEntry(
            self._renamingsFrame,
            text=_('Ending'),
            textvariable=self._customOutcome,
            command=self.apply_changes,
            lblWidth=20
            )
        self._customOutcomeEntry.pack(anchor='w')
        inputWidgets.append(self._customOutcomeEntry)

        ttk.Separator(self._renamingsFrame, orient='horizontal').pack(fill='x', pady=5)
        ttk.Label(self._renamingsFrame, text=_('Character')).pack(anchor='w')

        self._customChrBio = MyStringVar()
        self._customChrBioEntry = LabelEntry(
            self._renamingsFrame,
            text=_('Bio'),
            textvariable=self._customChrBio,
            command=self.apply_changes,
            lblWidth=20
            )
        self._customChrBioEntry.pack(anchor='w')
        inputWidgets.append(self._customChrBioEntry)

        self._customChrGoals = MyStringVar()
        self._customChrGoalsEntry = LabelEntry(
            self._renamingsFrame,
            text=_('Goals'),
            textvariable=self._customChrGoals,
            command=self.apply_changes,
            lblWidth=20
            )
        self._customChrGoalsEntry.pack(anchor='w')
        inputWidgets.append(self._customChrGoalsEntry)

        self._narrativeTimeFrame = FoldingFrame(self._elementInfoWindow, _('Narrative time'), self._toggle_narrative_time_frame)

        ttk.Separator(self._elementInfoWindow, orient='horizontal').pack(fill='x')

        self._referenceDate = MyStringVar()
        self._referenceDateEntry = LabelEntry(
            self._narrativeTimeFrame,
            text=_('Reference date'),
            textvariable=self._referenceDate,
            command=self.apply_changes,
            lblWidth=20
            )
        self._referenceDateEntry.pack(anchor='w')
        inputWidgets.append(self._referenceDateEntry)

        localeDateFrame = ttk.Frame(self._narrativeTimeFrame)
        localeDateFrame.pack(fill='x')
        ttk.Label(localeDateFrame, width=20).pack(side='left')
        self._referenceWeekDay = MyStringVar()
        ttk.Label(localeDateFrame, textvariable=self._referenceWeekDay).pack(side='left')
        self._localeDate = MyStringVar()
        ttk.Label(localeDateFrame, textvariable=self._localeDate).pack(anchor='w')

        self._datesToDaysButton = ttk.Button(self._narrativeTimeFrame, text=_('Convert dates to days'), command=self._dates_to_days)
        self._datesToDaysButton.pack(side='left', fill='x', expand=True, padx=1, pady=2)
        inputWidgets.append(self._datesToDaysButton)

        self._daysToDatesButton = ttk.Button(self._narrativeTimeFrame, text=_('Convert days to dates'), command=self._days_to_dates)
        self._daysToDatesButton.pack(side='left', fill='x', expand=True, padx=1, pady=2)
        inputWidgets.append(self._daysToDatesButton)

        self._progressFrame = FoldingFrame(self._elementInfoWindow, _('Writing progress'), self._toggle_progress_frame)

        self._saveWordCount = tk.BooleanVar()
        self._saveWordCountEntry = ttk.Checkbutton(
            self._progressFrame,
            text=_('Log writing progress'),
            variable=self._saveWordCount,
            onvalue=True,
            offvalue=False,
            command=self.apply_changes,
            )
        self._saveWordCountEntry.pack(anchor='w')
        inputWidgets.append(self._saveWordCountEntry)

        ttk.Separator(self._progressFrame, orient='horizontal').pack(fill='x')

        self._wordTarget = tk.IntVar()
        self._wordTargetEntry = LabelEntry(
            self._progressFrame,
            text=_('Words to write'),
            textvariable=self._wordTarget,
            command=self.apply_changes,
            lblWidth=20
            )
        self._wordTargetEntry.pack(anchor='w')
        inputWidgets.append(self._wordTargetEntry)

        self._wordCountStart = tk.IntVar()
        self._wordCountStartEntry = LabelEntry(
            self._progressFrame,
            text=_('Starting count'),
            textvariable=self._wordCountStart,
            command=self.apply_changes,
            lblWidth=20
            )
        self._wordCountStartEntry.pack(anchor='w')
        inputWidgets.append(self._wordCountStartEntry)

        self._setInitialWcButton = ttk.Button(self._progressFrame, text=_('Set actual wordcount as start'), command=self._set_initial_wc)
        self._setInitialWcButton.pack(pady=2)
        inputWidgets.append(self._setInitialWcButton)

        self._wordsWritten = MyStringVar()
        self._wordTarget.trace_add('write', self._update_words_written)
        self._wordCountStart.trace_add('write', self._update_words_written)
        LabelDisp(self._progressFrame, text=_('Words written'),
                  textvariable=self._wordsWritten, lblWidth=20).pack(anchor='w')

        ttk.Separator(self._progressFrame, orient='horizontal').pack(fill='x')

        self._totalUsed = MyStringVar()
        LabelDisp(self._progressFrame, text=_('Used'), textvariable=self._totalUsed, lblWidth=20).pack(anchor='w')
        self._totalOutline = MyStringVar()
        LabelDisp(self._progressFrame, text=_('Outline'), textvariable=self._totalOutline, lblWidth=20).pack(anchor='w')
        self._totalDraft = MyStringVar()
        LabelDisp(self._progressFrame, text=_('Draft'), textvariable=self._totalDraft, lblWidth=20).pack(anchor='w')
        self._total1stEdit = MyStringVar()
        LabelDisp(self._progressFrame, text=_('1st Edit'), textvariable=self._total1stEdit, lblWidth=20).pack(anchor='w')
        self._total2ndEdit = MyStringVar()
        LabelDisp(self._progressFrame, text=_('2nd Edit'), textvariable=self._total2ndEdit, lblWidth=20).pack(anchor='w')
        self._totalDone = MyStringVar()
        LabelDisp(self._progressFrame, text=_('Done'), textvariable=self._totalDone, lblWidth=20).pack(anchor='w')
        self._totalUnused = MyStringVar()
        LabelDisp(self._progressFrame, text=_('Unused'), textvariable=self._totalUnused, lblWidth=20).pack(anchor='w')
        self._totalWords = MyStringVar()
        LabelDisp(self._progressFrame, text=_('All'), textvariable=self._totalWords, lblWidth=20).pack(anchor='w')

        self._phase = MyStringVar()
        self._phaseCombobox = LabelCombo(self._progressFrame, lblWidth=20, text=_('Work phase'), textvariable=self._phase, values=[])
        self._phaseCombobox.pack(anchor='w')
        inputWidgets.append(self._phaseCombobox)
        self._phaseCombobox.bind('<Return>', self.apply_changes)

        self._coverFile = None

        for widget in inputWidgets:
            widget.bind('<FocusOut>', self.apply_changes)
            self._inputWidgets.append(widget)

        self._prefsShowLinks = 'show_pr_links'

    def apply_changes(self, event=None):
        super().apply_changes()

        authorName = self._authorName.get()
        if authorName:
            authorName = authorName.strip()
        self._element.authorName = authorName

        self._element.renumberChapters = self._renumberChapters.get()
        self._element.renumberParts = self._renumberParts.get()
        self._element.renumberWithinParts = self._renumberWithinParts.get()
        self._element.romanChapterNumbers = self._romanChapterNumbers.get()
        self._element.romanPartNumbers = self._romanPartNumbers.get()
        self._element.saveWordCount = self._saveWordCount.get()

        self._element.chapterHeadingPrefix = self._chapterHeadingPrefix.get()
        self._element.chapterHeadingSuffix = self._chapterHeadingSuffix.get()
        self._element.partHeadingPrefix = self._partHeadingPrefix.get()
        self._element.partHeadingSuffix = self._partHeadingSuffix.get()
        self._element.customPlotProgress = self._customPlotProgress.get()
        self._element.customCharacterization = self._customCharacterization.get()
        self._element.customWorldBuilding = self._customWorldBuilding.get()
        self._element.customGoal = self._customGoal.get()
        self._element.customConflict = self._customConflict.get()
        self._element.customOutcome = self._customOutcome.get()
        self._element.customChrBio = self._customChrBio.get()
        self._element.customChrGoals = self._customChrGoals.get()

        refDateStr = self._referenceDate.get()
        if not refDateStr:
            self._element.referenceDate = None
            self._referenceWeekDay.set('')
            self._localeDate.set('')
        elif refDateStr != self._element.referenceDate:
            try:
                date.fromisoformat(refDateStr)
            except ValueError:
                self._referenceDate.set(self._element.referenceDate)
                self._ui.show_error(
                    f'{_("Wrong date")}: "{refDateStr}"\n{_("Required")}: {_("YYYY-MM-DD")}',
                    title=_('Input rejected')
                    )
            else:
                self._element.referenceDate = refDateStr
                if self._element.referenceWeekDay is not None:
                    self._referenceWeekDay.set(WEEKDAYS[self._element.referenceWeekDay])
                else:
                    self._referenceWeekDay.set('')
                    self._localeDate.set('')

        try:
            entry = self._wordTarget.get()
            if self._element.wordTarget or entry:
                if self._element.wordTarget != entry:
                    self._element.wordTarget = entry
        except:
            pass
        try:
            entry = self._wordCountStart.get()
            if self._element.wordCountStart or entry:
                if self._element.wordCountStart != entry:
                    self._element.wordCountStart = entry
        except:
            pass

        if not self._phaseCombobox.current():
            entry = None
        else:
            entry = self._phaseCombobox.current()
        self._element.workPhase = entry

    def set_data(self, elementId):
        self._element = self._mdl.novel
        super().set_data(elementId)

        self._authorName.set(self._element.authorName)

        if prefs['show_auto_numbering']:
            self._numberingFrame.show()
        else:
            self._numberingFrame.hide()

        if self._element.renumberChapters:
            self._renumberChapters.set(True)
        else:
            self._renumberChapters.set(False)

        self._chapterHeadingPrefix.set(self._element.chapterHeadingPrefix)

        self._chapterHeadingSuffix = MyStringVar(value=self._element.chapterHeadingSuffix)

        if self._element.romanChapterNumbers:
            self._romanChapterNumbers.set(True)
        else:
            self._romanChapterNumbers.set(False)

        if self._element.renumberWithinParts:
            self._renumberWithinParts.set(True)
        else:
            self._renumberWithinParts.set(False)

        if self._element.renumberParts:
            self._renumberParts.set(True)
        else:
            self._renumberParts.set(False)

        self._partHeadingPrefix.set(self._element.partHeadingPrefix)

        self._partHeadingSuffix.set(self._element.partHeadingSuffix)

        if self._element.romanPartNumbers:
            self._romanPartNumbers.set(True)
        else:
            self._romanPartNumbers.set(False)

        if prefs['show_renamings']:
            self._renamingsFrame.show()
        else:
            self._renamingsFrame.hide()

        self._customPlotProgress.set(self._element.customPlotProgress)
        self._customCharacterization.set(self._element.customCharacterization)
        self._customWorldBuilding.set(self._element.customWorldBuilding)
        self._customGoal.set(self._element.customGoal)
        self._customConflict.set(self._element.customConflict)
        self._customOutcome.set(self._element.customOutcome)
        self._customChrBio.set(self._element.customChrBio)
        self._customChrGoals.set(self._element.customChrGoals)

        if prefs['show_narrative_time']:
            self._narrativeTimeFrame.show()
        else:
            self._narrativeTimeFrame.hide()

        if self._element.referenceDate and self._element.referenceWeekDay is not None:
            self._referenceWeekDay.set(
                WEEKDAYS[self._element.referenceWeekDay]
                )
            self._localeDate.set(
                datestr(self._element.referenceDate)
                )
        else:
            self._referenceWeekDay.set('')
            self._localeDate.set('')
        self._referenceDate.set(self._element.referenceDate)

        if prefs['show_writing_progress']:
            self._progressFrame.show()
        else:
            self._progressFrame.hide()

        if self._element.saveWordCount:
            self._saveWordCount.set(True)
        else:
            self._saveWordCount.set(False)

        if self._element.wordTarget is not None:
            self._wordTarget.set(self._element.wordTarget)
        else:
            self._wordTarget.set(0)

        if self._element.wordCountStart is not None:
            self._wordCountStart.set(self._element.wordCountStart)
        else:
            self._wordCountStart.set(0)

        normalWordsTotal, allWordsTotal = self._mdl.prjFile.count_words()
        self._totalWords.set(allWordsTotal)
        self._totalUsed.set(normalWordsTotal)
        self._totalUnused.set(allWordsTotal - normalWordsTotal)
        statusCounts = self._mdl.get_status_counts()
        self._totalOutline.set(statusCounts[1])
        self._totalDraft.set(statusCounts[2])
        self._total1stEdit.set(statusCounts[3])
        self._total2ndEdit.set(statusCounts[4])
        self._totalDone.set(statusCounts[5])

        phases = [_('Undefined'), _('Outline'), _('Draft'), _('1st Edit'), _('2nd Edit'), _('Done')]
        self._phaseCombobox.configure(values=phases)
        try:
            workPhase = int(self._element.workPhase)
        except:
            workPhase = 0
        self._phase.set(value=phases[workPhase])

    def show(self):
        try:
            coverFile = f'{os.path.splitext(self._mdl.prjFile.filePath)[0]}.png'
            if self._coverFile != coverFile:
                self._coverFile = coverFile
                coverPic = tk.PhotoImage(file=coverFile)
                self._cover.configure(image=coverPic)
                self._cover.image = coverPic
        except:
            self._coverFile = None
            self._cover.configure(image=None)
            self._cover.image = None
        super().show()

    def _set_initial_wc(self):
        self._wordCountStart.set(self._mdl.wordCount)

    def _create_cover_window(self):
        self._cover = tk.Label(self._propertiesFrame)
        self._cover.pack()

    def _create_frames(self):
        self._create_index_card()
        self._create_element_info_window()
        self._create_links_window()
        self._add_separator()
        self._create_cover_window()

    def _dates_to_days(self):
        buttonText = self._datesToDaysButton['text']
        self._datesToDaysButton['text'] = _('Please wait ...')
        if self._mdl.novel.referenceDate:
            if self._ui.ask_yes_no(_('Convert all section dates to days relative to the reference date?')):
                self.doNotUpdate = True
                for scId in self._mdl.novel.sections:
                    self._mdl.novel.sections[scId].date_to_day(self._mdl.novel.referenceDate)
                self.doNotUpdate = False
        else:
            self._show_missing_reference_date_message()
        self._datesToDaysButton['text'] = buttonText

    def _days_to_dates(self):
        buttonText = self._daysToDatesButton['text']
        self._daysToDatesButton['text'] = _('Please wait ...')
        if self._mdl.novel.referenceDate:
            if self._ui.ask_yes_no(_('Convert all section days to dates using the reference date?')):
                self.doNotUpdate = True
                for scId in self._mdl.novel.sections:
                    self._mdl.novel.sections[scId].day_to_date(self._mdl.novel.referenceDate)
                self.doNotUpdate = False
        else:
            self._show_missing_reference_date_message()
        self._daysToDatesButton['text'] = buttonText

    def _toggle_numbering_frame(self, event=None):
        if prefs['show_auto_numbering']:
            self._numberingFrame.hide()
            prefs['show_auto_numbering'] = False
        else:
            self._numberingFrame.show()
            prefs['show_auto_numbering'] = True

    def _toggle_narrative_time_frame(self, event=None):
        if prefs['show_narrative_time']:
            self._narrativeTimeFrame.hide()
            prefs['show_narrative_time'] = False
        else:
            self._narrativeTimeFrame.show()
            prefs['show_narrative_time'] = True

    def _toggle_progress_frame(self, event=None):
        if prefs['show_writing_progress']:
            self._progressFrame.hide()
            prefs['show_writing_progress'] = False
        else:
            self._progressFrame.show()
            prefs['show_writing_progress'] = True

    def _toggle_renamings_frame(self, event=None):
        if prefs['show_renamings']:
            self._renamingsFrame.hide()
            prefs['show_renamings'] = False
        else:
            self._renamingsFrame.show()
            prefs['show_renamings'] = True

    def _update_words_written(self, n, m, x):
        try:
            ww = self._mdl.wordCount - self._wordCountStart.get()
            wt = self._wordTarget.get()
            try:
                wp = f'({round(100*ww/wt)}%)'
            except ZeroDivisionError:
                wp = ''
            self._wordsWritten.set(f'{ww} {wp}')
        except:
            pass



class StageView(BasicView):

    def __init__(self, parent, model, view, controller):
        super().__init__(parent, model, view, controller)
        self._prefsShowLinks = 'show_st_links'

    def set_data(self, elementId):
        self._element = self._mdl.novel.sections[elementId]
        super().set_data(elementId)

    def _create_frames(self):
        self._create_index_card()
        self._create_element_info_window()
        self._create_links_window()
        self._add_separator()
        self._create_notes_window()
        self._create_button_bar()


class PropertiesViewer(ViewComponentNode, ttk.Frame):

    def __init__(self, parent, model, view, controller, **kw):
        ViewComponentNode.__init__(self, model, view, controller)
        ttk.Frame.__init__(self, parent, **kw)

        self._viewComponents = []

        self._noView = self._make_view(NoView)
        self._projectView = self._make_view(ProjectView)
        self._chapterView = self._make_view(ChapterView)
        self._stageView = self._make_view(StageView)
        self._sectionView = self._make_view(FullSectionView)
        self._characterView = self._make_view(CharacterView)
        self._locationView = self._make_view(LocationView)
        self._itemView = self._make_view(ItemView)
        self._plotlineView = self._make_view(PlotLineView)
        self._plotPointView = self._make_view(TurningPointView)
        self._projectnoteView = self._make_view(ProjectNoteView)

        self._activeView = self._noView
        self._activeView.set_data(None)
        self._activeView.doNotUpdate = False

    def apply_changes(self, event=None):
        self._activeView.doNotUpdate = True
        self._activeView.apply_changes()
        self._activeView.doNotUpdate = False

    def focus_title(self):
        self._activeView.focus_title()

    def show_properties(self, nodeId):
        if self._mdl is None:
            self._view_nothing()
        elif nodeId.startswith(SECTION_PREFIX):
            self._view_section(nodeId)
        elif nodeId == self._mdl.trashBin:
            self._view_nothing()
        elif nodeId.startswith(CHAPTER_PREFIX):
            self._view_chapter(nodeId)
        elif nodeId.startswith(CH_ROOT):
            self._view_project()
        elif nodeId.startswith(CHARACTER_PREFIX):
            self._view_character(nodeId)
        elif nodeId.startswith(LOCATION_PREFIX):
            self._view_location(nodeId)
        elif nodeId.startswith(ITEM_PREFIX):
            self._view_item(nodeId)
        elif nodeId.startswith(PLOT_LINE_PREFIX):
            self._view_arc(nodeId)
        elif nodeId.startswith(PLOT_POINT_PREFIX):
            self._view_plot_point(nodeId)
        elif nodeId.startswith(PRJ_NOTE_PREFIX):
            self._view_projectnote(nodeId)
        else:
            self._view_nothing()
        self._activeView.doNotUpdate = False

    def refresh(self):
        if not self._activeView.doNotUpdate:
            try:
                self.show_properties(self._activeView._elementId)
            except:
                pass

    def _make_view(self, viewClass):
        newView = viewClass(self, self._mdl, self._ui, self._ctrl)
        self._viewComponents.append(newView)
        return newView

    def _set_data(self, elemId):
        self._activeView.set_data(elemId)

    def _view_arc(self, plId):
        if not self._activeView is self._plotLineView:
            self._activeView.hide()
            self._activeView = self._plotLineView
            self._activeView.show()
        self._set_data(plId)

    def _view_chapter(self, chId):
        if not self._activeView is self._chapterView:
            self._activeView.hide()
            self._activeView = self._chapterView
            self._activeView.show()
        self._set_data(chId)

    def _view_character(self, crId):
        if not self._activeView is self._characterView:
            self._activeView.hide()
            self._activeView = self._characterView
            self._activeView.show()
        self._set_data(crId)

    def _view_item(self, itId):
        if not self._activeView is self._itemView:
            self._activeView.hide()
            self._activeView = self._itemView
            self._activeView.show()
        self._set_data(itId)

    def _view_location(self, lcId):
        if not self._activeView is self._locationView:
            self._activeView.hide()
            self._activeView = self._locationView
            self._activeView.show()
        self._set_data(lcId)

    def _view_nothing(self):
        if not self._activeView is self._noView:
            self._activeView.hide()
            self._activeView = self._noView
            self._activeView.show()

    def _view_project(self):
        if not self._activeView is self._projectView:
            self._activeView.hide()
            self._activeView = self._projectView
            self._activeView.show()
        self._set_data(CH_ROOT)

    def _view_projectnote(self, pnId):
        if not self._activeView is self._projectnoteView:
            self._activeView.hide()
            self._activeView = self._projectnoteView
            self._activeView.show()
        self._set_data(pnId)

    def _view_section(self, scId):
        if self._mdl.novel.sections[scId].scType > 1:
            if not self._activeView is self._stageView:
                self._activeView.hide()
                self._activeView = self._stageView
                self._activeView.show()
        else:
            if not self._activeView is self._sectionView:
                self._activeView.hide()
                self._activeView = self._sectionView
                self._activeView.show()
        self._set_data(scId)

    def _view_plot_point(self, ppId):
        if not self._activeView is self._plotPointView:
            self._activeView.hide()
            self._activeView = self._plotPointView
            self._activeView.show()
        self._set_data(ppId)

from tkinter import ttk



class Toolbar(ViewComponentBase, ttk.Frame):

    def __init__(self, parent, model, view, controller):
        ViewComponentBase.__init__(self, model, view, controller)
        ttk.Frame.__init__(self, parent)

        self.buttonBar = tk.Frame(self._ui.mainWindow)

        self._goBackButton = ttk.Button(
            self.buttonBar,
            text=_('Back'),
            image=self._ui.icons.goBackIcon,
            command=self._ui.tv.go_back
            )
        self._goBackButton.pack(side='left')
        self._goBackButton.image = self._ui.icons.goBackIcon

        self._goForwardButton = ttk.Button(
            self.buttonBar,
            text=_('Forward'),
            image=self._ui.icons.goForwardIcon,
            command=self._ui.tv.go_forward
            )
        self._goForwardButton.pack(side='left')
        self._goForwardButton.image = self._ui.icons.goForwardIcon

        tk.Frame(self.buttonBar, bg='light gray', width=1).pack(side='left', fill='y', padx=4)

        self._viewBookButton = ttk.Button(
            self.buttonBar,
            text=_('Book'),
            image=self._ui.icons.viewBookIcon,
            command=lambda: self._ui.tv.show_branch(CH_ROOT)
            )
        self._viewBookButton.pack(side='left')
        self._viewBookButton.image = self._ui.icons.viewBookIcon

        self._viewCharactersButton = ttk.Button(
            self.buttonBar,
            text=_('Characters'),
            image=self._ui.icons.viewCharactersIcon,
            command=lambda: self._ui.tv.show_branch(CR_ROOT)
            )
        self._viewCharactersButton.pack(side='left')
        self._viewCharactersButton.image = self._ui.icons.viewCharactersIcon

        self._viewLocationsButton = ttk.Button(
            self.buttonBar,
            text=_('Locations'),
            image=self._ui.icons.viewLocationsIcon,
            command=lambda: self._ui.tv.show_branch(LC_ROOT)
            )
        self._viewLocationsButton.pack(side='left')
        self._viewLocationsButton.image = self._ui.icons.viewLocationsIcon

        self._viewItemsButton = ttk.Button(
            self.buttonBar,
            text=_('Items'),
            image=self._ui.icons.viewItemsIcon,
            command=lambda: self._ui.tv.show_branch(IT_ROOT)
            )
        self._viewItemsButton.pack(side='left')
        self._viewItemsButton.image = self._ui.icons.viewItemsIcon

        self._viewPlotLinesButton = ttk.Button(
            self.buttonBar,
            text=_('Plot lines'),
            image=self._ui.icons.viewPlotLinesIcon,
            command=lambda: self._ui.tv.show_branch(PL_ROOT)
            )
        self._viewPlotLinesButton.pack(side='left')
        self._viewPlotLinesButton.image = self._ui.icons.viewPlotLinesIcon

        self._viewProjectnotesButton = ttk.Button(
            self.buttonBar,
            text=_('Project notes'),
            image=self._ui.icons.viewProjectnotesIcon,
            command=lambda: self._ui.tv.show_branch(PN_ROOT)
            )
        self._viewProjectnotesButton.pack(side='left')
        self._viewProjectnotesButton.image = self._ui.icons.viewProjectnotesIcon

        tk.Frame(self.buttonBar, bg='light gray', width=1).pack(side='left', fill='y', padx=4)

        self._saveButton = ttk.Button(
            self.buttonBar,
            text=_('Save'),
            image=self._ui.icons.saveIcon,
            command=self._ctrl.save_project
            )
        self._saveButton.pack(side='left')
        self._saveButton.image = self._ui.icons.saveIcon

        tk.Frame(self.buttonBar, bg='light gray', width=1).pack(side='left', fill='y', padx=4)

        self._addElementButton = ttk.Button(
            self.buttonBar,
            text=_('Add'),
            image=self._ui.icons.addIcon,
            command=self._ctrl.add_element
            )
        self._addElementButton.pack(side='left')
        self._addElementButton.image = self._ui.icons.addIcon

        self._addChildButton = ttk.Button(
            self.buttonBar,
            text=_('Add child'),
            image=self._ui.icons.addChildIcon,
            command=self._ctrl.add_child
            )
        self._addChildButton.pack(side='left')
        self._addChildButton.image = self._ui.icons.addChildIcon

        self._addParentButton = ttk.Button(
            self.buttonBar,
            text=_('Add parent'),
            image=self._ui.icons.addParentIcon,
            command=self._ctrl.add_parent
            )
        self._addParentButton.pack(side='left')
        self._addParentButton.image = self._ui.icons.addParentIcon

        self._deleteElementButton = ttk.Button(
            self.buttonBar,
            text=_('Delete'),
            image=self._ui.icons.removeIcon,
            command=self._ctrl.delete_elements
            )
        self._deleteElementButton.pack(side='left')
        self._deleteElementButton.image = self._ui.icons.removeIcon


        self._propertiesButton = ttk.Button(
            self.buttonBar,
            text=_('Toggle Properties'),
            image=self._ui.icons.propertiesIcon,
            command=self._ui.toggle_properties_view
            )
        self._propertiesButton.pack(side='right')
        self._propertiesButton.image = self._ui.icons.propertiesIcon

        self._viewerButton = ttk.Button(
            self.buttonBar,
            text=_('Toggle Text viewer'),
            image=self._ui.icons.viewerIcon,
            command=self._ui.toggle_contents_view
            )
        self._viewerButton.pack(side='right')
        self._viewerButton.image = self._ui.icons.viewerIcon

        self.buttonBar.pack(expand=False, before=self._ui.appWindow, fill='both')
        self._set_hovertips()

    def disable_menu(self):
        self._addChildButton.config(state='disabled')
        self._addElementButton.config(state='disabled')
        self._addParentButton.config(state='disabled')
        self._goBackButton.config(state='disabled')
        self._goForwardButton.config(state='disabled')
        self._deleteElementButton.config(state='disabled')
        self._saveButton.config(state='disabled')
        self._viewBookButton.config(state='disabled')
        self._viewCharactersButton.config(state='disabled')
        self._viewItemsButton.config(state='disabled')
        self._viewLocationsButton.config(state='disabled')
        self._viewPlotLinesButton.config(state='disabled')
        self._viewProjectnotesButton.config(state='disabled')

    def enable_menu(self):
        self._addChildButton.config(state='normal')
        self._addElementButton.config(state='normal')
        self._addParentButton.config(state='normal')
        self._goBackButton.config(state='normal')
        self._goForwardButton.config(state='normal')
        self._deleteElementButton.config(state='normal')
        self._saveButton.config(state='normal')
        self._viewBookButton.config(state='normal')
        self._viewCharactersButton.config(state='normal')
        self._viewItemsButton.config(state='normal')
        self._viewLocationsButton.config(state='normal')
        self._viewPlotLinesButton.config(state='normal')
        self._viewProjectnotesButton.config(state='normal')

    def _set_hovertips(self):
        if not prefs['enable_hovertips']:
            return

        Hovertip(self._addChildButton, f"{self._addChildButton['text']} ({KEYS.ADD_CHILD[1]})")
        Hovertip(self._addElementButton, f"{self._addElementButton['text']} ({KEYS.ADD_ELEMENT[1]})")
        Hovertip(self._addParentButton, f"{self._addParentButton['text']} ({KEYS.ADD_PARENT[1]})")
        Hovertip(self._goBackButton, self._goBackButton['text'])
        Hovertip(self._goForwardButton, self._goForwardButton['text'])
        Hovertip(self._propertiesButton, f"{self._propertiesButton['text']} ({KEYS.TOGGLE_PROPERTIES[1]})")
        Hovertip(self._saveButton, f"{self._saveButton['text']} ({KEYS.SAVE_PROJECT[1]})")
        Hovertip(self._deleteElementButton, f"{self._deleteElementButton['text']} ({KEYS.DELETE[1]})")
        Hovertip(self._viewBookButton, self._viewBookButton['text'])
        Hovertip(self._viewCharactersButton, self._viewCharactersButton['text'])
        Hovertip(self._viewItemsButton, self._viewItemsButton['text'])
        Hovertip(self._viewLocationsButton, self._viewLocationsButton['text'])
        Hovertip(self._viewPlotLinesButton, self._viewPlotLinesButton['text'])
        Hovertip(self._viewProjectnotesButton, self._viewProjectnotesButton['text'])
        Hovertip(self._viewerButton, f"{self._viewerButton['text']} ({KEYS.TOGGLE_VIEWER[1]})")

from tkinter import ttk



class HistoryList:

    def __init__(self):
        self._historyList = []
        self._pointer = None
        self._lock = False

    def append_node(self, node):
        if not self._lock:
            try:
                del self._historyList[self._pointer + 1:]
            except:
                pass
            if self._pointer is None or self._historyList[self._pointer] != node:
                self._historyList.append(node)
                self._pointer = len(self._historyList) - 1
        self._lock = False

    def go_back(self):
        if self._pointer is None:
            return None

        if self._pointer > 0:
            self._pointer -= 1
        return self._historyList[self._pointer]

    def go_forward(self):
        if self._pointer is None:
            return None

        if self._pointer + 1 < len(self._historyList):
            self._pointer += 1
        return self._historyList[self._pointer]

    def lock(self):
        self._lock = True

    def reset(self):
        self._historyList = []
        self._pointer = None
        self._lock = False



class ContextMenu(tk.Menu):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.bind('<FocusOut>', self._close)

    def _close(self, event):
        self.unpost()
import tkinter.font as tkFont


class TreeViewer(ViewComponentBase, ttk.Frame):
    COLORING_MODES = [_('None'), _('Status'), _('Work phase')]

    _COLUMNS = dict(
        wc=(_('Words'), 'wc_width'),
        vp=(_('Viewpoint'), 'vp_width'),
        st=(_('Status'), 'status_width'),
        nt=(_('N'), 'nt_width'),
        dt=(_('Date'), 'date_width'),
        tm=(_('Time'), 'time_width'),
        dr=(_('Duration'), 'duration_width'),
        tg=(_('Tags'), 'tags_width'),
        po=(_('Position'), 'ps_width'),
        ac=(_('Plot lines'), 'arcs_width'),
        sc=(_('Scene'), 'scene_width'),
        tp=(_('Plot points'), 'points_width'),
        )

    _ROOT_TITLES = {
        CH_ROOT: _('Book'),
        CR_ROOT: _('Characters'),
        LC_ROOT: _('Locations'),
        IT_ROOT: _('Items'),
        PL_ROOT: _('Plot lines'),
        PN_ROOT: _('Project notes'),
        }

    _SCENE = [
        '-',
        _('A'),
        _('R'),
        'x',
        ]

    _NOTE_INDICATOR = _('N')

    def __init__(self, parent, model, view, controller, **kw):
        ViewComponentBase.__init__(self, model, view, controller)
        ttk.Frame.__init__(self, parent, **kw)
        self._wordsTotal = None
        self.skipUpdate = False

        self.tree = NvTreeview(self)
        scrollX = ttk.Scrollbar(self, orient='horizontal', command=self.tree.xview)
        scrollY = ttk.Scrollbar(self.tree, orient='vertical', command=self.tree.yview)
        self.tree.configure(xscrollcommand=scrollX.set)
        self.tree.configure(yscrollcommand=scrollY.set)
        scrollX.pack(side='bottom', fill='x')
        scrollY.pack(side='right', fill='y')
        self.tree.pack(fill='both', expand=True)

        self.configure_columns()

        fontSize = tkFont.nametofont('TkDefaultFont').actual()['size']
        self.tree.tag_configure('root', font=('', fontSize, 'bold'))
        self.tree.tag_configure('chapter', foreground=prefs['color_chapter'])
        self.tree.tag_configure('arc', font=('', fontSize, 'bold'), foreground=prefs['color_arc'])
        self.tree.tag_configure('plot_point', foreground=prefs['color_arc'])
        self.tree.tag_configure('unused', foreground=prefs['color_unused'])
        self.tree.tag_configure('stage1', font=('', fontSize, 'bold'), foreground=prefs['color_stage'])
        self.tree.tag_configure('stage2', foreground=prefs['color_stage'])
        self.tree.tag_configure('part', font=('', fontSize, 'bold'))
        self.tree.tag_configure('major', foreground=prefs['color_major'])
        self.tree.tag_configure('minor', foreground=prefs['color_minor'])
        self.tree.tag_configure('status1', foreground=prefs['color_outline'])
        self.tree.tag_configure('status2', foreground=prefs['color_draft'])
        self.tree.tag_configure('status3', foreground=prefs['color_1st_edit'])
        self.tree.tag_configure('status4', foreground=prefs['color_2nd_edit'])
        self.tree.tag_configure('status5', foreground=prefs['color_done'])
        self.tree.tag_configure('On_schedule', foreground=prefs['color_on_schedule'])
        self.tree.tag_configure('Behind_schedule', foreground=prefs['color_behind_schedule'])
        self.tree.tag_configure('Before_schedule', foreground=prefs['color_before_schedule'])

        self._history = HistoryList()

        try:
            self.coloringMode = int(prefs['coloring_mode'])
        except:
            self.coloringMode = 0
        if self.coloringMode > len(self.COLORING_MODES):
            self.coloringMode = 0

        self._build_menus()

        self._bind_events()

    def close_children(self, parent):
        self.tree.item(parent, open=False)
        self._update_node_values(parent, collect=True)
        for child in self.tree.get_children(parent):
            self.close_children(child)

    def configure_columns(self):
        self._colPos = {}
        self.columns = []
        titles = []
        srtColumns = string_to_list(prefs['column_order'])

        for coId in self._COLUMNS:
            if not coId in srtColumns:
                srtColumns.append(coId)
        i = 0
        for coId in srtColumns:
            try:
                title, width = self._COLUMNS[coId]
            except:
                continue
            self._colPos[coId] = i
            i += 1
            self.columns.append((coId, title, width))
            titles.append(title)
        self.tree.configure(columns=tuple(titles))
        for column in self.columns:
            self.tree.heading(column[1], text=column[1], anchor='w')
            self.tree.column(column[1], width=int(prefs[column[2]]), minwidth=3, stretch=False)
        self.tree.column('#0', width=int(prefs['title_width']), stretch=False)

    def go_back(self, event=None):
        self._browse_tree(self._history.go_back())

    def go_forward(self, event=None):
        self._browse_tree(self._history.go_forward())

    def see_node(self, node):
        try:
            self.tree.see(node)
            parent = self.tree.parent(node)
            self._update_node_values(parent, collect=False)
        except:
            pass

    def go_to_node(self, node):
        try:
            self.tree.focus_set()
            self.tree.selection_set(node)
            self.see_node(node)
            self.tree.focus(node)
        except:
            pass

    def next_node(self, thisNode):

        def search_tree(parent, result, flag):
            for child in self.tree.get_children(parent):
                if result:
                    break
                if child.startswith(prefix):
                    if prefix == CHAPTER_PREFIX:
                        if self._mdl.novel.chapters[child].chLevel != self._mdl.novel.chapters[thisNode].chLevel:
                            continue

                    elif prefix == SECTION_PREFIX:
                        if self._mdl.novel.sections[thisNode].scType > 1:
                            if self._mdl.novel.sections[child].scType != self._mdl.novel.sections[thisNode].scType:
                                continue

                        elif self._mdl.novel.sections[thisNode].scType < 2:
                            if self._mdl.novel.sections[child].scType > 1:
                                continue

                    if flag:
                        result = child
                        break

                    elif child == thisNode:
                        flag = True
                else:
                    result, flag = search_tree(child, result, flag)
            return result, flag

        prefix = thisNode[:2]
        root = self.tree.parent(thisNode)
        while not root.startswith(ROOT_PREFIX):
            root = self.tree.parent(root)
        nextNode, __ = search_tree(root, None, False)
        return nextNode

    def on_quit(self):
        prefs['title_width'] = self.tree.column('#0', 'width')
        for i, column in enumerate(self.columns):
            prefs[column[2]] = self.tree.column(i, 'width')

        prefs['coloring_mode'] = self.coloringMode

    def open_children(self, parent):
        self.tree.item(parent, open=True)
        self._update_node_values(parent, collect=False)
        for child in self.tree.get_children(parent):
            self.open_children(child)

    def prev_node(self, thisNode):

        def search_tree(parent, result, prevNode):
            for child in self.tree.get_children(parent):
                if result:
                    break

                if child.startswith(prefix):
                    if prefix == CHAPTER_PREFIX:
                        if self._mdl.novel.chapters[child].chLevel != self._mdl.novel.chapters[thisNode].chLevel:
                            continue

                    elif prefix == SECTION_PREFIX:
                        if self._mdl.novel.sections[thisNode].scType > 1:
                            if self._mdl.novel.sections[child].scType != self._mdl.novel.sections[thisNode].scType:
                                continue

                        elif self._mdl.novel.sections[thisNode].scType < 2:
                            if self._mdl.novel.sections[child].scType > 1:
                                continue

                    if child == thisNode:
                        result = prevNode
                        break
                    else:
                        prevNode = child
                else:
                    result, prevNode = search_tree(child, result, prevNode)
            return result, prevNode

        prefix = thisNode[:2]
        root = self.tree.parent(thisNode)
        while not root.startswith(ROOT_PREFIX):
            root = self.tree.parent(root)
        prevNode, __ = search_tree(root, None, None)
        return prevNode

    def reset_view(self):
        self._history.reset()
        for rootElement in self.tree.get_children(''):
            self.tree.item(rootElement, text='')
        self.tree.configure({'selectmode': 'none'})
        self._ctrl.reset_tree()

    def show_branch(self, node):
        self.go_to_node(node)
        self.open_children(node)
        return 'break'

    def show_chapter_level(self, event=None):

        def show_chapters(parent):
            if parent.startswith(CHAPTER_PREFIX):
                self.tree.item(parent, open=False)
                self._update_node_values(parent, collect=True)
            else:
                self.tree.item(parent, open=True)
                for child in self.tree.get_children(parent):
                    show_chapters(child)

        show_chapters(CH_ROOT)
        return 'break'

    def refresh(self, event=None):

        def update_branch(node, scnPos=0):
            for elemId in self.tree.get_children(node):
                if elemId.startswith(SECTION_PREFIX):
                    title, nodeValues, nodeTags = self._get_section_row_data(elemId, position=scnPos)
                    if self._mdl.novel.sections[elemId].scType == 0:
                        scnPos += self._mdl.novel.sections[elemId].wordCount
                elif elemId.startswith(CHARACTER_PREFIX):
                    title, nodeValues, nodeTags = self._get_character_row_data(elemId)
                elif elemId.startswith(LOCATION_PREFIX):
                    title, nodeValues, nodeTags = self._get_location_row_data(elemId)
                elif elemId.startswith(ITEM_PREFIX):
                    title, nodeValues, nodeTags = self._get_item_row_data(elemId)
                elif elemId.startswith(CHAPTER_PREFIX):
                    chpPos = scnPos
                    scnPos = update_branch(elemId, scnPos)
                    isCollapsed = not self.tree.item(elemId, 'open')
                    title, nodeValues, nodeTags = self._get_chapter_row_data(elemId, position=chpPos, collect=isCollapsed)
                elif elemId.startswith(PLOT_LINE_PREFIX):
                    update_branch(elemId, scnPos)
                    isCollapsed = not self.tree.item(elemId, 'open')
                    title, nodeValues, nodeTags = self._get_plot_line_row_data(elemId, collect=isCollapsed)
                elif elemId.startswith(PLOT_POINT_PREFIX):
                    title, nodeValues, nodeTags = self._get_plot_point_row_data(elemId)
                elif elemId.startswith(PRJ_NOTE_PREFIX):
                    title, nodeValues, nodeTags = self._get_prj_note_row_data(elemId)
                else:
                    title = self._ROOT_TITLES[elemId]
                    nodeValues = []
                    nodeTags = 'root'
                    update_branch(elemId, scnPos)
                self.tree.item(elemId, text=title, values=nodeValues, tags=nodeTags)
            return scnPos

        if self.skipUpdate:
            self.skipUpdate = False
        elif self._mdl.prjFile is not None:
            self._wordsTotal = self._mdl.get_counts()[0]
            update_branch('')
            self.tree.configure(selectmode='extended')

    def _bind_events(self):
        self.tree.bind('<<TreeviewSelect>>', self._on_select_node)
        self.tree.bind('<<TreeviewOpen>>', self._on_open_branch)
        self.tree.bind('<<TreeviewClose>>', self._on_close_branch)
        self.tree.bind(KEYS.DELETE[0], self._ctrl.delete_elements)
        self.tree.bind(MOUSE.RIGHT_CLICK, self._on_open_context_menu)
        self.tree.bind(MOUSE.MOVE_NODE, self._on_move_node)

    def _browse_tree(self, node):
        if node and self.tree.exists(node):
            if self.tree.selection()[0] != node:
                self._history.lock()
                self.go_to_node(node)
        else:
            self._history.reset()
            self._history.append_node(self.tree.selection()[0])

    def _build_menus(self):


        self.selectTypeMenu = tk.Menu(self.tree, tearoff=0)
        self.selectTypeMenu.add_command(label=_('Normal'), command=lambda:self._ctrl.set_type(0))
        self.selectTypeMenu.add_command(label=_('Unused'), command=lambda:self._ctrl.set_type(1))

        self.selectLevelMenu = tk.Menu(self.tree, tearoff=0)
        self.selectLevelMenu.add_command(label=_('1st Level'), command=lambda:self._ctrl.set_level(1))
        self.selectLevelMenu.add_command(label=_('2nd Level'), command=lambda:self._ctrl.set_level(2))

        self.scStatusMenu = tk.Menu(self.tree, tearoff=0)
        self.scStatusMenu.add_command(label=_('Outline'), command=lambda:self._ctrl.set_completion_status(1))
        self.scStatusMenu.add_command(label=_('Draft'), command=lambda:self._ctrl.set_completion_status(2))
        self.scStatusMenu.add_command(label=_('1st Edit'), command=lambda:self._ctrl.set_completion_status(3))
        self.scStatusMenu.add_command(label=_('2nd Edit'), command=lambda:self._ctrl.set_completion_status(4))
        self.scStatusMenu.add_command(label=_('Done'), command=lambda:self._ctrl.set_completion_status(5))

        self.crStatusMenu = tk.Menu(self.tree, tearoff=0)
        self.crStatusMenu.add_command(label=_('Major Character'), command=lambda:self._ctrl.set_character_status(True))
        self.crStatusMenu.add_command(label=_('Minor Character'), command=lambda:self._ctrl.set_character_status(False))


        self._nvCtxtMenu = ContextMenu(self.tree, tearoff=0)
        self._nvCtxtMenu.add_command(label=_('Add Section'), command=self._ctrl.add_section)
        self._nvCtxtMenu.add_command(label=_('Add Chapter'), command=self._ctrl.add_chapter)
        self._nvCtxtMenu.add_command(label=_('Add Part'), command=self._ctrl.add_part)
        self._nvCtxtMenu.add_command(label=_('Insert Stage'), command=self._ctrl.add_stage)
        self._nvCtxtMenu.add_cascade(label=_('Change Level'), menu=self.selectLevelMenu)
        self._nvCtxtMenu.add_separator()
        self._nvCtxtMenu.add_command(label=_('Delete'), accelerator=KEYS.DELETE[1], command=self._ctrl.delete_elements)
        self._nvCtxtMenu.add_separator()
        self._nvCtxtMenu.add_cascade(label=_('Set Type'), menu=self.selectTypeMenu)
        self._nvCtxtMenu.add_cascade(label=_('Set Status'), menu=self.scStatusMenu)
        self._nvCtxtMenu.add_separator()
        self._nvCtxtMenu.add_command(label=_('Join with previous'), command=self._ctrl.join_sections)
        self._nvCtxtMenu.add_separator()
        self._nvCtxtMenu.add_command(label=_('Chapter level'), command=self.show_chapter_level)
        self._nvCtxtMenu.add_command(label=_('Expand'), command=lambda: self.open_children(self.tree.selection()[0]))
        self._nvCtxtMenu.add_command(label=_('Collapse'), command=lambda: self.close_children(self.tree.selection()[0]))
        self._nvCtxtMenu.add_command(label=_('Expand all'), command=lambda: self.open_children(''))
        self._nvCtxtMenu.add_command(label=_('Collapse all'), command=lambda: self.close_children(''))

        self._wrCtxtMenu = ContextMenu(self.tree, tearoff=0)
        self._wrCtxtMenu.add_command(label=_('Add'), command=self._ctrl.add_element)
        self._wrCtxtMenu.add_separator()
        self._wrCtxtMenu.add_command(label=_('Delete'), accelerator=KEYS.DELETE[1], command=self._ctrl.delete_elements)
        self._wrCtxtMenu.add_separator()
        self._wrCtxtMenu.add_cascade(label=_('Set Status'), menu=self.crStatusMenu)

        self._plCtxtMenu = ContextMenu(self.tree, tearoff=0)
        self._plCtxtMenu.add_command(label=_('Add Plot line'), command=self._ctrl.add_plot_line)
        self._plCtxtMenu.add_command(label=_('Add Plot point'), command=self._ctrl.add_plot_point)
        self._plCtxtMenu.add_separator()
        self._plCtxtMenu.add_command(label=_('Delete'), accelerator=KEYS.DELETE[1], command=self._ctrl.delete_elements)

        self._pnCtxtMenu = ContextMenu(self.tree, tearoff=0)
        self._pnCtxtMenu.add_command(label=_('Add Project note'), command=self._ctrl.add_project_note)
        self._pnCtxtMenu.add_separator()
        self._pnCtxtMenu.add_command(label=_('Delete'), accelerator=KEYS.DELETE[1], command=self._ctrl.delete_elements)

    def _collect_ch_note_indicators(self, chId):
        if self._mdl.novel.chapters[chId].notes:
            return self._NOTE_INDICATOR

        if self._mdl.novel.chapters[chId].chType == 0:
            for scId in self.tree.get_children(chId):
                if self._mdl.novel.sections[scId].scType != 1:
                    if self._mdl.novel.sections[scId].notes:
                        return self._NOTE_INDICATOR

        return ''

    def _collect_pl_note_indicators(self, plId):
        if self._mdl.novel.plotLines[plId].notes:
            return self._NOTE_INDICATOR

        for ppId in self.tree.get_children(plId):
            if self._mdl.novel.plotPoints[ppId].notes:
                return self._NOTE_INDICATOR

        return ''

    def _collect_plot_lines(self, chId):
        chPlotlineShortNames = []
        chPlotPointTitles = []
        chPlotlines = {}
        for plId in self._mdl.novel.plotLines:
            chPlotlines[plId] = []
        if self._mdl.novel.chapters[chId].chType == 0:
            for scId in self.tree.get_children(chId):
                if self._mdl.novel.sections[scId].scType == 0:
                    scPlotlines = self._mdl.novel.sections[scId].scPlotLines
                    for plId in scPlotlines:
                        shortName = self._mdl.novel.plotLines[plId].shortName
                        if not shortName in chPlotlineShortNames:
                            chPlotlineShortNames.append(shortName)
                    for ppId in self._mdl.novel.sections[scId].scPlotPoints:
                        chPlotlines[plId].append(ppId)
            if len(chPlotlineShortNames) == 1:
                for plId in chPlotlines:
                    for ppId in chPlotlines[plId]:
                        chPlotPointTitles.append(self._mdl.novel.plotPoints[ppId].title)
            else:
                for plId in chPlotlines:
                    for ppId in chPlotlines[plId]:
                        chPlotPointTitles.append(f'{self._mdl.novel.plotLines[plId].shortName}: {self._mdl.novel.plotPoints[ppId].title}')
        return list_to_string(chPlotlineShortNames), list_to_string(chPlotPointTitles)

    def _collect_tags(self, chId):
        chapterTags = []
        if self._mdl.novel.chapters[chId].chType == 0:
            for scId in self.tree.get_children(chId):
                if self._mdl.novel.sections[scId].scType == 0:
                    if self._mdl.novel.sections[scId].tags:
                        for tag in self._mdl.novel.sections[scId].tags:
                            if not tag in chapterTags:
                                chapterTags.append(tag)
        return list_to_string(chapterTags)

    def _collect_viewpoints(self, chId):
        chapterViewpoints = []
        if self._mdl.novel.chapters[chId].chType == 0:
            for scId in self.tree.get_children(chId):
                if self._mdl.novel.sections[scId].scType == 0:
                    try:
                        crId = self._mdl.novel.sections[scId].characters[0]
                        viewpoint = self._mdl.novel.characters[crId].title
                        if not viewpoint in chapterViewpoints:
                            chapterViewpoints.append(viewpoint)
                    except:
                        pass
        return list_to_string(chapterViewpoints)

    def _count_words(self, chId):
        chapterWordCount = 0
        if self._mdl.novel.chapters[chId].chType == 0:
            for scId in self.tree.get_children(chId):
                if self._mdl.novel.sections[scId].scType == 0:
                    chapterWordCount += self._mdl.novel.sections[scId].wordCount
        return chapterWordCount

    def _date_is_valid(self, section):
        if section.date is None:
            return False

        if section.date == section.NULL_DATE:
            return False

        return True

    def _export_synopsis(self, event=None):
        self._ctrl.export_document(SECTIONS_SUFFIX, filter=self.tree.selection()[0], ask=False)

    def _get_chapter_row_data(self, chId, position=None, collect=False):
        nodeValues = [''] * len(self.columns)
        nodeTags = []
        if self._mdl.novel.chapters[chId].chType != 0:
            nodeTags.append('unused')
            if self._mdl.novel.chapters[chId].chLevel == 1:
                nodeTags.append('part')
        else:
            nodeTags.append('chapter')
            try:
                positionStr = f'{round(100 * position / self._wordsTotal, 1)}%'
            except:
                positionStr = ''
            wordCount = self._count_words(chId)
            if self._mdl.novel.chapters[chId].chLevel == 1:
                nodeTags.append('part')

                srtChapters = self.tree.get_children(CH_ROOT)
                i = srtChapters.index(chId) + 1
                while i < len(srtChapters):
                    c = srtChapters[i]
                    if self._mdl.novel.chapters[c].chLevel == 1:
                        break
                    i += 1
                    wordCount += self._count_words(c)
            nodeValues[self._colPos['wc']] = wordCount
            nodeValues[self._colPos['po']] = positionStr
            if collect:
                nodeValues[self._colPos['vp']] = self._collect_viewpoints(chId)
        if collect:
            nodeValues[self._colPos['tg']] = self._collect_tags(chId)
            nodeValues[self._colPos['ac']], nodeValues[self._colPos['tp']] = self._collect_plot_lines(chId)
            nodeValues[self._colPos['nt']] = self._collect_ch_note_indicators(chId)
        else:
            nodeValues[self._colPos['nt']] = self._get_notes_indicator(self._mdl.novel.chapters[chId])
        return to_string(self._mdl.novel.chapters[chId].title), nodeValues, tuple(nodeTags)

    def _get_character_row_data(self, crId):
        nodeValues = [''] * len(self.columns)

        nodeValues[self._colPos['nt']] = self._get_notes_indicator(self._mdl.novel.characters[crId])

        wordCount = 0
        for scId in self._mdl.novel.sections:
            if self._mdl.novel.sections[scId].scType == 0:
                if self._mdl.novel.sections[scId].characters:
                    if self._mdl.novel.sections[scId].characters[0] == crId:
                        wordCount += self._mdl.novel.sections[scId].wordCount
        if wordCount > 0:
            nodeValues[self._colPos['wc']] = wordCount

            try:
                percentageStr = f'{round(100 * wordCount / self._wordsTotal, 1)}%'
            except:
                percentageStr = ''
            nodeValues[self._colPos['vp']] = percentageStr

        try:
            nodeValues[self._colPos['tg']] = list_to_string(self._mdl.novel.characters[crId].tags)
        except:
            pass

        nodeTags = []
        if self._mdl.novel.characters[crId].isMajor:
            nodeTags.append('major')
        else:
            nodeTags.append('minor')
        return to_string(self._mdl.novel.characters[crId].title), nodeValues, tuple(nodeTags)

    def _get_date_or_day(self, scId):
        if self._date_is_valid(self._mdl.novel.sections[scId]):
            return get_section_date_str(self._mdl.novel.sections[scId])

        if self._mdl.novel.sections[scId].day is not None:
            return f'{_("Day")} {self._mdl.novel.sections[scId].day}'

        return ''

        title = self._mdl.novel.sections[scId].title
        if not title:
            title = _('Unnamed')

    def _get_item_row_data(self, itId):
        nodeValues = [''] * len(self.columns)

        nodeValues[self._colPos['nt']] = self._get_notes_indicator(self._mdl.novel.items[itId])

        try:
            nodeValues[self._colPos['tg']] = list_to_string(self._mdl.novel.items[itId].tags)
        except:
            pass
        return to_string(self._mdl.novel.items[itId].title), nodeValues, ()

    def _get_location_row_data(self, lcId):
        nodeValues = [''] * len(self.columns)

        nodeValues[self._colPos['nt']] = self._get_notes_indicator(self._mdl.novel.locations[lcId])

        try:
            nodeValues[self._colPos['tg']] = list_to_string(self._mdl.novel.locations[lcId].tags)
        except:
            pass
        return to_string(self._mdl.novel.locations[lcId].title), nodeValues, ()

    def _get_notes_indicator(self, element):
        if element.notes:
            return self._NOTE_INDICATOR

        return ''

    def _get_plot_line_row_data(self, plId, collect=False):
        fullName = to_string(self._mdl.novel.plotLines[plId].title)
        title = f'({self._mdl.novel.plotLines[plId].shortName}) {fullName}'
        nodeValues = [''] * len(self.columns)
        if collect:
            nodeValues[self._colPos['nt']] = self._collect_pl_note_indicators(plId)
        else:
            nodeValues[self._colPos['nt']] = self._get_notes_indicator(self._mdl.novel.plotLines[plId])
        return title, nodeValues, ('arc')

    def _get_plot_point_row_data(self, ppId):
        nodeValues = [''] * len(self.columns)

        nodeValues[self._colPos['nt']] = self._get_notes_indicator(self._mdl.novel.plotPoints[ppId])

        scId = self._mdl.novel.plotPoints[ppId].sectionAssoc
        if scId:
            sectionTitle = self._mdl.novel.sections[scId].title
            if sectionTitle is not None:
                nodeValues[self._colPos['tp']] = sectionTitle
        return to_string(self._mdl.novel.plotPoints[ppId].title), nodeValues, ('plot_point')

    def _get_prj_note_row_data(self, pnId):
        nodeValues = [''] * len(self.columns)
        return to_string(self._mdl.novel.projectNotes[pnId].title), nodeValues, ()

    def _get_section_row_data(self, scId, position=None):

        if self._mdl.novel.sections[scId].time is not None:
            dispTime = self._mdl.novel.sections[scId].time.rsplit(':', 1)[0]
        else:
            dispTime = ''

        if self._mdl.novel.sections[scId].lastsDays and self._mdl.novel.sections[scId].lastsDays != '0':
            days = f'{self._mdl.novel.sections[scId].lastsDays}d '
        else:
            days = ''
        if self._mdl.novel.sections[scId].lastsHours and self._mdl.novel.sections[scId].lastsHours != '0':
            hours = f'{self._mdl.novel.sections[scId].lastsHours}h '
        else:
            hours = ''
        if self._mdl.novel.sections[scId].lastsMinutes and self._mdl.novel.sections[scId].lastsMinutes != '0':
            minutes = f'{self._mdl.novel.sections[scId].lastsMinutes}min'
        else:
            minutes = ''

        nodeValues = [''] * len(self.columns)
        nodeTags = []
        if self._mdl.novel.sections[scId].scType > 1:
            stageLevel = self._mdl.novel.sections[scId].scType - 1
            nodeTags.append(f'stage{stageLevel}')
        else:
            positionStr = ''
            if self._mdl.novel.sections[scId].scType == 1:
                nodeTags.append('unused')
            else:
                if self.coloringMode == 1:
                    nodeTags.append(f'status{self._mdl.novel.sections[scId].status}')
                elif self.coloringMode == 2 and self._mdl.novel.workPhase:
                    if self._mdl.novel.sections[scId].status == self._mdl.novel.workPhase:
                        nodeTags.append('On_schedule')
                    elif self._mdl.novel.sections[scId].status < self._mdl.novel.workPhase:
                        nodeTags.append('Behind_schedule')
                    else:
                        nodeTags.append('Before_schedule')
                try:
                    positionStr = f'{round(100 * position / self._wordsTotal, 1)}%'
                except:
                    pass
            nodeValues[self._colPos['po']] = positionStr
            nodeValues[self._colPos['wc']] = self._mdl.novel.sections[scId].wordCount
            nodeValues[self._colPos['st']] = self._mdl.novel.sections[scId].STATUS[self._mdl.novel.sections[scId].status]
            try:
                nodeValues[self._colPos['vp']] = self._mdl.novel.characters[self._mdl.novel.sections[scId].characters[0]].title
            except:
                nodeValues[self._colPos['vp']] = _('N/A')

            nodeValues[self._colPos['sc']] = self._SCENE[self._mdl.novel.sections[scId].scene]

            nodeValues[self._colPos['dt']] = self._get_date_or_day(scId)
            nodeValues[self._colPos['tm']] = dispTime
            nodeValues[self._colPos['dr']] = f'{days}{hours}{minutes}'

            scPlotlineShortNames = []
            scPlotPointTitles = []
            scPlotlines = self._mdl.novel.sections[scId].scPlotLines
            for plId in scPlotlines:
                shortName = self._mdl.novel.plotLines[plId].shortName
                if not shortName in scPlotlineShortNames:
                    scPlotlineShortNames.append(shortName)
            for ppId in self._mdl.novel.sections[scId].scPlotPoints:
                if len(scPlotlineShortNames) == 1:
                    scPlotPointTitles.append(self._mdl.novel.plotPoints[ppId].title)
                else:
                    plId = self._mdl.novel.sections[scId].scPlotPoints[ppId]
                    scPlotPointTitles.append(f'{self._mdl.novel.plotLines[plId].shortName}: {self._mdl.novel.plotPoints[ppId].title}')
            nodeValues[self._colPos['ac']] = list_to_string(scPlotlineShortNames)
            nodeValues[self._colPos['tp']] = list_to_string(scPlotPointTitles)

        nodeValues[self._colPos['nt']] = self._get_notes_indicator(self._mdl.novel.sections[scId])

        try:
            nodeValues[self._colPos['tg']] = list_to_string(self._mdl.novel.sections[scId].tags)
        except:
            pass
        return to_string(self._mdl.novel.sections[scId].title), nodeValues, tuple(nodeTags)

    def _on_close_branch(self, event):
        self._update_node_values(self.tree.selection()[0], collect=True)

    def _on_move_node(self, event):
        self._ctrl.move_node(
            self.tree.selection()[0],
            self.tree.identify_row(event.y)
            )

    def _on_open_branch(self, event):
        self._update_node_values(self.tree.selection()[0], collect=False)

    def _on_open_context_menu(self, event):
        if self._mdl is None:
            return

        row = self.tree.identify_row(event.y)
        if row:
            self.go_to_node(row)
            if row.startswith(ROOT_PREFIX):
                prefix = row
            else:
                prefix = row[:2]
            if prefix in (CH_ROOT, CHAPTER_PREFIX, SECTION_PREFIX):
                if prefix.startswith(CH_ROOT):
                    self._nvCtxtMenu.entryconfig(_('Delete'), state='disabled')
                    self._nvCtxtMenu.entryconfig(_('Set Type'), state='disabled')
                    self._nvCtxtMenu.entryconfig(_('Set Status'), state='normal')
                    self._nvCtxtMenu.entryconfig(_('Add Section'), state='disabled')
                    self._nvCtxtMenu.entryconfig(_('Add Chapter'), state='normal')
                    self._nvCtxtMenu.entryconfig(_('Add Part'), state='normal')
                    self._nvCtxtMenu.entryconfig(_('Insert Stage'), state='disabled')
                    self._nvCtxtMenu.entryconfig(_('Change Level'), state='disabled')
                    self._nvCtxtMenu.entryconfig(_('Join with previous'), state='disabled')
                else:
                    self._nvCtxtMenu.entryconfig(_('Delete'), state='normal')
                    self._nvCtxtMenu.entryconfig(_('Set Type'), state='normal')
                    self._nvCtxtMenu.entryconfig(_('Set Status'), state='normal')
                    self._nvCtxtMenu.entryconfig(_('Add Section'), state='normal')
                    self._nvCtxtMenu.entryconfig(_('Add Chapter'), state='normal')
                    self._nvCtxtMenu.entryconfig(_('Add Part'), state='normal')
                    self._nvCtxtMenu.entryconfig(_('Insert Stage'), state='normal')
                    self._nvCtxtMenu.entryconfig(_('Change Level'), state='normal')
                    self._nvCtxtMenu.entryconfig(_('Join with previous'), state='normal')
                    if prefix.startswith(CHAPTER_PREFIX):
                        self._nvCtxtMenu.entryconfig(_('Join with previous'), state='disabled')
                        if row == self._mdl.trashBin:
                            self._nvCtxtMenu.entryconfig(_('Set Type'), state='disabled')
                            self._nvCtxtMenu.entryconfig(_('Set Status'), state='disabled')
                            self._nvCtxtMenu.entryconfig(_('Change Level'), state='disabled')
                            self._nvCtxtMenu.entryconfig(_('Add Section'), state='disabled')
                            self._nvCtxtMenu.entryconfig(_('Add Chapter'), state='disabled')
                            self._nvCtxtMenu.entryconfig(_('Add Part'), state='disabled')
                            self._nvCtxtMenu.entryconfig(_('Insert Stage'), state='disabled')
                    if prefix.startswith(SECTION_PREFIX):
                        if self._mdl.novel.sections[row].scType < 2:
                            self._nvCtxtMenu.entryconfig(_('Change Level'), state='disabled')
                        else:
                            self._nvCtxtMenu.entryconfig(_('Set Type'), state='disabled')
                            self._nvCtxtMenu.entryconfig(_('Set Status'), state='disabled')
                            self._nvCtxtMenu.entryconfig(_('Join with previous'), state='disabled')
                try:
                    self._nvCtxtMenu.tk_popup(event.x_root, event.y_root, 0)
                finally:
                    self._nvCtxtMenu.grab_release()
            elif prefix in (CR_ROOT, CHARACTER_PREFIX, LC_ROOT, LOCATION_PREFIX, IT_ROOT, ITEM_PREFIX):
                self._wrCtxtMenu.entryconfig(_('Add'), state='normal')
                if prefix.startswith('wr'):
                    self._wrCtxtMenu.entryconfig(_('Delete'), state='disabled')
                else:
                    self._wrCtxtMenu.entryconfig(_('Delete'), state='normal')
                if prefix.startswith(CHARACTER_PREFIX) or  row.endswith(CHARACTER_PREFIX):
                    self._wrCtxtMenu.entryconfig(_('Set Status'), state='normal')
                else:
                    self._wrCtxtMenu.entryconfig(_('Set Status'), state='disabled')
                try:
                    self._wrCtxtMenu.tk_popup(event.x_root, event.y_root, 0)
                finally:
                    self._wrCtxtMenu.grab_release()
            elif prefix in (PL_ROOT, PLOT_LINE_PREFIX, PLOT_POINT_PREFIX):
                if prefix.startswith(PL_ROOT):
                    self._plCtxtMenu.entryconfig(_('Add Plot line'), state='normal')
                    self._plCtxtMenu.entryconfig(_('Add Plot point'), state='disabled')
                    self._plCtxtMenu.entryconfig(_('Delete'), state='disabled')
                else:
                    self._plCtxtMenu.entryconfig(_('Add Plot line'), state='normal')
                    self._plCtxtMenu.entryconfig(_('Add Plot point'), state='normal')
                    self._plCtxtMenu.entryconfig(_('Delete'), state='normal')
                try:
                    self._plCtxtMenu.tk_popup(event.x_root, event.y_root, 0)
                finally:
                    self._plCtxtMenu.grab_release()
            elif prefix in (PN_ROOT, PRJ_NOTE_PREFIX):
                if prefix.startswith(PN_ROOT):
                    self._pnCtxtMenu.entryconfig(_('Add Project note'), state='normal')
                    self._pnCtxtMenu.entryconfig(_('Delete'), state='normal')
                try:
                    self._pnCtxtMenu.tk_popup(event.x_root, event.y_root, 0)
                finally:
                    self._pnCtxtMenu.grab_release()

    def _on_select_node(self, event):
        try:
            nodeId = self.tree.selection()[0]
        except IndexError:
            return

        self._history.append_node(nodeId)
        self._ui.on_change_selection(nodeId)

    def _update_node_values(self, nodeId, collect=False):
        if nodeId.startswith(CHAPTER_PREFIX):
            positionStr = self.tree.item(nodeId)['values'][self._colPos['po']]
            __, nodeValues, __ = self._get_chapter_row_data(nodeId, position=None, collect=collect)
            nodeValues[self._colPos['po']] = positionStr
            self.tree.item(nodeId, values=nodeValues)
            return

        if nodeId.startswith(PLOT_LINE_PREFIX):
            __, nodeValues, __ = self._get_plot_line_row_data(nodeId, collect=collect)
            self.tree.item(nodeId, values=nodeValues)
            return



class NvView(ViewBase):
    _MIN_WINDOW_WIDTH = 400
    _MIN_WINDOW_HEIGHT = 200

    _MAX_NR_NEW_SECTIONS = 20
    _INI_NR_NEW_SECTIONS = 1

    def __init__(self, model, controller, title):
        super().__init__(model, controller, title)

        self._statusText = ''
        if prefs.get('root_geometry', None):
            self.root.geometry(prefs['root_geometry'])
        set_icon(self.root, icon='nLogo32')
        self.root.minsize(self._MIN_WINDOW_WIDTH, self._MIN_WINDOW_HEIGHT)

        self.mainMenu = tk.Menu(self.root)
        self.root.config(menu=self.mainMenu)

        self.mainWindow = tk.Frame()
        self.mainWindow.pack(expand=True, fill='both')

        self.statusBar = tk.Label(self.root, text='', anchor='w', padx=5, pady=2)
        self.statusBar.pack(expand=False, fill='both')
        self.statusBar.bind(MOUSE.LEFT_CLICK, self.restore_status)
        self.infoWhatText = ''
        self.infoHowText = ''

        self.pathBar = tk.Label(self.root, text='', anchor='w', padx=5, pady=3)
        self.pathBar.pack(expand=False, fill='both')

        self.guiStyle = ttk.Style()

        self.icons = Icons()


        self.appWindow = ttk.Frame(self.mainWindow)
        self.appWindow.pack(expand=True, fill='both')

        self.leftFrame = ttk.Frame(self.appWindow)
        self.leftFrame.pack(side='left', expand=True, fill='both')

        self.tv = TreeViewer(self.leftFrame, self._mdl, self, self._ctrl)
        self.register_client(self.tv)
        self.tv.pack(expand=True, fill='both')

        self.middleFrame = ttk.Frame(self.appWindow, width=prefs['middle_frame_width'])
        self.middleFrame.pack_propagate(0)

        self.contentsView = ContentsViewer(self.middleFrame, self._mdl, self, self._ctrl)
        self.register_client(self.contentsView)
        if prefs['show_contents']:
            self.middleFrame.pack(side='left', expand=False, fill='both')

        self.rightFrame = ttk.Frame(self.appWindow, width=prefs['right_frame_width'])
        self.rightFrame.pack_propagate(0)
        if prefs['show_properties']:
            self.rightFrame.pack(expand=True, fill='both')

        self.propertiesView = PropertiesViewer(self.rightFrame, self._mdl, self, self._ctrl)
        self.propertiesView.pack(expand=True, fill='both')
        self._propWinDetached = False
        if prefs['detach_prop_win']:
            self.detach_properties_frame()
        self.register_client(self.propertiesView)

        self._build_menu()

        self.toolbar = Toolbar(self.mainWindow, self._mdl, self, self._ctrl)
        self.register_client(self.toolbar)

        self._bind_events()

    def detach_properties_frame(self, event=None):
        self.propertiesView.apply_changes()
        if self._propWinDetached:
            return

        if self.rightFrame.winfo_manager():
            self.rightFrame.pack_forget()
        self._propertiesWindow = tk.Toplevel()
        self._propertiesWindow.geometry(prefs['prop_win_geometry'])
        set_icon(self._propertiesWindow, icon='pLogo32', default=False)

        self.propertiesView.pack_forget()
        self.unregister_client(self.propertiesView)
        self.propertiesView = PropertiesViewer(self._propertiesWindow, self._mdl, self, self._ctrl)
        self.register_client(self.propertiesView)
        self.propertiesView.pack(expand=True, fill='both')

        self._propertiesWindow.protocol("WM_DELETE_WINDOW", self.dock_properties_frame)
        prefs['detach_prop_win'] = True
        self._propWinDetached = True
        try:
            self.propertiesView.show_properties(self.tv.tree.selection()[0])
        except IndexError:
            pass
        return 'break'

    def disable_menu(self):
        self.fileMenu.entryconfig(_('Close'), state='disabled')
        self.mainMenu.entryconfig(_('Part'), state='disabled')
        self.mainMenu.entryconfig(_('Chapter'), state='disabled')
        self.mainMenu.entryconfig(_('Section'), state='disabled')
        self.mainMenu.entryconfig(_('Characters'), state='disabled')
        self.mainMenu.entryconfig(_('Locations'), state='disabled')
        self.mainMenu.entryconfig(_('Items'), state='disabled')
        self.mainMenu.entryconfig(_('Plot'), state='disabled')
        self.mainMenu.entryconfig(_('Project notes'), state='disabled')
        self.mainMenu.entryconfig(_('Export'), state='disabled')
        self.fileMenu.entryconfig(_('Reload'), state='disabled')
        self.fileMenu.entryconfig(_('Restore backup'), state='disabled')
        self.fileMenu.entryconfig(_('Refresh Tree'), state='disabled')
        self.fileMenu.entryconfig(_('Open Project folder'), state='disabled')
        self.fileMenu.entryconfig(_('Save'), state='disabled')
        self.fileMenu.entryconfig(_('Save as...'), state='disabled')
        self.viewMenu.entryconfig(_('Chapter level'), state='disabled')
        self.viewMenu.entryconfig(_('Expand selected'), state='disabled')
        self.viewMenu.entryconfig(_('Collapse selected'), state='disabled')
        self.viewMenu.entryconfig(_('Expand all'), state='disabled')
        self.viewMenu.entryconfig(_('Collapse all'), state='disabled')
        self.viewMenu.entryconfig(_('Show Book'), state='disabled')
        self.viewMenu.entryconfig(_('Show Characters'), state='disabled')
        self.viewMenu.entryconfig(_('Show Locations'), state='disabled')
        self.viewMenu.entryconfig(_('Show Items'), state='disabled')
        self.viewMenu.entryconfig(_('Show Plot lines'), state='disabled')
        self.viewMenu.entryconfig(_('Show Project notes'), state='disabled')
        super().disable_menu()

    def dock_properties_frame(self, event=None):
        self.propertiesView.apply_changes()
        if not self._propWinDetached:
            return

        if not self.rightFrame.winfo_manager():
            self.rightFrame.pack(side='left', expand=False, fill='both')

        prefs['prop_win_geometry'] = self._propertiesWindow.winfo_geometry()

        self._propertiesWindow.destroy()
        self.unregister_client(self.propertiesView)
        self.propertiesView = PropertiesViewer(self.rightFrame, self._mdl, self, self._ctrl)
        self.register_client(self.propertiesView)
        self.propertiesView.pack(expand=True, fill='both')
        self.root.lift()

        prefs['show_properties'] = True
        prefs['detach_prop_win'] = False
        self._propWinDetached = False
        try:
            self.propertiesView.show_properties(self.tv.tree.selection()[0])
        except IndexError:
            pass
        return 'break'

    def enable_menu(self):
        self.fileMenu.entryconfig(_('Close'), state='normal')
        self.mainMenu.entryconfig(_('Part'), state='normal')
        self.mainMenu.entryconfig(_('Chapter'), state='normal')
        self.mainMenu.entryconfig(_('Section'), state='normal')
        self.mainMenu.entryconfig(_('Characters'), state='normal')
        self.mainMenu.entryconfig(_('Locations'), state='normal')
        self.mainMenu.entryconfig(_('Items'), state='normal')
        self.mainMenu.entryconfig(_('Plot'), state='normal')
        self.mainMenu.entryconfig(_('Project notes'), state='normal')
        self.mainMenu.entryconfig(_('Export'), state='normal')
        self.fileMenu.entryconfig(_('Reload'), state='normal')
        self.fileMenu.entryconfig(_('Restore backup'), state='normal')
        self.fileMenu.entryconfig(_('Refresh Tree'), state='normal')
        self.fileMenu.entryconfig(_('Open Project folder'), state='normal')
        self.fileMenu.entryconfig(_('Save'), state='normal')
        self.fileMenu.entryconfig(_('Save as...'), state='normal')
        self.viewMenu.entryconfig(_('Chapter level'), state='normal')
        self.viewMenu.entryconfig(_('Expand selected'), state='normal')
        self.viewMenu.entryconfig(_('Collapse selected'), state='normal')
        self.viewMenu.entryconfig(_('Expand all'), state='normal')
        self.viewMenu.entryconfig(_('Collapse all'), state='normal')
        self.viewMenu.entryconfig(_('Show Book'), state='normal')
        self.viewMenu.entryconfig(_('Show Characters'), state='normal')
        self.viewMenu.entryconfig(_('Show Locations'), state='normal')
        self.viewMenu.entryconfig(_('Show Items'), state='normal')
        self.viewMenu.entryconfig(_('Show Plot lines'), state='normal')
        self.viewMenu.entryconfig(_('Show Project notes'), state='normal')
        super().enable_menu()

    def on_change_selection(self, nodeId):
        self.propertiesView.show_properties(nodeId)
        self.contentsView.see(nodeId)

    def on_quit(self):

        prefs['show_markup'] = self.contentsView.showMarkup.get()

        if self._propWinDetached:
            prefs['prop_win_geometry'] = self._propertiesWindow.winfo_geometry()
        self.tv.on_quit()
        prefs['root_geometry'] = self.root.winfo_geometry()
        super().on_quit()

    def refresh(self):
        super().refresh()
        if self._mdl.isModified:
            self.pathBar.config(bg=prefs['color_modified_bg'])
            self.pathBar.config(fg=prefs['color_modified_fg'])
        else:
            self.pathBar.config(bg=self.root.cget('background'))
            self.pathBar.config(fg='black')
        self.set_title()

    def restore_status(self, event=None):
        self.show_status(self._statusText)

    def set_info(self, message):
        pass

    def set_status(self, message, colors=None):
        if message is not None:
            try:
                self.statusBar.config(bg=colors[0])
                self.statusBar.config(fg=colors[1])
                self.infoHowText = message
            except:
                if message.startswith('!'):
                    self.statusBar.config(bg='red')
                    self.statusBar.config(fg='white')
                    self.infoHowText = message.lstrip('!').strip()
                else:
                    self.statusBar.config(bg='green')
                    self.statusBar.config(fg='white')
                    self.infoHowText = message
            self.statusBar.config(text=self.infoHowText)

    def set_title(self):
        if self._mdl.novel is None:
            return

        if self._mdl.novel.title:
            titleView = self._mdl.novel.title
        else:
            titleView = _('Untitled project')
        if self._mdl.novel.authorName:
            authorView = self._mdl.novel.authorName
        else:
            authorView = _('Unknown author')
        self.root.title(f'{titleView} {_("by")} {authorView} - {self.title}')

    def show_path(self, message):
        self.pathBar.config(text=message)

    def show_status(self, message=''):
        self._statusText = message
        self.statusBar.config(bg=self.root.cget('background'))
        self.statusBar.config(fg='black')
        self.statusBar.config(text=message)

    def toggle_contents_view(self, event=None):
        if self.middleFrame.winfo_manager():
            self.middleFrame.pack_forget()
            prefs['show_contents'] = False
        else:
            self.middleFrame.pack(after=self.leftFrame, side='left', expand=False, fill='both')
            prefs['show_contents'] = True
        return 'break'

    def toggle_properties_view(self, event=None):
        if self.rightFrame.winfo_manager():
            self.propertiesView.apply_changes()
            self.rightFrame.pack_forget()
            prefs['show_properties'] = False
        elif not self._propWinDetached:
            self.rightFrame.pack(side='left', expand=False, fill='both')
            prefs['show_properties'] = True
        return 'break'

    def toggle_properties_window(self, event=None):
        if self._propWinDetached:
            self.dock_properties_frame()
        else:
            self.detach_properties_frame()
        return 'break'

    def _add_multiple_sections(self):
        n = askinteger(
            title=_('New'),
            prompt=_('How many sections to add?'),
            initialvalue=self._INI_NR_NEW_SECTIONS,
            minvalue=0,
            maxvalue=self._MAX_NR_NEW_SECTIONS
            )
        if n is not None:
            for __ in range(n):
                self._ctrl.add_section()

    def _bind_events(self):
        self.root.bind(KEYS.RESTORE_STATUS[0], self.restore_status)
        self.root.bind(KEYS.OPEN_PROJECT[0], self._ctrl.open_project)
        self.root.bind(KEYS.RELOAD_PROJECT[0], self._ctrl.reload_project)
        self.root.bind(KEYS.RESTORE_BACKUP[0], self._ctrl.restore_backup)
        self.root.bind(KEYS.FOLDER[0], self._ctrl.open_project_folder)
        self.root.bind(KEYS.REFRESH_TREE[0], self._ctrl.refresh_views)
        self.root.bind(KEYS.SAVE_PROJECT[0], self._ctrl.save_project)
        self.root.bind(KEYS.SAVE_AS[0], self._ctrl.save_as)
        self.root.bind(KEYS.CHAPTER_LEVEL[0], self.tv.show_chapter_level)
        self.root.bind(KEYS.TOGGLE_VIEWER[0], self.toggle_contents_view)
        self.root.bind(KEYS.TOGGLE_PROPERTIES[0], self.toggle_properties_view)
        self.root.bind(KEYS.DETACH_PROPERTIES[0], self.toggle_properties_window)
        self.root.bind(KEYS.ADD_ELEMENT[0], self._ctrl.add_element)
        self.root.bind(KEYS.ADD_CHILD[0], self._ctrl.add_child)
        self.root.bind(KEYS.ADD_PARENT[0], self._ctrl.add_parent)
        if PLATFORM == 'win':
            self.root.bind(MOUSE.BACK_CLICK, self.tv.go_back)
            self.root.bind(MOUSE.FORWARD_CLICK, self.tv.go_forward)
        else:
            self.root.bind(KEYS.QUIT_PROGRAM[0], self._ctrl.on_quit)
        self.root.bind(KEYS.OPEN_HELP[0], self._open_help)

    def _build_menu(self):

        self.newMenu = tk.Menu(self.mainMenu, tearoff=0)
        self.newMenu.add_command(label=_('Empty project'), command=self._ctrl.new_project)
        self.newMenu.add_command(label=_('Create from Markdown...'), command=self._ctrl.import_md)

        self.fileMenu = tk.Menu(self.mainMenu, tearoff=0)
        self.mainMenu.add_cascade(label=_('File'), menu=self.fileMenu)
        self.fileMenu.add_cascade(label=_('New'), menu=self.newMenu)
        self.fileMenu.add_command(label=_('Open...'), accelerator=KEYS.OPEN_PROJECT[1], command=self._ctrl.open_project)
        self.fileMenu.add_command(label=_('Reload'), accelerator=KEYS.RELOAD_PROJECT[1], command=self._ctrl.reload_project)
        self.fileMenu.add_command(label=_('Restore backup'), accelerator=KEYS.RESTORE_BACKUP[1], command=self._ctrl.restore_backup)
        self.fileMenu.add_separator()
        self.fileMenu.add_command(label=_('Refresh Tree'), accelerator=KEYS.REFRESH_TREE[1], command=self._ctrl.refresh_views)
        self.fileMenu.add_separator()
        self.fileMenu.add_command(label=_('Open Project folder'), accelerator=KEYS.FOLDER[1], command=self._ctrl.open_project_folder)
        self.fileMenu.add_separator()
        self.fileMenu.add_command(label=_('Save'), accelerator=KEYS.SAVE_PROJECT[1], command=self._ctrl.save_project)
        self.fileMenu.add_command(label=_('Save as...'), accelerator=KEYS.SAVE_AS[1], command=self._ctrl.save_as)
        self.fileMenu.add_command(label=_('Close'), command=self._ctrl.close_project)
        if PLATFORM == 'win':
            self.fileMenu.add_command(label=_('Exit'), accelerator=KEYS.QUIT_PROGRAM[1], command=self._ctrl.on_quit)
        else:
            self.fileMenu.add_command(label=_('Quit'), accelerator=KEYS.QUIT_PROGRAM[1], command=self._ctrl.on_quit)

        self.viewMenu = tk.Menu(self.mainMenu, tearoff=0)
        self.mainMenu.add_cascade(label=_('View'), menu=self.viewMenu)
        self.viewMenu.add_command(label=_('Chapter level'), accelerator=KEYS.CHAPTER_LEVEL[1], command=self.tv.show_chapter_level)
        self.viewMenu.add_command(label=_('Expand selected'), command=lambda: self.tv.open_children(self.tv.tree.selection()[0]))
        self.viewMenu.add_command(label=_('Collapse selected'), command=lambda: self.tv.close_children(self.tv.tree.selection()[0]))
        self.viewMenu.add_command(label=_('Expand all'), command=lambda: self.tv.open_children(''))
        self.viewMenu.add_command(label=_('Collapse all'), command=lambda: self.tv.close_children(''))
        self.viewMenu.add_separator()
        self.viewMenu.add_command(label=_('Show Book'), command=lambda: self.tv.show_branch(CH_ROOT))
        self.viewMenu.add_command(label=_('Show Characters'), command=lambda: self.tv.show_branch(CR_ROOT))
        self.viewMenu.add_command(label=_('Show Locations'), command=lambda: self.tv.show_branch(LC_ROOT))
        self.viewMenu.add_command(label=_('Show Items'), command=lambda: self.tv.show_branch(IT_ROOT))
        self.viewMenu.add_command(label=_('Show Plot lines'), command=lambda: self.tv.show_branch(PL_ROOT))
        self.viewMenu.add_command(label=_('Show Project notes'), command=lambda: self.tv.show_branch(PN_ROOT))
        self.viewMenu.add_separator()
        self.viewMenu.add_command(label=_('Toggle Text viewer'), accelerator=KEYS.TOGGLE_VIEWER[1], command=self.toggle_contents_view)
        self.viewMenu.add_command(label=_('Toggle Properties'), accelerator=KEYS.TOGGLE_PROPERTIES[1], command=self.toggle_properties_view)
        self.viewMenu.add_command(label=_('Detach/Dock Properties'), accelerator=KEYS.DETACH_PROPERTIES[1], command=self.toggle_properties_window)
        self.viewMenu.add_separator()
        self.viewMenu.add_command(label=_('Options'), command=self._open_view_options)

        self.partMenu = tk.Menu(self.mainMenu, tearoff=0)
        self.mainMenu.add_cascade(label=_('Part'), menu=self.partMenu)
        self.partMenu.add_command(label=_('Add'), command=self._ctrl.add_part)
        self.partMenu.add_separator()
        self.partMenu.add_command(label=_('Export part descriptions'), command=lambda: self._ctrl.export_document(PARTS_SUFFIX))

        self.chapterMenu = tk.Menu(self.mainMenu, tearoff=0)
        self.mainMenu.add_cascade(label=_('Chapter'), menu=self.chapterMenu)
        self.chapterMenu.add_command(label=_('Add'), command=self._ctrl.add_chapter)
        self.chapterMenu.add_separator()
        self.chapterMenu.add_cascade(label=_('Set Type'), menu=self.tv.selectTypeMenu)
        self.chapterMenu.add_cascade(label=_('Change Level'), menu=self.tv.selectLevelMenu)
        self.chapterMenu.add_separator()
        self.chapterMenu.add_command(label=_('Export chapter descriptions'), command=lambda: self._ctrl.export_document(CHAPTERS_SUFFIX))

        self.sectionMenu = tk.Menu(self.mainMenu, tearoff=0)
        self.mainMenu.add_cascade(label=_('Section'), menu=self.sectionMenu)
        self.sectionMenu.add_command(label=_('Add'), command=self._ctrl.add_section)
        self.sectionMenu.add_command(label=_('Add multiple sections'), command=self._add_multiple_sections)
        self.sectionMenu.add_separator()
        self.sectionMenu.add_cascade(label=_('Set Type'), menu=self.tv.selectTypeMenu)
        self.sectionMenu.add_cascade(label=_('Set Status'), menu=self.tv.scStatusMenu)
        self.sectionMenu.add_separator()
        self.sectionMenu.add_command(label=_('Export section descriptions'), command=lambda: self._ctrl.export_document(SECTIONS_SUFFIX))
        self.sectionMenu.add_command(label=_('Export section list'), command=lambda: self._ctrl.export_document(SECTIONLIST_SUFFIX))

        self.characterMenu = tk.Menu(self.mainMenu, tearoff=0)
        self.mainMenu.add_cascade(label=_('Characters'), menu=self.characterMenu)
        self.characterMenu.add_command(label=_('Add'), command=self._ctrl.add_character)
        self.characterMenu.add_separator()
        self.characterMenu.add_cascade(label=_('Set Status'), menu=self.tv.crStatusMenu)
        self.characterMenu.add_separator()
        self.characterMenu.add_command(label=_('Export character descriptions'), command=lambda: self._ctrl.export_document(CHARACTERS_SUFFIX))
        self.characterMenu.add_command(label=_('Export character list'), command=lambda: self._ctrl.export_document(CHARLIST_SUFFIX))
        self.characterMenu.add_command(label=_('Show list'), command=lambda: self._ctrl.show_report(CHARACTER_REPORT_SUFFIX))

        self.locationMenu = tk.Menu(self.mainMenu, tearoff=0)
        self.mainMenu.add_cascade(label=_('Locations'), menu=self.locationMenu)
        self.locationMenu.add_command(label=_('Add'), command=self._ctrl.add_location)
        self.locationMenu.add_separator()
        self.locationMenu.add_command(label=_('Export location descriptions'), command=lambda: self._ctrl.export_document(LOCATIONS_SUFFIX))
        self.locationMenu.add_command(label=_('Export location list'), command=lambda: self._ctrl.export_document(LOCLIST_SUFFIX))
        self.locationMenu.add_command(label=_('Show list'), command=lambda: self._ctrl.show_report(LOCATION_REPORT_SUFFIX))

        self.itemMenu = tk.Menu(self.mainMenu, tearoff=0)
        self.mainMenu.add_cascade(label=_('Items'), menu=self.itemMenu)
        self.itemMenu.add_command(label=_('Add'), command=self._ctrl.add_item)
        self.itemMenu.add_separator()
        self.itemMenu.add_command(label=_('Export item descriptions'), command=lambda: self._ctrl.export_document(ITEMS_SUFFIX))
        self.itemMenu.add_command(label=_('Export item list'), command=lambda: self._ctrl.export_document(ITEMLIST_SUFFIX))
        self.itemMenu.add_command(label=_('Show list'), command=lambda: self._ctrl.show_report(ITEM_REPORT_SUFFIX))

        self.plotMenu = tk.Menu(self.mainMenu, tearoff=0)
        self.mainMenu.add_cascade(label=_('Plot'), menu=self.plotMenu)
        self.plotMenu.add_command(label=_('Add Plot line'), command=self._ctrl.add_plot_line)
        self.plotMenu.add_command(label=_('Add Plot point'), command=self._ctrl.add_plot_point)
        self.plotMenu.add_separator()
        self.plotMenu.add_command(label=_('Insert Stage'), command=self._ctrl.add_stage)
        self.plotMenu.add_cascade(label=_('Change Level'), menu=self.tv.selectLevelMenu)
        self.plotMenu.add_separator()
        self.plotMenu.add_command(label=_('Export plot grid'), command=lambda:self._ctrl.export_document(GRID_SUFFIX))
        self.plotMenu.add_command(label=_('Export story structure description'), command=lambda:self._ctrl.export_document(STAGES_SUFFIX))
        self.plotMenu.add_command(label=_('Export plot line descriptions'), command=lambda: self._ctrl.export_document(PLOTLINES_SUFFIX))
        self.plotMenu.add_separator()
        self.plotMenu.add_command(label=_('Show Plot list'), command=lambda: self._ctrl.show_report(PLOTLIST_SUFFIX))

        self.prjNoteMenu = tk.Menu(self.mainMenu, tearoff=0)
        self.mainMenu.add_cascade(label=_('Project notes'), menu=self.prjNoteMenu)
        self.prjNoteMenu.add_command(label=_('Add'), command=self._ctrl.add_project_note)
        self.prjNoteMenu.add_separator()
        self.prjNoteMenu.add_command(label=_('Show list'), command=lambda: self._ctrl.show_report('_projectnote_report'))

        self.exportMenu = tk.Menu(self.mainMenu, tearoff=0)
        self.mainMenu.add_cascade(label=_('Export'), menu=self.exportMenu)
        self.exportMenu.add_command(label=_('Manuscript'), command=lambda: self._ctrl.export_document(''))
        self.exportMenu.add_command(label=_('Brief synopsis'), command=lambda: self._ctrl.export_document(BRF_SYNOPSIS_SUFFIX))
        self.exportMenu.add_separator()
        self.exportMenu.add_command(label=_('Options'), command=self._open_export_options)

        self.toolsMenu = tk.Menu(self.mainMenu, tearoff=0)
        self.mainMenu.add_cascade(label=_('Tools'), menu=self.toolsMenu)
        self.toolsMenu.add_command(label=_('Open installation folder'), command=self._ctrl.open_installationFolder)
        self.toolsMenu.add_separator()

        self.helpMenu = tk.Menu(self.mainMenu, tearoff=0)
        self.mainMenu.add_cascade(label=_('Help'), menu=self.helpMenu)
        self.helpMenu.add_command(label=_('Online help'), accelerator=KEYS.OPEN_HELP[1], command=self._open_help)
        self.helpMenu.add_command(label=f"mdnovel {_('Home page')}", command=lambda: webbrowser.open(HOME_URL))

    def _open_export_options(self, event=None):
        ExportOptionsWindow(self._mdl, self, self._ctrl)
        return 'break'

    def _open_help(self, event=None):
        open_help('')

    def _open_view_options(self, event=None):
        ViewOptionsWindow(self._mdl, self, self._ctrl)
        return 'break'



class NvController(ControllerBase):

    def __init__(self, title, tempDir):
        super().__init__(title)
        self.tempDir = tempDir

        self._mdl = NvModel()
        self._mdl.register_client(self)

        self._ui = NvView(self._mdl, self, title)

        self.launchers = {}

        self.linkProcessor = LinkProcessor(self._mdl)

        self._fileTypes = [(NvWorkFile.DESCRIPTION, NvWorkFile.EXTENSION)]
        self.importFiletypes = [(_('Markdown document'), '.md')]

        self._mdl.tree = self._ui.tv.tree

        self.plugins = NvPluginCollection(self._mdl, self._ui, self)

        self.disable_menu()
        self._ui.tv.reset_view()

    def add_chapter(self, **kwargs):
        targetNode = kwargs.get('targetNode', None)
        if targetNode is None:
            try:
                kwargs['targetNode'] = self._ui.tv.tree.selection()[0]
            except:
                pass
        newNode = self._mdl.add_chapter(**kwargs)
        self._view_new_element(newNode)
        return newNode

    def add_character(self, **kwargs):
        targetNode = kwargs.get('targetNode', None)
        if targetNode is None:
            try:
                kwargs['targetNode'] = self._ui.tv.tree.selection()[0]
            except:
                pass
        newNode = self._mdl.add_character(**kwargs)
        self._view_new_element(newNode)
        return newNode

    def add_child(self, event=None):
        if self._mdl.prjFile is None:
            return

        try:
            selection = self._ui.tv.tree.selection()[0]
        except:
            return

        if selection == CH_ROOT:
            self.add_chapter(targetNode=selection)
            return

        if selection.startswith(CHAPTER_PREFIX):
            self.add_section(targetNode=selection)
            return

        if selection.startswith(PLOT_LINE_PREFIX):
            self.add_plot_point(targetNode=selection)
            return

        if selection == CR_ROOT:
            self.add_character(targetNode=selection)
            return

        if selection == LC_ROOT:
            self.add_location(targetNode=selection)
            return

        if selection == IT_ROOT:
            self.add_item(targetNode=selection)
            return

        if selection == PL_ROOT:
            self.add_plot_line(targetNode=selection)
            return

        if selection == PN_ROOT:
            self.add_project_note(targetNode=selection)

    def add_element(self, event=None):
        if self._mdl.prjFile is None:
            return

        try:
            selection = self._ui.tv.tree.selection()[0]
        except:
            return

        if selection.startswith(SECTION_PREFIX):
            if self._mdl.novel.sections[selection].scType < 2:
                self.add_section(targetNode=selection)
                return

            self.add_stage(targetNode=selection)
            return

        if CHAPTER_PREFIX in selection:
            self.add_chapter(targetNode=selection)
            return

        if CHARACTER_PREFIX in selection:
            self.add_character(targetNode=selection)
            return

        if LOCATION_PREFIX in selection:
            self.add_location(targetNode=selection)
            return

        if ITEM_PREFIX in selection:
            self.add_item(targetNode=selection)
            return

        if PLOT_LINE_PREFIX in selection:
            self.add_plot_line(targetNode=selection)
            return

        if PRJ_NOTE_PREFIX in selection:
            self.add_project_note(targetNode=selection)
            return

        if selection.startswith(PLOT_POINT_PREFIX):
            self.add_plot_point(targetNode=selection)

    def add_item(self, **kwargs):
        targetNode = kwargs.get('targetNode', None)
        if targetNode is None:
            try:
                kwargs['targetNode'] = self._ui.tv.tree.selection()[0]
            except:
                pass
        newNode = self._mdl.add_item(**kwargs)
        self._view_new_element(newNode)
        return newNode

    def add_location(self, **kwargs):
        targetNode = kwargs.get('targetNode', None)
        if targetNode is None:
            try:
                kwargs['targetNode'] = self._ui.tv.tree.selection()[0]
            except:
                pass
        newNode = self._mdl.add_location(**kwargs)
        self._view_new_element(newNode)
        return newNode

    def add_parent(self, event=None):
        if self._mdl.prjFile is None:
            return

        try:
            selection = self._ui.tv.tree.selection()[0]
        except:
            return

        if selection.startswith(SECTION_PREFIX):
            self.add_chapter(targetNode=selection)
        elif selection.startswith(PLOT_POINT_PREFIX):
            self.add_plot_line(targetNode=selection)

    def add_part(self, **kwargs):
        targetNode = kwargs.get('targetNode', None)
        if targetNode is None:
            try:
                kwargs['targetNode'] = self._ui.tv.tree.selection()[0]
            except:
                pass
        newNode = self._mdl.add_part(**kwargs)
        self._view_new_element(newNode)
        return newNode

    def add_plot_line(self, **kwargs):
        targetNode = kwargs.get('targetNode', None)
        if targetNode is None:
            try:
                kwargs['targetNode'] = self._ui.tv.tree.selection()[0]
            except:
                pass
        newNode = self._mdl.add_plot_line(**kwargs)
        self._view_new_element(newNode)
        return newNode

    def add_plot_point(self, **kwargs):
        targetNode = kwargs.get('targetNode', None)
        if targetNode is None:
            try:
                kwargs['targetNode'] = self._ui.tv.tree.selection()[0]
            except:
                pass
        newNode = self._mdl.add_plot_point(**kwargs)
        self._view_new_element(newNode)
        return newNode

    def add_project_note(self, **kwargs):
        targetNode = kwargs.get('targetNode', None)
        if targetNode is None:
            try:
                kwargs['targetNode'] = self._ui.tv.tree.selection()[0]
            except:
                pass
        newNode = self._mdl.add_project_note(**kwargs)
        self._view_new_element(newNode)
        return newNode

    def add_section(self, **kwargs):
        targetNode = kwargs.get('targetNode', None)
        if targetNode is None:
            try:
                kwargs['targetNode'] = self._ui.tv.tree.selection()[0]
            except:
                pass
        newNode = self._mdl.add_section(**kwargs)
        self._view_new_element(newNode)
        return newNode

    def add_stage(self, **kwargs):
        targetNode = kwargs.get('targetNode', None)
        if targetNode is None:
            try:
                kwargs['targetNode'] = self._ui.tv.tree.selection()[0]
            except:
                pass
        newNode = self._mdl.add_stage(**kwargs)
        self._view_new_element(newNode)
        return newNode

    def close_project(self, event=None, doNotSave=False):
        self._ui.propertiesView.apply_changes()
        self.plugins.on_close()
        if self._mdl.isModified and not doNotSave:
            if self._ui.ask_yes_no(_('Save changes?')):
                if not self.save_project():
                    self._ui.show_error(_('Cannot save the project'), _('Critical Error'))

        self._ui.propertiesView._view_nothing()
        self._mdl.close_project()
        self._ui.tv.reset_view()
        self._ui.contentsView.reset_view()
        self._ui.root.title(self._ui.title)
        self.show_status('')
        self._ui.show_path('')
        self.disable_menu()
        return 'break'

    def delete_elements(self, event=None, elements=None):
        if elements is None:
            try:
                elements = self._ui.tv.tree.selection()
            except:
                return

        for  elemId in elements:
            if elemId.startswith(SECTION_PREFIX):
                if self._mdl.novel.sections[elemId].scType < 2:
                    candidate = f'{_("Section")} "{self._mdl.novel.sections[elemId].title}"'
                else:
                    candidate = f'{_("Stage")} "{self._mdl.novel.sections[elemId].title}"'
            elif elemId.startswith(CHAPTER_PREFIX):
                candidate = f'{_("Chapter")} "{self._mdl.novel.chapters[elemId].title}"'
            elif elemId.startswith(CHARACTER_PREFIX):
                candidate = f'{_("Character")} "{self._mdl.novel.characters[elemId].title}"'
            elif elemId.startswith(LOCATION_PREFIX):
                candidate = f'{_("Location")} "{self._mdl.novel.locations[elemId].title}"'
            elif elemId.startswith(ITEM_PREFIX):
                candidate = f'{_("Item")} "{self._mdl.novel.items[elemId].title}"'
            elif elemId.startswith(PLOT_LINE_PREFIX):
                candidate = f'{_("Plot line")} "{self._mdl.novel.plotLines[elemId].title}"'
            elif elemId.startswith(PLOT_POINT_PREFIX):
                candidate = f'{_("Plot point")} "{self._mdl.novel.plotPoints[elemId].title}"'
            elif elemId.startswith(PRJ_NOTE_PREFIX):
                candidate = f'{_("Project note")} "{self._mdl.novel.projectNotes[elemId].title}"'
            else:
                return

            if not self._ui.ask_yes_no(_('Delete {}?').format(candidate)):
                return

            if self._ui.tv.tree.prev(elemId):
                self._view_new_element(self._ui.tv.tree.prev(elemId))
            else:
                self._view_new_element(self._ui.tv.tree.parent(elemId))
            self._mdl.delete_element(elemId)

    def export_document(self, suffix, **kwargs):
        self._ui.restore_status()
        self._ui.propertiesView.apply_changes()
        if self._mdl.prjFile.filePath is not None or self.save_project():
            if self._mdl.isModified:
                if self._ui.ask_yes_no(_('Save changes?')):
                    self.save_project()
                else:
                    return

            exporter = NvDocExporter(self._ui)
            try:
                self._ui.set_status(exporter.run(self._mdl.prjFile, suffix, **kwargs))
            except Error as ex:
                self._ui.set_status(f'!{str(ex)}')

    def get_preferences(self):
        return prefs

    def import_md(self, event=None, sourcePath=None, defaultExtension='.md'):
        if sourcePath is None:
            if prefs['last_open']:
                startDir, __ = os.path.split(prefs['last_open'])
            else:
                startDir = '.'
            sourcePath = filedialog.askopenfilename(
                filetypes=self.importFiletypes,
                defaultextension=defaultExtension,
                initialdir=startDir,
                )
            if not sourcePath:
                return 'break'

        if self._mdl.prjFile is not None:
            self.show_status()
            self.refresh_views()
            if self._mdl.isModified:
                if self._ui.ask_yes_no(_('Save changes?')):
                    self.save_project()
        importer = NvDocImporter(self._ui)
        try:
            message = importer.run(sourcePath, nv_service=self._mdl.nvService)
        except Error as ex:
            self._ui.set_status(f'!{str(ex)}')
            return 'break'

        if importer.newFile:
            self.open_project(filePath=importer.newFile)
            if os.path.isfile(sourcePath) and prefs['import_mode'] == '1':
                os.replace(sourcePath, f'{sourcePath}.bak')
                message = f'{message} - {_("Source document deleted")}.'
            self._ui.set_status(message)
        return 'break'

    def join_sections(self, event=None, scId0=None, scId1=None):
        if scId0 is None or scId1 is None:
            try:
                scId1 = self._ui.tv.tree.selection()[0]
            except:
                return

            if not scId1.startswith(SECTION_PREFIX):
                return

            scId0 = self._ui.tv.prev_node(scId1)
            if not scId0:
                self._ui.show_error(_('There is no previous section'), title=_('Cannot join sections'))
                return

        if self._ui.ask_yes_no(f'{_("Join with previous")}?'):
            try:
                self._mdl.join_sections(scId0, scId1)
            except Error as ex:
                self._ui.show_error(str(ex), title=_('Cannot join sections'))
                return

            self._view_new_element(scId0)

    def move_node(self, node, targetNode):
        if (node.startswith(SECTION_PREFIX) and targetNode.startswith(CHAPTER_PREFIX)
            ) or (node.startswith(PLOT_POINT_PREFIX) and targetNode.startswith(PLOT_LINE_PREFIX)):
            self._ui.tv.open_children(targetNode)
        self._ui.tv.skipUpdate = True
        self._mdl.move_node(node, targetNode)

    def new_project(self, event=None):
        if self._mdl.prjFile is not None:
            self.close_project()
        self._mdl.new_project(self._ui.tv.tree)
        self._ui.show_path(_('Unnamed'))
        self.enable_menu()
        self.show_status()
        self._ui.tv.go_to_node(CH_ROOT)
        self.refresh_views()
        self.save_project()
        return 'break'

    def on_quit(self, event=None):
        try:
            if self._mdl.prjFile is not None:
                self.close_project()
            super().on_quit()
        except Exception as ex:
            self._ui.show_error(str(ex), title='ERROR: Unhandled exception on exit')
            self._ui.root.quit()
        return 'break'

    def open_installationFolder(self, event=None):
        installDir = os.path.dirname(sys.argv[0])
        try:
            os.startfile(norm_path(installDir))
        except:
            try:
                os.system('xdg-open "%s"' % norm_path(installDir))
            except:
                try:
                    os.system('open "%s"' % norm_path(installDir))
                except:
                    pass
        return 'break'

    def open_link(self, element, linkIndex):
        linkPath = list(element.links)[linkIndex]
        fullPath = element.links[linkPath]
        try:
            self.linkProcessor.open_link(linkPath, self.launchers)
        except:

            if fullPath is not None:
                newPath = self.linkProcessor.shorten_path(fullPath)
            else:
                newPath = ''
            try:
                self.linkProcessor.open_link(newPath, self.launchers)
            except Exception as ex:

                self._ui.show_error(
                    str(ex),
                    title=_('Cannot open link')
                    )
            else:
                links = element.links
                del links[linkPath]
                links[newPath] = fullPath
                element.links = links
                self._ui.set_status(_('Broken link fixed'))
        else:
            pathOk = self.linkProcessor.expand_path(linkPath)
            if fullPath != pathOk:
                links = element.links
                links[linkPath] = pathOk
                element.links = links
                self._ui.set_status(_('Broken link fixed'))

    def open_project(self, event=None, filePath='', doNotSave=False):
        self._ui.restore_status()
        filePath = self.select_project(filePath)
        if not filePath:
            return False

        prefs['last_open'] = filePath

        if self._mdl.prjFile is not None:
            self.close_project(doNotSave=doNotSave)
        try:
            self._mdl.open_project(filePath)
        except Error as ex:
            self.close_project(doNotSave=doNotSave)
            self._ui.set_status(f'!{str(ex)}')
            return False

        self._ui.show_path(f'{norm_path(self._mdl.prjFile.filePath)}')
        self.enable_menu()

        self.refresh_views()
        self._ui.show_path(_('{0} (last saved on {1})').format(norm_path(self._mdl.prjFile.filePath), self._mdl.prjFile.fileDate))
        self.show_status()
        self._ui.contentsView.view_text()
        self._ui.tv.show_branch(CH_ROOT)
        return True

    def open_project_folder(self, event=None):
        if not self.save_project():
            if not self._mdl:
                return

            if not self._mdl.prjFile:
                return

            if self._mdl.prjFile.filePath is None:
                return

        projectDir, __ = os.path.split(self._mdl.prjFile.filePath)
        try:
            os.startfile(norm_path(projectDir))
        except:
            try:
                os.system('xdg-open "%s"' % norm_path(projectDir))
            except:
                try:
                    os.system('open "%s"' % norm_path(projectDir))
                except:
                    pass
        return 'break'

    def refresh(self):
        self.show_status()

    def refresh_views(self, event=None):
        self._ui.propertiesView.apply_changes()
        self._mdl.renumber_chapters()
        self._mdl.prjFile.adjust_section_types()
        self._mdl.novel.update_plot_lines()
        self._ui.refresh()
        return 'break'

    def reload_project(self, event=None):
        if self._mdl.prjFile is None:
            return 'break'

        if self._mdl.isModified and not self._ui.ask_yes_no(_('Discard changes and reload the project?')):
            return 'break'

        if self._mdl.prjFile.has_changed_on_disk() and not self._ui.ask_yes_no(_('File has changed on disk. Reload anyway?')):
            return 'break'

        if self.open_project(filePath=self._mdl.prjFile.filePath, doNotSave=True):
            self._ui.set_status(_('Project successfully restored from disk.'))
        return 'break'

    def reset_tree(self, event=None):
        self._mdl.reset_tree()

    def restore_backup(self, event=None):
        if self._mdl.prjFile is None:
            return 'break'

        latestBackup = f'{self._mdl.prjFile.filePath}.bak'
        if not os.path.isfile(latestBackup):
            self._ui.set_status(f'!{_("No backup available")}')
            return 'break'

        if self._mdl.isModified:
            if not self._ui.ask_yes_no(_('Discard changes and restore the latest backup?')):
                return 'break'

        elif not self._ui.ask_yes_no(_('Restore the latest backup?')):
            return 'break'

        try:
            os.replace(latestBackup, self._mdl.prjFile.filePath)
        except Exception as ex:
            self._ui.set_status(str(ex))
        else:
            if self.open_project(filePath=self._mdl.prjFile.filePath, doNotSave=True):
                self._ui.set_status(_('Latest backup successfully restored.'))
        return 'break'

    def save_as(self, event=None):
        if self._mdl.prjFile is None:
            return False

        if prefs['last_open']:
            startDir, __ = os.path.split(prefs['last_open'])
        else:
            startDir = '.'
        fileName = filedialog.asksaveasfilename(
            filetypes=self._fileTypes,
            defaultextension=self._fileTypes[0][1],
            initialdir=startDir,
            )
        if fileName:
            if self._mdl.prjFile is not None:
                self._ui.propertiesView.apply_changes()
                try:
                    self._mdl.save_project(fileName)
                except Error as ex:
                    self._ui.set_status(f'!{str(ex)}')
                else:
                    self._ui.show_path(f'{norm_path(self._mdl.prjFile.filePath)} ({_("last saved on")} {self._mdl.prjFile.fileDate})')
                    self._ui.restore_status()
                    prefs['last_open'] = self._mdl.prjFile.filePath
                    return True

        return False

    def save_project(self, event=None):
        if self._mdl.prjFile is None:
            return False

        if self._mdl.prjFile.filePath is None:
            return self.save_as()

        if self._mdl.prjFile.has_changed_on_disk() and not self._ui.ask_yes_no(_('File has changed on disk. Save anyway?')):
            return False

        self._ui.propertiesView.apply_changes()
        try:
            self._mdl.save_project()
        except Error as ex:
            self._ui.set_status(f'!{str(ex)}')
            return False

        self._ui.show_path(f'{norm_path(self._mdl.prjFile.filePath)} ({_("last saved on")} {self._mdl.prjFile.fileDate})')
        self._ui.restore_status()
        prefs['last_open'] = self._mdl.prjFile.filePath
        return True

    def select_project(self, fileName):
        initDir = os.path.dirname(prefs.get('last_open', ''))
        if not initDir:
            initDir = './'
        if not fileName or not os.path.isfile(fileName):
            fileName = filedialog.askopenfilename(
                filetypes=self._fileTypes,
                defaultextension=NvWorkFile.EXTENSION,
                initialdir=initDir
                )
        if not fileName:
            return ''

        return fileName

    def set_character_status(self, isMajor, elemIds=None):
        if elemIds is None:
            try:
                elemIds = self._ui.tv.tree.selection()
            except:
                return

        self._ui.tv.open_children(CR_ROOT)
        self._mdl.set_character_status(isMajor, elemIds)

    def set_level(self, newLevel, elemIds=None):
        if elemIds is None:
            try:
                elemIds = self._ui.tv.tree.selection()
            except:
                return

        self._mdl.set_level(newLevel, elemIds)

    def set_completion_status(self, newStatus, elemIds=None):
        if elemIds is None:
            try:
                elemIds = self._ui.tv.tree.selection()
            except:
                return

        self._ui.tv.open_children(elemIds[0])
        self._mdl.set_completion_status(newStatus, elemIds)

    def set_type(self, newType, elemIds=None):
        if elemIds is None:
            try:
                elemIds = self._ui.tv.tree.selection()
            except:
                return

        self._ui.tv.open_children(elemIds[0])
        self._mdl.set_type(newType, elemIds)

    def show_report(self, suffix):
        if self._mdl.prjFile.filePath is None:
            return False

        self._ui.restore_status()
        self._ui.propertiesView.apply_changes()
        reporter = NvHtmlReporter()
        try:
            reporter.run(self._mdl.prjFile, suffix, tempdir=self.tempDir)
        except Error as ex:
            self._ui.set_status(f'!{str(ex)}')

    def show_status(self, message=None):
        if self._mdl.novel is not None and not message:
            wordCount, sectionCount, chapterCount, partCount = self._mdl.get_counts()
            message = _('{0} parts, {1} chapters, {2} sections, {3} words').format(partCount, chapterCount, sectionCount, wordCount)
            self.wordCount = wordCount
        self._ui.show_status(message)

    def _view_new_element(self, newNode):
        if newNode:
            self._ui.tv.go_to_node(newNode)
            self._ui.propertiesView.show_properties(newNode)
            self._ui.propertiesView.focus_title()
        else:
            self._ui.set_status(f'!{_("Cannot create the element at this position")}.')


SETTINGS = dict(
    arcs_width=55,
    color_1st_edit='DarkGoldenrod4',
    color_2nd_edit='DarkGoldenrod3',
    color_arc='maroon',
    color_before_schedule='lime green',
    color_behind_schedule='magenta',
    color_chapter='green',
    color_done='DarkGoldenrod2',
    color_draft='black',
    color_major='navy',
    color_minor='cornflower blue',
    color_modified_bg='goldenrod1',
    color_modified_fg='maroon',
    color_notes_bg='lemon chiffon',
    color_notes_fg='black',
    color_on_schedule='black',
    color_outline='dark orchid',
    color_stage='red',
    color_text_bg='white',
    color_text_fg='black',
    color_unused='gray',
    coloring_mode='',
    column_order='wc;vp;sy;st;nt;dt;tm;dr;tg;po;ac;pt;ar',
    date_width=70,
    duration_width=55,
    gco_height=4,
    gui_theme='',
    import_mode='0',
    index_card_height=13,
    last_open='',
    middle_frame_width=400,
    nt_width=20,
    points_width=300,
    prop_win_geometry='299x716+260+260',
    ps_width=50,
    right_frame_width=350,
    root_geometry='1200x800',
    scene_width=40,
    status_width=100,
    tags_width=100,
    time_width=40,
    title_width=400,
    vp_width=100,
    wc_width=50,
    )
OPTIONS = dict(
    ask_doc_open=True,
    detach_prop_win=False,
    enable_hovertips=True,
    large_icons=False,
    localize_date=True,
    show_auto_numbering=False,
    show_ch_links=False,
    show_contents=True,
    show_cr_bio=True,
    show_cr_goals=True,
    show_cr_links=False,
    show_date_time=False,
    show_it_links=False,
    show_language_settings=False,
    show_lc_links=False,
    show_markdown=True,
    show_narrative_time=False,
    show_pl_links=False,
    show_plot=False,
    show_pn_links=False,
    show_pp_links=False,
    show_pr_links=False,
    show_properties=True,
    show_relationships=False,
    show_renamings=False,
    show_sc_links=False,
    show_scene=False,
    show_st_links=False,
    show_writing_progress=False,
)


def main():
    try:
        homeDir = str(Path.home()).replace('\\', '/')
        installDir = f'{homeDir}/.mdnovel'
    except:
        installDir = '.'
    os.makedirs(installDir, exist_ok=True)
    configDir = f'{installDir}/config'
    os.makedirs(configDir, exist_ok=True)
    tempDir = f'{installDir}/temp'
    os.makedirs(tempDir, exist_ok=True)

    iniFile = f'{configDir}/novx.ini'
    configuration = Configuration(SETTINGS, OPTIONS)
    configuration.read(iniFile)
    prefs.update(configuration.settings)
    prefs.update(configuration.options)

    app = NvController('mdnovel 1.0.1', tempDir)
    ui = app.get_view()

    launcherConfig = NvConfiguration()
    launcherConfig.read(f'{configDir}/launchers.ini')
    app.launchers = launcherConfig.settings

    try:
        sourcePath = sys.argv[1]
    except:
        sourcePath = ''
    if not sourcePath or not os.path.isfile(sourcePath):
        sourcePath = prefs['last_open']
    root, extension = os.path.splitext(sourcePath)
    if extension != NvWorkFile.EXTENSION:
        sourcePath = f'{root}{NvWorkFile.EXTENSION}'
    if sourcePath and os.path.isfile(sourcePath):
        app.open_project(filePath=sourcePath)

    ui.start()

    for keyword in prefs:
        if keyword in configuration.options:
            configuration.options[keyword] = prefs[keyword]
        elif keyword in configuration.settings:
            configuration.settings[keyword] = prefs[keyword]
    configuration.write(iniFile)

    for file in os.scandir(tempDir):
        try:
            os.remove(file)
        except:
            pass


if __name__ == '__main__':
    main()
