# ACT 1

Setup

## Inciting Incident

Also called "catalyst" or "call to adventure".
This sets the protagonist in motion.

## Plot Point 1

"Point of no return": The protagonist engages with the action 
the inciting incident has created.

# ACT 2

Confrontation

## Midpoint

The main turning point. A significant event, changing the 
development of things from good to bad, or vice versa.

## Plot Point 2

The aftermath of the Midpoint crisis.
What changes the protagonist from "passenger" to "driver".  

# ACT 3

Resolution

## Climax

The final moment of the story's conflict.
